#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	char l[30], login[30], s[15], senha[15];
	int i;
	
	printf("Digite o login para cadastro: ");
	fflush(stdin);
	gets(l);
	
	printf("Digite a senha para cadastro: ");
	fflush(stdin);
	gets(s);
	
    system("cls");
	
	printf("Digite o login: ");
	fflush(stdin);
	gets(login);
	if (strcmp(l,login) != 0)
		printf("\nLogin incorreto\n");	
	    else{
 	       printf("Digite a senha: ");
	       fflush(stdin);
	       gets(senha);
   	       if (strcmp(s,senha) != 0)
		      printf("\nSenha incorreta\n");
		}
	
	if (strlen(l) == strlen(login)){
	   for(i = 0;i < strlen(l);i++){
		  if (l[i] != login[i]){
		  	 printf("\nLogin incorreto... %d\n",i);
		  	 exit(0);
		  }
	   }
	}
	
	return 0;
	
}