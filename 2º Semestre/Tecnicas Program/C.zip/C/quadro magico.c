#include <stdio.h>
main(){

  int m[4][4], l, c, soma1, soma2, ok, achou=0;

  srand(time(NULL));

while(!achou){
  for(l = 0; l <= 3; l++)
    for(c = 0; c <= 3; c++)
//      scanf("%d", &m[l][c]);
      m[l][c] = rand()/10000;

  for(l = 0; l <= 3; l++){
    for(c = 0; c <= 3; c++)
      printf("%d ", m[l][c]);
    printf("\n")  ;
  }

  soma1 = 0;

  for(l = 0; l <= 3; l++)
   soma1 = soma1 + m[0][l];

//linhas
  ok = 0;
  for(l = 0; l <= 3; l++){
    soma2 = 0;
    for(c = 0; c <= 3; c++)
      soma2 = soma2 + m[l][c];
    if (soma1 != soma2){
      ok = 1;
      l = 5;
    }
  }

//colunas
  if (ok == 0){
    for(c = 0; c <= 3; c++){
      soma2 = 0;
      for(l = 0; l <= 3; l++)
        soma2 = soma2 + m[c][l];
      if (soma1 != soma2){
        ok = 1;
        l = 5;
      }
    }
  }

//diagonal principal
  if (ok == 0){
    soma2 = 0;
    for(l = 0; l <= 3; l++)
      soma2 = soma2 + m[l][l];
      if (soma1 != soma2){
        ok = 1;
      }
  }

//diagonal secundaria
//0 3
//1 2
//2 2
//3 0
  if (ok == 0){
    soma2 = 0;
    for(l = 0, c = 3; l <= 3; l++, c--)
      soma2 = soma2 + m[l][c];
    if (soma1 != soma2){
      ok = 1;
    }
  }

  if (ok == 0){
    printf("\nquadrado magico\n");
    achou = 1;
  }
    else
      printf("\nnao quadrado magico\n");
}
}
