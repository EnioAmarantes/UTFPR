#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct aluno{
    int cod;
    char nome[50];
    char coddisc[6];
    int faltas;
    float notas[3];
    float media;
    float exame;
    float nf;
    char res[10];
} typedef tp_aluno;

struct disciplina{
    char coddis[6];
    char disc[30];
} typedef tp_disciplina;

void lerdisciplina(tp_disciplina [], int);
	//vetor de disciplinas, posi��o no vetor de disciplinas
	//l� os dados de uma disciplina e grava no vetor na posi��o atual
void leraluno(tp_aluno [], int, tp_disciplina[]);
	//vetor de alunos, posi��o no vetor de alunos, vetor de disciplinas
	//l� os dados de um aluno e grava no vetor na posi��o atual
int verificadisciplina(tp_disciplina [], char [], int);
	//vetor de disciplinas, c�digo da disciplina, limite do vetor de disciplinas
	//verifica se um c�digo de disciplina j� foi inserido no vetor
int verificaaluno(tp_aluno [], int, int);
	//vetor de alunos, c�digo do aluno, limite do vetor de alunos
	//verifica se um c�digo de aluno j� foi inserido no vetor
float calculamedia(tp_aluno [], int, int);
	//vetor de alunos, posi��o no vetor de alunos, quantidade de notas
	//retorna a m�dia para a quantidade de notas de um aluno
void leexame(tp_aluno[], int);
	//vetor de alunos, posi��o no vetor de alunos
	//l� a nota do exame final de um aluno e grava na posi��o atual
float calculanotafinal(tp_aluno [], int);
	//vetor de alunos, posi��o no vetor de alunos
	//retorna a nota final de um aluno
char resultadofinal(tp_aluno [], int);
	//vetor de alunos, posi��o no vetor de alunos
	//retorna o resultado final de um aluno
void imprimealuno(tp_aluno [], int);
	//vetor de alunos, limite do vetor de alunos
	//mostra na tela os dados de todos os alunos cadastrados
void imprimedisciplina(tp_aluno [], int);
	//vetor de disciplinas, limite do vetor de disciplinas
	//mostra na tela os dados de todas as disciplinas cadastradas
void ordenaalunonome(tp_aluno [], int);
	//vetor de alunos, limite do vetor de alunos
	//ordena o vetor de alunos alfabeticamente por nome crescente
void ordenaalunonotafinal(tp_aluno [], int);
	//vetor de alunos, limite do vetor de alunos
	//ordena o vetor de alunos por nota final decrescente
int menu();
    //imprime o menu na tela
    //retorna a op��o selecionada

int main(){
  tp_disciplina disciplinas[15];
  int pos_disc;

  for(pos_disc = 0;pos_disc < 15;pos_disc = pos_disc + 1)
  {
  	printf("\nInfvoid lerdisciplina(tp_disciplina disc[], int pos)orme os dados para a %d disciplina de um total de 15\n",pos_disc+1);
    lerdisciplina(disciplinas, pos_disc);
  }
  return 0;
}

float calculamedia(tp_aluno aluno[], int pos, int q)
{
	float soma;
	int i;
	for(i = 0, soma = 0;i < q;i = i + 1)
	  soma = soma + aluno[pos].notas[i];
	return soma / q;
}

void lerdisciplina(tp_disciplina disc[], int pos)
{
	char codigo[6];
	do{
	  printf("\nDigite o codigo da disciplina: ");
	  fflush(stdin);
	  gets(codigo);
	}while (verificadisciplina(disc, codigo, pos));
	strcpy(disc[pos].coddis,codigo);
	printf("\nDigite o nome da disciplina: ");
	fflush(stdin);
	gets(disc[pos].disc);
}

int verificadisciplina(tp_disciplina disc[], char codigo[6], int pos)
{
	int i;
	for(i = 0;i < pos;i = i + 1)
      if (strcmp(disc[i].coddis,codigo) == 0)
      	 return 1;
    return 0;
}
