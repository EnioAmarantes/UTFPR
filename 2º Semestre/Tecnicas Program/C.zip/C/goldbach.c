#include <stdio.h>
#define Ta 25
#define Tb 75
preenchea(int[], int);
void mostravetor(int[], int);
int primo(int);
main(){
  int A[Ta], B[Tb], i, j, np1, OK;
  preenchea(A, Ta);
  printf("\n\nVetor A\n");
  mostravetor(A, Ta);
  srand(time(NULL));
  j = 0; i = 0;
  while (i < Ta){
    OK = 0;
    do{
      np1 = rand()/100; //gera um n�mero aleat�rio para verificar depois e o mesmo � primo

      if ((np1 % 2 != 0) && (np1 < A[i]) && (!primo(np1)) && (!primo(A[i]-np1))){
        B[j] = A[i];
        B[j+1] = np1;
        B[j+2] = A[i]-np1;
        if (j < Tb)
           printf("\n%d \t--> \t%d \t= \t%d \t+ \t%d",i,B[j],B[j+1],B[j+2]);
        i = i + 1;
        j = j + 3;
        OK = 1;
       }
    }while (!(OK));
  }
  printf("\n\nVetor B\n");
  mostravetor(B, Tb);
  printf("\n\n");
}
preenchea(int v[], int t){
  int i, x, j, n;
  for(i = 0; i <= t; i++)
    v[i] = 0;
  i = 0;
  srand(time(NULL));
  while (i <= t){
    do{
      //printf("\ndigite o %d numero para o vetor (numeros pares maiores do que 5): ", i + 1);
      //scanf("%d", &x);
      x = rand()/100;  //preenche o vetor com n�meros aleat�rios
    }while ((x <= 5) || (x % 2 != 0));
    n = 0;
    for(j = 0; j < i; j++)
      if (v[j] == x)
        n = 1;
    if (n == 0) {
      v[i] = x;
      i++;
    }
  }
}
void mostravetor(int v[], int t){
  int i;
  for(i = 0; i < t; i++)
    printf("%d ",v[i]);
}
int primo(int n){
  int x, p;
  p = 0;
  x = n;
  while (x >= 1) {
    if (n % x == 0)
      p++;
    x--;
  }
  if (p == 2)
    return 0;  //falso - esta fun��o est� retornando falso ou verdadeiro 'trocados'
    else       //neste caso, a verifica��o do seu retorno deve ser negada (if !(primo(x))...)
       return 1;  //verdadeiro
}
