#include <stdio.h>
#include <stdlib.h>
int main(){
  int bin[100], i, n;
  char b[50];
  printf("Digite um numero: ");
  scanf("%d", &n);
//itoa --> into to ascii - converte um valor inteiro para ascii
//itoa(valorinteiro,vari�velchardestino,basenum�rica)
//itoa(n,b,2) - converte o valor da vari�vel inteira n para
//              a vari�vel char(string) b na base 2(bin�rio)
  itoa(n,b,2);
  printf ("\nbinario:\n%s\n",b);  
  
  for(i = 0; n > 0; i++){
    bin[i] = n % 2;
    n = n / 2;
  }

  for(i = i - 1; i >= 0; i--)
    printf("%d",bin[i]);

  return 0;

}
