#include <stdio.h>
void dec_bin(int *i, int n, int vet[]){
  for(*i = 0;n > 0;*i = *i + 1){
    vet[*i] = n % 2;
    n = n / 2;
  }
}
void imprime_bin(int *i, int vet[]){
  for(*i = *i - 1;*i >= 0;*i = *i - 1)
    printf("%d",vet[*i]);
}
int main(){

  int bin[100], num, i;

  printf("digite um numero inteiro para converte-lo para binario: ");
  scanf("%d",&num);
  dec_bin(&i,num,bin);
  imprime_bin(&i,bin);

  return 0;
}
