//A  - Z
//65 - 90
//a  - z
//97 - 122
#include <stdio.h>
main(){
  int x = 0, n;
  while(x <= 255){
    printf("\n\%3d ->%3c", x, x);
    x++;
  }
/*  
  printf("digite um numero entre 65 e 90: ");
  for(x=0;x<25;x++){
    printf("");
    scanf("%d", &n);
    printf("%c", n);
  }
*/
}
