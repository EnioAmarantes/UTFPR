/*
4. Fa�a um programa que leia um vetor K[30].
Troque a seguir, todos os elementos de ordem �mpar do
vetor com os elementos de ordem par imediatamente
posteriores.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  srand(time(NULL));
  int k[30], i, aux;
//preenche o vetor k com n�meros rand�micos
  for(i = 0;i < 30;i = i + 1)
    k[i] = rand()/1000;

//mostra o conte�do do vetor k na tela
  printf("\nVetor K\n");
  for(i = 0;i < 30;i = i + 1)
    printf("%d ",k[i]);
  printf("\n");

//percorre o vetor realizando a troca com um �ndice
  for(i = 0;i < 30 - 1;i = i + 2){
    aux = k[i];
    k[i] = k[i + 1];
    k[i + 1] = aux;
  }
//mostra o conte�do do vetor k na tela
  printf("\nVetor k\n");
  for(i = 0;i < 30;i = i + 1)
    printf("%d ",k[i]);
  printf("\n");

  return 0;
}
