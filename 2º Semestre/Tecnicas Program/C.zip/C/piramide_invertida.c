#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int x, y, n, i;
	do{
		printf("\nDigite um n�mero inteiro �mpar: ");
		scanf("%d",&n);				
	}while (n % 2 == 0);
	for(x = 1;x <= (n + x) / 2;x++){
		for(y = x;y <= n;y++)
			printf("%4d",y);
		printf("\n");
		for(i = 1;i <= x;i++)
			printf("    ");
		n = n - 1;
	}	
	return 0;
}