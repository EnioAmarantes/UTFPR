/*
14. Fa�a um procedimento que recebe, por par�metro, a hora de inicio
e a hora de t�rmino de um jogo, ambas subdivididas em 2 valores distintos:
horas e minutos. O procedimento deve retornar, tamb�m por par�metro,
a dura��o do jogo em horas e minutos, considerando que o tempo m�ximo
de dura��o de um jogo � de 24 horas e que o jogo pode come�ar em um dia e
terminar no outro.
*/
#include <stdio.h>
void calcula_tempo(int hi, int mi, int hf, int mf, int *ht, int *mt)
{
   int dif;
   dif = (hi * 60 + mi) - (hf * 60 + mf);
   if (dif > 0){
      dif = 1440 - dif;
      *ht = dif / 60;
      *mt = dif % 60;
   }
   if (dif < 0){
      dif = dif * -1;
      *ht = dif / 60;
      *mt = dif % 60;
   }
   if (dif == 0){
      *ht = 24;
      *mt = 0;
   }
}
int main(){
  int h1, m1, h2, m2, *h3 = 0, *m3 = 0;
  printf("Digite o horario inicial do jogo no formato HH:MM ");
  scanf("%d:%d",&h1,&m1);
  printf("Digite o horario final do jogo no formato HH:MM ");
  scanf("%d:%d",&h2,&m2);
  calcula_tempo(h1,m1,h2,m2,&h3,&m3);
  printf("\nO tempo de duracao do jogo foi de %d horas e %d minutos\n",h3,m3);
  return 0;
}


