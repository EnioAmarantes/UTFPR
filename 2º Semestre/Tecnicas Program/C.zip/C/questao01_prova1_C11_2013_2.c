#include <stdio.h>
#include <math.h>
main(){
  float x;
  printf("Digite um numero: ");
  scanf("%f", &x);
  if (x <= 1)
    printf("A imagem de %2.2f e 1\n", x);
    else
      if (x <= 2)
        printf("A imagem de %2.2f e 2\n", x);
        else
          if (x <= 5)
            printf("A imagem de %2.2f e %2.2f\n", x, pow(x,2.0));
            else
              printf("A imagem de %2.2f e %2.2f\n", x, pow(x,3.0));
   system("pause");
}
