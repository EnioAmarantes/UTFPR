#include <stdio.h>
#include <string.h>
main(){



}
