#include <stdio.h>
#define tam 10000

main()
{
  int s[6], acertos[tam], j[tam][6], q[60], x, i, k, z, achou, n;
  float valor, v4, v5, v6;

  srand(time(NULL));
  for(i = 0; i < 6; i++)
    s[i] = 0;
  i = 0;
  achou = 0;
//preenche o vetor do sorteio
  while (i < 6){
    do{
      x = rand()/100;
    }while (x > 60);
    if ((i == 0) && (x != 0))
        {
          s[i] = x;
          i = i + 1;
        }
      if ((i > 0) && (x != 0))
        {
          achou = 0;
          for(k = 0; k <= i; k++)
            {
              if (s[k] == x)
                achou = 1;
            }
        }
      if ((achou == 0) && (i > 0))
        {
          s[i] = x;
          i = i + 1;
        }
    }
    printf("\n\nnumeros sorteados:");
    for(i = 0; i < 6; i++)
      printf("%d ", s[i]);
    printf("\n");
    system("pause");

//preenche a matriz de jogos
    i = 0; //linha da matriz
    while (i < tam)
      {
        k = 0; //coluna matriz
        while (k < 6)
		{
            do{
              x = rand()/1000;
            }while (x > 60);
            if ((k == 0) && (x != 0)){
                j[i][k] = x;
                k = k + 1;
            }
            if ((k > 0) && (x != 0))
              {
                achou = 0;
                for(z = 0; z <= k; z++) //z � utilizado para percorrer a linha da matriz como se fosse um vetor e procurar numeros repetidos
                  {
                    if (j[z][k] == x)
                      achou = 1;
                  }
              }
            if ((achou == 0) && (k > 0))
              {
	  	      j[i][k] = x;
                k = k + 1;
              }
            if (k == 1)
              k = k + 1;
		}
        i = i + 1;
      }
//    j[1001,1] := -1;
    printf("\nnumeros jogados:");
    for(i = 0; i < tam; i++)
      {
        printf("\n%2d - ", i);
        for(k = 0; k < 6; k++)
          printf("%2d ",j[i][k]);
	 }
    printf("\n");
    system("pause");
/*
{d)Verificar e mostrar quantas vezes cada n�mero (de 01 a 60) foi repetido na totalidade dos jogos realizados,
gravando estes dados num vetor Q de sessenta (60) posi��es onde a posi��o 1 representa o n�mero 01,
a posi��o 2 representa o n�mero 02 e assim sucessivamente;}*/
    for(n = 0;n < 60;n++)
      for(i = 0; i < tam; i++)
        for(k = 0;k < 6; k++)
           if (j[i][k] == n)
		    q[n] = q[n] + 1;
    printf("\nletra d - quantidade de vezes em cada n�mero foi jogado:\n");
    for(n = 0;n < 60;n++){
      printf("\n%d -> %d",n,q[n]);
//	   if (n % 10 == 0)
//         system("pause");
	 }
/*
//e)Verificar e mostrar qual foi o n�mero que mais foi jogado;
   n := q[1]; //inicializao N com o primeiro valor do vetor
   k := 1;    //armazena a posi��o do valor N no vetor
   for i := 2 to 60 do
     if n < q[i] then
	  {
	    n := q[i];  //se N for menor do que o valor na posi��o atual do vetor
	    k := i;     //ent�o N recebe este valor e K armazena sua posi��o
	  };
   writeln;
   writeln('O n�mero ',k,' foi jogado ',n, ' vezes');
   readkey;
//f)Verificar e mostrar qual foi o n�mero que menos foi jogado;
   n := 1001; //inicializao N com um valor para compara��o
   for i := 1 to 60 do
     if ((n > q[i]) and (q[i] > 0)) then
       {
	    n := q[i];  //se N for maior do que o valor na posi��o atual do vetor
	    k := i;     //ent�o N recebe este valor e K armazena sua posi��o
       };
   writeln;
   writeln('O n�mero ',k,' foi jogado ',n, ' vezes');
   readkey;
{g)Verificar e mostrar qual ou quais os n�meros que n�o foram jogados.
Caso negativo, informar que todos os n�meros, de 01 a 60, foram jogados; (1,5)}
   writeln;
   n := 0;
   for i := 1 to 60 do
     {
  	  if q[i] = 0 then
         {
           writeln('o n�mero ',i,' n�o foi jogado');
           n := 1;
         };
     };
     if n = 0 then
       {
         writeln;
         writeln('todos o n�meros de 01 a 60 foram jogados');
       };
    readkey;
{a)Verificar e mostrar quantos jogos acertaram seis (06) dezenas;
b)Verificar e mostrar quantos jogos acertaram cinco (05) dezenas;
c)Verificar e mostrar quantos jogos acertaram quatro (04) dezenas;}
    for i := 1 to tam do //i percorre todas as linhas da matriz de jogos
      {
        x := 0;
	   for n := 1 to 6 do //n percorre o vetor sorteio
          {
		  for k := 1 to 6 do //k percorre as colunas de cada linha da matriz de jogos
              if j[i,k] = s[n] then
                 x := x + 1;
            acertos[i] := x;
	     };
	 };
   writeln;
   for i := 1 to tam do
     writeln('o jogo ',i,' acertou ',acertos[i], ' no sorteio');
    readkey;
{h)	Verificar e mostrar quanto cada acertador ir� receber, considerando a seguinte propor��o
(informar caso n�o existam ganhadores para algum dos casos - isto �, se o pr�mio foi acumulado para a pr�xima extra��o):
85% do valor do pr�mio: dividido entre os jogadores que acertaram seis (06) dezenas;
10% do valor do pr�mio: dividido entre os jogadores que acertaram cinco (05) dezenas;
5% do valor do pr�mio: dividido entre os jogadores que acertaram quatro (04) dezenas;}
   writeln;
   writeln('informe o valor total do pr�mio: ');
   readln(valor);
   v4 := valor * 0.05;
   v5 := valor * 0.10;
   v6 := valor * 0.85;
   x := 0; //contador para quantidade de 04 acertos;
   k := 0;//contador para quantidade de 05 acertos;
   z := 0;//contador para quantidade de 06 acertos;
   for i := 1 to tam do
     {
       if acertos[i] = 4 then
          x := x + 1;
       if acertos[i] = 5 then
          k := k + 1;
       if acertos[i] = 6 then
          z := z + 1;
     };
   writeln;
   if z = 0 then
     writeln('n�o houve ganhadores para 06 dezenas')
	else
	  writeln('houve ',z,' ganhadores para 06 dezenas, e cada um receber� como premio o valor de ',v6/z:2);
   if k = 0 then
     writeln('n�o houve ganhadores para 05 dezenas')
	else
	  writeln('houve ',k,' ganhadores para 05 dezenas, e cada um receber� como premio o valor de ',v5/k:2);
   if x = 0 then
     writeln('n�o houve ganhadores para 04 dezenas')
	else
	  writeln('houve ',x,' ganhadores para 04 dezenas, e cada um receber� como premio o valor de ',v4/x:2);

   readkey;
}.
*/
}
