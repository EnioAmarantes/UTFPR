#include <stdio.h>

main(){
  double soma, y;
  int c;

  c = 1;
  soma = 0;
  y = 1;

  while (c <= 64){
    soma = soma + y;
    y = y * 2;
    c = c + 1;
  }
  printf("%f", soma);



}
