#include <stdio.h>

int primo(n) int n;
  {
   int x, p;
   p = 0;
   x = n;
   while (x >= 1) {
     if (n % x == 0)
       p++;
     x--;
   }
   if ((p == 2) && (n % 2 == 0))
     return 1;  //retorna 1 quando for primo e par
     else
       if ((p == 2) && (n % 2 != 0))
         return 2;  //retorna 2 quando for primo e �mpar
         else
           if ((p != 2) && (n % 2 == 0))
             return 3;  //retorna 3 quando for nao primo e par
             else
               if ((p != 2) && (n % 2 != 0))
                 return 4;  //retorna 4 quando for nao primo e �mpar
   }

main(){
  int n;
  printf("digite um numero para verificar se o mesmo e primo: ");
  scanf("%d", &n);
  if (primo(n) == 1)
     printf("\no numero %d e primo e par", n);
     else
       if (primo(n) == 2)
          printf("\no numero %d e primo e impar", n);
          else
            if (primo(n) == 3)
              printf("\no numero %d nao e primo e eh par", n);
              else
                printf("\no numero %d nao e primo e eh impar", n);
}
