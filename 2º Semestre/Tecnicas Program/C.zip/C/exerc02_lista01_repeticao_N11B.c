/*
02 � Calcular a m�dia final obtida por um grupo de 22 alunos,
para 4 notas bimestrais.
*/
#include <stdio.h>
#include <locale.h>
#define Q 2
int main(){
  setlocale(LC_ALL,"Portuguese");
  float n1, n2, n3, n4, media, soma;
  int x, cont;
  cont = 1;
  soma = 0;
  while (cont <= Q)
  {
     printf("\nDigite as 4 notas do %d� aluno separadas por / ",cont);
     scanf("%f/%f/%f/%f",&n1,&n2,&n3,&n4);
/*
     printf("Digite a 1� nota do %d� aluno: ",cont);
     scanf("%f",&n1);
     printf("Digite a 2� nota do %d� aluno: ",cont);
     scanf("%f",&n2);
     printf("Digite a 3� nota do %d� aluno: ",cont);
     scanf("%f",&n3);
     printf("Digite a 4� nota do %d� aluno: ",cont);
     scanf("%f",&n4);
*/
     media = (n1 + n2 + n3 + n4) / 4;
     soma = soma + media;
     printf("\nA m�dia do %d aluno � %2.2f",cont,media);
     cont = cont + 1;
  }
  printf("\nA m�dia da turma � %2.2f",soma/Q);
  return 0;
}
