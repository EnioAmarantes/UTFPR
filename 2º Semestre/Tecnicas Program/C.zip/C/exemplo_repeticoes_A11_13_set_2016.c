#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
int main(){
  int a, n;
  setlocale(LC_ALL,"Portuguese");
  
//este la�o DO-WHILE obriga a leitura para a vari�vel n
//de um n�mero que seja �mpar e positivo  
  do{
    printf("Digite um n�mero �mpar e positivo: ");
    scanf("%d",&n);
  }while ((n < 0) || (n % 2 == 0)); 

  
  a = 1; //inicializa��o do contador 
  printf("\nTABUADA COM WHILE (enquanto a condi��o for verdadeira, fa�a)\n");
  while (a <= 10){ //condi��o de parada do la�o de repeti��o 
    printf("\n%d X %d = %d",n,a,a*n);
    a = a + 1; //incremento do contador para atingir a condi��o de parada
  }
  
  printf("\nTABUADA COM DO-WHILE (fa�a - enquanto a condi��o for verdadeira)\n");  
  a = 1; //inicializa��o do contador 
  do{
	  printf("\n%d X %d = %d",n,a,a*n);
	  a = a + 1;//incremento do contador para atingir a condi��o de parada
  }while (a <= 10);//condi��o de parada do la�o de repeti��o 
  
  printf("\nTABUADA COM FOR (la�o contado)\n");  
  for(a = 1;a <= 10;a = a + 1)
    printf("\n%d X %d = %d",n,a,a*n);
//for(inicializa��o do contador;condi��o de parada;incremento do contador)

  return 0;
}
 