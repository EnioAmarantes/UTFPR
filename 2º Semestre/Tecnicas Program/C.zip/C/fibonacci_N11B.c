#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int t1, t2, t3, qt, cont;
  printf("\nInforme a quantidade de termos para a s�rie de Fibonacci: ");
  scanf("%d",&qt);
  t1 = 1;
  t2 = 1;
  printf("%d %d ",t1,t2);
  cont = 2;
  while (cont < qt)
  {
     t3 = t1 + t2;
     printf("%d ",t3);
     cont = cont + 1;
     t1 = t2;
     t2 = t3;
  }
  return 0;
}
