#include <stdio.h>
#include <math.h> // necess�rio para raiz
#define NMAX 10000 // valor m�ximo para o valor m�ximo
main() {
    int i, j, vetor[NMAX];
    int valorMaximo, raiz;    // Primeiro passo
    scanf("%d", &valorMaximo);    // Segundo passo
    raiz=sqrt(valorMaximo);    // Terceiro passo
    for (i=2; i<=valorMaximo; i++) {
        vetor[i]=i;
    }    // Quarto passo
    for (i=2; i<=raiz; i++) {
        if (vetor[i]==i) {
            printf("%d ", i);
            for (j=i+i; j<=valorMaximo; j+=i) {
                vetor[j]=0; // removendo da lista
            }
        }
    }
}
