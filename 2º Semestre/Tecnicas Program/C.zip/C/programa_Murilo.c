#include <stdio.h>
main(){

int a[7],i,j,x,n,par,impar, b[7]; //VOC� DEVE COPIAR OS VALORES DO VETOR a PARA O VETOR b, CASO CONTR�RIO VOC� IRPA SOBREPOR OS VALORES DENTRO DO MESMO VETOR, CORRETO??

for(i=0;i<7;i++)
  a[i]=0; //zerar vetor , iniciar preenchimento com posi��o zerada

i=0;

while(i<7)
{
  printf("Informe o valor INTEIRO para a %d posicao : ",i+1);
  scanf("%d",&x);//indexar valor ao vetor

  n=0;//parametro para nao repetir

  for(j=0;j<i;j++)//percorrer todo o vetor para compara��o
    if((a[j]==x) && (x<0))
      n=1;

  if((n==0) && (x!=0) && (x>0))
  {
    a[i]=x;
    i++;
  }
}//fechando condi��o while , preenchimento do vetor sem repeti��o

printf("Vetor A\n");
i=0;
for(i=0;i<7;i++)
  printf(" %d",a[i]);

printf("\n\n");

par=0;
impar=6;  //ESTE �NDICE DEVE SER INICIALIZADO EM 6, E N�O EM 7, UMA VEZ QUE O VETOR � INDEXADO DE ZERO A SEIS (TAMANHO 7)...

for(i=0;i<7;i++)
  if(a[i]%2==0)
  {
    b[par]=a[i];   //VOC� DEVE COPIAR OS VALORES DO VETOR a PARA O VETOR b, CASO CONTR�RIO VOC� IRPA SOBREPOR OS VALORES DENTRO DO MESMO VETOR, CORRETO??
    par++;
  }
  else
  {
    b[impar]=a[i]; //VOC� DEVE COPIAR OS VALORES DO VETOR a PARA O VETOR b, CASO CONTR�RIO VOC� IRPA SOBREPOR OS VALORES DENTRO DO MESMO VETOR, CORRETO??
    impar--;
  }

printf("Vetor B\n");

for(i=0;i<7;i++)
  printf(" %d",b[i]); //....

}
