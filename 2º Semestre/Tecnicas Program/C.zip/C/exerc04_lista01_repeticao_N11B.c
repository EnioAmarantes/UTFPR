/*
04 � Calcular o volume de um cilindro.
Perguntar ao usu�rio se h� outros c�lculos a
serem realizados para continuar ou n�o o algoritmo.
*/
#include <stdio.h>
#include <locale.h>
#include <math.h>
#define Q 2
int main(){
  setlocale(LC_ALL,"Portuguese");
  float r, h, vol;
  int controle;
  controle = 1;
  while (controle == 1)
  {
     printf("Digite o raio do cilindro: ");
     scanf("%f",&r);
     printf("Digite a altura do cilindro: ");
     scanf("%f",&h);
     vol = 2 * M_PI * pow(r,2.0) * h;
     printf("\nO volume do cilindro � %2.2f",vol);
     printf("\nDeseja continuar? 1 para sim ou 0 para n�o ");
     scanf("%d",&controle);
  }
  return 0;
}
