#include <stdio.h>
#define I 15
#define L 15
#define C 4
main(){
  int IMPAR[I], R[L][C], x, p, i, j, n, l, c, np1, np2, np3, NP1, NP2, NP3, OK;
//  preenche vetor
  for(i = 0; i <= I; i++)
    IMPAR[i] = 0;
  i = 0;
  srand(time(NULL));
  while (i <= I){
    do{
      x = rand();
    }while ((x <= 5) || (x % 2 == 0));
    n = 0;
    for(j = 0; j < i; j++)
      if (IMPAR[j] == x)
        n = 1;
    if (n == 0) {
      IMPAR[i] = x;
      i++;
    }
  }
//  mostra vetor
  printf("\n\nVetor IMPAR\n\n");
  for(i = 0; i < I; i++)
    printf("%d ",IMPAR[i]);
  printf("\n");
//------------------
  srand(time(NULL));
  i = 0;
  while (i < L){
    OK = 0;
    do{
//gera primeiro n�mero primo
      do{
       NP1 = 0;
       np1 = rand();
       p = 0;
       x = np1;
       while (x >= 1) {
         if (np1 % x == 0)
           p++;
         x--;
       }
       if (p == 2)
         NP1 = 1;
      }while ((np1 > IMPAR[i]) || (np1 % 2 == 0) || (NP1 == 1));
//gera segundo n�mero primo
      do{
       NP2 = 0;
       np2 = rand();
       p = 0;
       x = np2;
       while (x >= 1) {
         if (np2 % x == 0)
           p++;
         x--;
       }
       if (p == 2)
         NP2 = 1;
      }while ((np2 > np1) || (np2 % 2 == 0) || (NP2 == 1));
//gera terceiro n�mero primo
      do{
       NP3 = 0;
       np3 = rand();
       p = 0;
       x = np3;
       while (x >= 1) {
         if (np3 % x == 0)
           p++;
         x--;
       }
       if (p == 2)
         NP3 = 1;
      }while ((np3 > np2) || (np3 % 2 == 0) || (NP3 == 1));

      if ((np1 + np2 + np3 == IMPAR[i]) && (np1 != np2) && (np2 != np3)){
        R[i][0] = IMPAR[i];
        R[i][1] = np1;
        R[i][2] = np2;
        R[i][3] = np3;
        printf("\n%2d --> %4d = %4d + %4d + %4d",i,R[i][0],R[i][1],R[i][2],R[i][3]);
        i = i + 1;
        OK = 1;
       }
    }while (!(OK));
  }
//------------------
//mostra matriz
  printf("\n\nMatriz R\n\n");
  for(l = 0; l < L; l++){
    for(c = 0; c < C; c++)
      printf("%5d ",R[l][c]);
    printf("\n");
  }
  printf("\n\n");
 //----------------------
}
