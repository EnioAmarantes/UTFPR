#include <stdio.h>
#include <math.h>

  float triangulo(base, altura) float base, altura;
    {
      if ((base > 0) && (altura > 0))
        return (base * altura / 2);
        else
          return 0;
    }

  float cubo(lado) float lado;
    {
      if (lado > 0)
        return (lado * lado);
        else
          return 0;
    }

  float circulo(raio) float raio;
    {
      if (raio > 0)
        return (3.14 * pow(raio,2.0));
        else
          return 0;
    }

  float cilindro(raio, altura) float raio, altura;
    {
      if ((raio > 0) && (altura > 0))
        return (2.0 * (3.14 * pow(raio,2.0)) + (2 * 3.14 * raio * altura)) ;
        else
          return 0;
    }

  main(){
    float x, y, R;
    int op;
    printf("\nescolha uma das opcoes\n\n1 - area de um triangulo\n2 - area de um circulo\n3 - area de um cubo\n4 - area de um cilindro\n5 - fim\n") ;
    scanf("%d", &op);

    if (op == 1) {
       printf("\ndigite a base do triangulo: ");
       scanf("%f", &x);
       printf("\ndigite a altura do triangulo: ");
       scanf("%f", &y);
       R = triangulo(x,y);
       if (R == 0)
         printf("\nParametros invalidos para a funcao");
         else
           printf("\nA area do triangulo e %f", R);
    }

    if (op == 2) {
       printf("\ndigite o raio do circulo: ");
       scanf("%f", &x);
       R = circulo(x);
       if (R == 0)
         printf("\nParametros invalidos para a funcao");
         else
           printf("\nA area do circulo e %f", R);
    }

    if (op == 3) {
       printf("\ndigite a o lado do cubo: ");
       scanf("%f", &x);
       R = cubo(x);
       if (R == 0)
         printf("\nParametros invalidos para a funcao");
         else
           printf("\nA area do cubo e %f", R);
    }

    if (op == 4) {
       printf("\ndigite a base do cilindro: ");
       scanf("%f", &x);
       printf("\ndigite a altura do cilindro: ");
       scanf("%f", &y);
       R = cilindro(x,y);
       if (R == 0)
         printf("\nParametros invalidos para a funcao");
         else
           printf("\nA area do cilindro e %f", R);
    }

  }
