#include <stdio.h>
#include <math.h>
float triangulo(float, float);
float cubo(float);
float circulo(float);
float cilindro(float,float);
int main(){
    float x, y, R;
    int op;
    printf("\nescolha uma das opcoes\n\n1 - area de um triangulo\n2 - area de um circulo\n3 - area de um cubo\n4 - area de um cilindro\n5 - fim\n") ;
    scanf("%d", &op);
//IFs simples
    if (op == 1){
      printf("\ndigite a base do triangulo: ");
      scanf("%f", &x);
      printf("\ndigite a altura do triangulo: ");
      scanf("%f", &y);
      if ((x > 0) && (y > 0))
      {
        R = (y * y / 2);
        printf("\nA area do triangulo e %f", R);
      }
        else
           printf("\nParametros invalidos\n");
    }
    if (op == 2) {
      printf("\ndigite o raio do circulo: ");
      scanf("%f", &x);
      if (x <= 0)
        printf("\nParametros invalidos\n");
        else
         {
           R = (M_PI * pow(x,2.0));
           printf("\nA area do circulo e %f", R);
         }
    }
    if (op == 3) {
      printf("\ndigite a o lado do cubo: ");
      scanf("%f", &x);
      if (x <= 0)
        printf("\nParametros invalidos para a funcao");
        else
        {
          R = x * x;
         printf("\nA area do cubo e %f", R);
        }
    }
    if (op == 4) {
      printf("\ndigite a base do cilindro: ");
      scanf("%f", &x);
      printf("\ndigite a altura do cilindro: ");
      scanf("%f", &y);
      if ((x > 0) && (y > 0))
      {
        R = (2.0 * (M_PI * pow(x,2.0)) + (2 * M_PI * x * y)) ;
        printf("\nA area do cilindro e %f", R);
      }
        else
          printf("\nParametros invalidos");
    }
    if ((op != 1) && (op != 2) && (op != 3) && (op != 4))
      printf("\nOp��o incorreta\n");

//SWITCH..CASE
   switch (op){
      case 1:
        printf("\ndigite a base do triangulo: ");
        scanf("%f", &x);
        printf("\ndigite a altura do triangulo: ");
        scanf("%f", &y);
        if ((x > 0) && (y > 0))
        {
          R = (x * y / 2);
          printf("\nA area do triangulo e %f", R);
        }
          else
            printf("\nParametros invalidos\n");
        break;
      case 2:
        printf("\ndigite o raio do circulo: ");
        scanf("%f", &x);
        if (x <= 0)
          printf("\nParametros invalidos\n");
          else
          {
             R = (M_PI * pow(x,2.0));
             printf("\nA area do circulo e %f", R);
          }
        break;
      case 3:
        printf("\ndigite a o lado do cubo: ");
        scanf("%f", &x);
        if (x <= 0)
          printf("\nParametros invalidos para a funcao");
          else
          {
            R = x * x;
            printf("\nA area do cubo e %f", R);
          }
        break;
      case 4:
        printf("\ndigite a base do cilindro: ");
        scanf("%f", &x);
        printf("\ndigite a altura do cilindro: ");
        scanf("%f", &y);
        if ((x > 0) && (y > 0))
        {
          R = (2.0 * (M_PI * pow(x,2.0)) + (2 * M_PI * x * y)) ;
          printf("\nA area do cilindro e %f", R);
        }
          else
            printf("\nParametros invalidos");
       break;
       default:
         printf("\nOp��o incorreta\n");
   }
   return 0;
}
