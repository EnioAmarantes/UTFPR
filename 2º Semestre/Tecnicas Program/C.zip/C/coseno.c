//Quest�o 01 (1,0): 
//Fazer um programa que:
//a)	Calcule o valor do co-seno de x atrav�s de n termos da s�rie seguinte:
//                 x^2   x^4    x^6    x^8
//co-seno(x)= 1 - ---- + ---- - ---- + ---- - ...
//                 2!     4!     6!     8!
//b)	Calcule a diferen�a entre o valor calculado no item a e o valor fornecido pela fun��o COS(X).
//c)	Imprima o que foi calculado nos itens a e b.
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
    float coseno, x, n, fat, f;
	int count, qt, sinal;
	printf("Informe um valor para calcular o coseno: ");
	scanf("%f",&x);
	printf("Informe a quantidade de termos para a s�rie: ");
	scanf("%d",&qt);
	count = 0;
	coseno = 1;
	n = 2;
	sinal = -1;
	while (count < qt){
		fat = n;
		f = fat - 1;
		while (f > 1){
			fat = fat * f;
			f = f - 1;
		}
		coseno = coseno + ((pow(x,n) / fat) * sinal);
		sinal = sinal * -1;
		n = n + 2;
		count = count + 1;
	} 
	printf("\nCoseno a partir de MATH.H (cos(x)) --> %f",cos(x));
	printf("\nCoseno calculado pelo programa ------> %f",coseno);
	return 0;
}