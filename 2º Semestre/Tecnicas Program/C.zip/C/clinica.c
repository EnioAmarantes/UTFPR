#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct{
	char codPaciente[10];
	char nome[70];
	char telefone[11];
	char sexo;
	int idade;
}Paciente;

typedef struct{
	char codMedico[10];
	char nome[70];
	char especialidade[70];
	double valorConsulta;
}Medico;

typedef struct{
	char codPaciente[10];
	char codMedico[10];
	char dataConsulta[10];
	char diaSemana[15];
}Consulta;

int cadastrarMedico(Medico med[] ,int k);
int cadastrarPaciente(Paciente pac[] ,int k);
int cadastrarConsulta(Consulta con[] ,Paciente pac[] , Medico med[],int k);
void relatorio(Consulta con[] ,Paciente pac[] , Medico med[], int k, int nPacientes, int nCon);

main(){

	Medico *med;
	Paciente *pac;
	Consulta *con;
	int op, quant, nM, nC, nP;
	FILE *medico, *paciente, *consulta;

	medico = fopen("medico.dat","r");
	paciente = fopen("paciente.dat","r");
	consulta = fopen("consulta.dat","r");

	if(medico == NULL || paciente == NULL || consulta == NULL){
		nP = 0;
		nC = 0;
		nM = 0;
		quant = 100;
		if(malloc(quant * sizeof(Medico)) == NULL || malloc(quant * sizeof(Paciente)) == NULL || malloc(quant * sizeof(Consulta)) == NULL){
			printf("Memoria insuficiente!");
			exit(1);
		}
		med = malloc(quant * sizeof(Medico));
		pac = malloc(quant * sizeof(Paciente));
		con = malloc(quant * sizeof(Consulta));
	}else{
		fread(&nM,sizeof(int),1,medico);
		fread(&nP,sizeof(int),1,paciente);
		fread(&nC,sizeof(int),1,consulta);

        quant = nP * 2;

		med = (Medico *) malloc(quant * sizeof(Medico));
		pac = (Paciente *) malloc(quant * sizeof(Paciente));
		con = (Consulta *) malloc(quant * sizeof(Consulta));

		fread(med, sizeof(Medico), nM, medico);
		fread(pac, sizeof(Paciente), nP, paciente);
		fread(con, sizeof(Consulta), nC, consulta);

		fclose(medico);
		fclose(paciente);
		fclose(consulta);
	}

	do{
		printf("*** Menu ***\n");
    	printf(" 1 - Cadastrar medico.\n");
    	printf(" 2 - Cadastrar paciente.\n");
    	printf(" 3 - Cadastrar consulta	.\n");
    	printf(" 4 - Exibir relatrio.");
    	printf("-1 - Sair.\n");
		scanf("%d", &op);
		fflush(stdin);

		if(nM == quant || nP == quant || nC == quant){
			quant = nM + 5;
			med = realloc(med, sizeof(Medico) * quant);
			pac = realloc(pac, sizeof(Paciente) * quant);
			con = realloc(con, sizeof(Consulta) * quant);
		}

		switch(op){
			case 1:
				nM = cadastrarMedico(med, nM);
				op = 0;
				break;
			case 2:
				nP = cadastrarPaciente(pac, nP);
				op = 0;
				break;
			case 3:
				nC = cadastrarConsulta(con, pac, med, nC);
				op = 0;
				break;
			case 4:
				relatorio(con, pac, med, nM, nP, nC);
				op = 0;
				break;
			case -1:
				printf("Voce saiu do programa.");
				break;
			default:
				printf("Operacao indisponivel.");
				break;
		}
	}while(op != -1);

}

int cadastrarMedico(Medico med[] ,int k){
	int i = 0, j = 0;

	printf("Cadastro de medico::\n");

	do{
		j = 1;

		printf("\nDigite o codigo do %d medico:\n", k+1);
		gets(med[k].codMedico);
		fflush(stdin);
		for(i = 0; i < k; i++)
			if(strcmp(med[i].codMedico, med[k].codMedico))
				j = 0;

	}while(j == 0);

	printf("Digite o nome do %d medico:\n", k+1);
	gets(med[k].nome);
	fflush(stdin);

	printf("Digite a especialidade do %d medico:\n", k+1);
	gets(med[k].especialidade);
	fflush(stdin);

	printf("Digite o valor da consulta do %d medico:\n", k+1);
	scanf("%f",&med[k].valorConsulta);
	fflush(stdin);

	return ++k;
}

int cadastrarPaciente(Paciente pac[] ,int k){
	int i = 0, j = 0;

	if(k == 50){
		printf("Nao pode ser cadastrada mais consultas.");
		exit(1);
	}

	printf("Cadastro de paciente::\n");

	printf("Digite o codigo do %d paciente:\n", k+1);
	gets(pac[k].nome);
	fflush(stdin);

	printf("Digite o codigo do %d medico:\n", k+1);
	gets(pac[k].nome);
	fflush(stdin);

	printf("Digite a telefone do %d paciente:\n", k+1);
	gets(pac[k].telefone);
	fflush(stdin);

	do{
		printf("Sexo::\n F - Feminino\n M - Masculino");
		printf("Digite o sexo do paciente: ");
		scanf("%c",&pac[k].sexo);
	}while(!(pac[k].sexo == 'F') || !(pac[k].sexo == 'f') || !(pac[k].sexo == 'M') ||!(pac[k].sexo == 'm'));

	printf("Digite a idade do %d paciente:\n", k+1);
	scanf("%d", &pac[k].idade);
	fflush(stdin);

	return ++k;
}

int cadastrarConsulta(Consulta con[] ,Paciente pac[] , Medico med[],int k){
	int i = 0, j = 0, nAten = 0;
	printf("Cadastro de consulta::\n");
	do{
		j = 0;

		printf("\nDigite o codigo do medico: \n");
		gets(con[k].codMedico);
		fflush(stdin);
		for(i = 0; i < k; i++)
			if(strcmp(con[k].codMedico, med[i].codMedico)){
				j = 1;
				nAten++;
			}
	}while(j == 0);

	do{
		j = 0;

		printf("\nDigite o codigo do paciente: \n");
		gets(con[k].codPaciente);
		fflush(stdin);
		for(i = 0; i < k; i++)
			if(strcmp(con[k].codPaciente, con[i].codPaciente))
				j = 1;
	}while(j == 0);

	printf("Digite a data da consulta:\n");
	gets(con[k].dataConsulta);
	fflush(stdin);

	j = 0;
	for(i = 0; i < k; i++){
		if(strcmp(con[k].codMedico,con[i].codMedico)){
			j++;
			if(j == 2)
				printf("O medico nao pode ter mais de uma consulta por dia.");
				k--;
		}
	}

	if(!(j <= 2)){
		printf("Digite o dia da semana em que vai cair esta data:\n");
		gets(con[k].diaSemana);
		fflush(stdin);
	}

	return ++k;
}

void relatorio(Consulta con[] ,Paciente pac[] , Medico med[], int k, int nPacientes, int nCon){
	int i, j, l;

	for(i = 0; i < k; i++){
		printf("O medico %s com especialidade em %s atendeu os pacientes:\n", med[i].nome, med[i].especialidade);
		for(j = 0; j < nCon; j++)
			if(strcmp(con[j].codMedico, med[i].codMedico))
				for(l = 0; l < nPacientes; l++)
					if(strcmp(con[j].codPaciente,pac[l].codPaciente))
						printf("%s\n",pac[l].nome);
	}

}
