#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
int main(){
  setlocale(LC_ALL,"Portuguese");



   int c;

   printf( "Enter a value :");
   c = getchar( );

   printf( "\nYou entered: ");
   putchar( c );



  return 0;
}
