#include <stdio.h>
int F1(int, int);
F2(int*, int*);
main(){
  int x, y;
  for(x = 3, y = 2; x <= 10; x = x + 1, y = y + 1){
    F2(&x,&y);
    printf("\n%d", x);
    F2(&x,&y);
    printf("\n%d", y);
    printf("\n%d", F1(x,y));
  }
}
int F1(int x, int y){
  x = x * y;
  y = y + x;
  if (x % y == 0)
    return x;
    else
        return y;
}
F2(int *x, int *y){
  if(*x % *y == 0)
    *x = *x + *y;
    else
      *y = *x - *y;
}
