#include <stdio.h>
#include <locale.h>
int nperfeito(int);
int main(){
	int a, b;
	setlocale(LC_ALL,"Portuguese");
	printf("\nVerifica se um n�mero � perfeito ou n�o: ");
	printf("\nDigite o primeiro valor do intervalo: ");
	scanf("%d",&a);
	printf("\nDigite o segundo valor do intervalo: ");
	scanf("%d",&b);
    for(;a <= b;a++){
	  if (nperfeito(a))
		printf("\nO n�mero %d � perfeito",a);
	    else
		  printf("\nO n�mero %d n�o � perfeito",a);	
	}	
    return 0;
}
int nperfeito(int n){
	int s, x;
	s = 0;
	x = n - 1;
	printf("\n");
	while(x >= 1){
		if (n % x == 0){
			s = s + x;
			printf("%d ",x);
		}
		x = x - 1;
	}
    if (s == n)
		return 1;
	else
		return 0;		
}
