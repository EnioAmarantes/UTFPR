#include <stdio.h>
main(){
  int a;

  a = 1;

  printf("%d %d %d %d %d", a, a--, --a, a++, ++a);

}
