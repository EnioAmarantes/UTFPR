#include <stdio.h>
#include <stdlib.h>

main(){
  float n;
  srand(time(NULL));
  do{
    n = rand();
    printf(" n --> %2.2f", n);
  }while (n >= 2000);

  printf("\n\nn --> %2.2f\n\n", n);
}
