#include <stdio.h>
//imprime uma s�rie de 10 numeros na tela
int main(){
  int n, x;
//*******WHILE*******
  n = 1; //(1) iniciliza��o da vari�vel de controle
  x = 1;
  while (n <= 10){ //(2) vari�vel de controle
	  printf("\n%d",n * x); //(3) comandos executados
	  n = n + 1; //(4) altera��o de valor da vari�vel de controle
  }	
//o comando WHILE segue a seguinte sequencia:
//(1)
//(2)
//(3)
//(4)
//ap�s (4) volta para (2), enquanto (2) for verdadeiro
	
//*******DO*******
  n = 1; //(1) iniciliza��o da vari�vel de controle
  x = 1;
  do{
	  printf("\n%d",n * x); //(2) comandos executados
	  n = n + 1; //(3) altera��o de valor da vari�vel de controle
  }	while (n <= 10); //(4) vari�vel de controle
//o comando WHILE segue a seguinte sequencia:
//(1)
//(2)
//(3)
//(4)
//ap�s (4) volta para (2), enquanto (2) for verdadeiro	
	
//*******FOR*******

  x = 1;
//for(n = 1;n <= 10;n = n + 1)  
  for(n = 1;      //(1) iniciliza��o da vari�vel de controle
  	  n <= 10;    //(2) vari�vel de controle
      n = n + 1){ //(4) altera��o de valor da vari�vel de controle
        printf("\n%d",n * x); //(3) comandos executados 
  }	
//o comando FOR segue a seguinte sequencia:
//(1)
//(2)
//(3)
//(4)
//ap�s (4) volta para (2), enquanto (2) for verdadeiro	
	
//*****CUIDADO COM O FOR*****	
//esta � a forma "correta" de utilizar o FOR
  x = 1;
  for(n = 1;n <= 10;n = n + 1){
       printf("\n%d",n * x); 
  }	

//mas o mesmo resultado pode ser obtido da seguinte forma
  for(n = 1, x = 1;n <= 10;printf("\n%d",n * x), n = n + 1);
	
//e ainda podemos fazer "isto":	
  for(;;);  //LOOP INFINITO	
  
	
  return 0;
}