/*
10. Escreva um programa que leia um vetor de 20
posi��es e mostre- o. Em seguida, troque o primeiro
elemento com o �ltimo, o segundo com o pen�ltimo,
o terceiro com o antepen�ltimo, e assim
sucessivamente. Mostre o novo vetor depois da troca.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  srand(time(NULL));
  int a[20], i, j, aux;
//preenche o vetor a com n�meros rand�micos
  for(i = 0;i < 20;i = i + 1)
    a[i] = rand()/1000;

//mostra o conte�do do vetor a na tela
  printf("\nVetor A\n");
  for(i = 0;i < 20;i = i + 1)
    printf("%d ",a[i]);
  printf("\n");
/*
//percorre o vetor realizando a troca com dois �ndices
  for(i = 0, j = 19;i < 10;i = i + 1, j = j - 1){
    aux = a[i];
    a[i] = a[j];
    a[j] = aux;
  }
*/
//percorre o vetor realizando a troca um �ndice
  for(i = 0;i < 10;i = i + 1){
    aux = a[i];
    a[i] = a[20 - 1 - i];
    a[20 - 1 - i] = aux;
  }
//mostra o conte�do do vetor a na tela
  printf("\nVetor A\n");
  for(i = 0;i < 20;i = i + 1)
    printf("%d ",a[i]);
  printf("\n");

  return 0;
}
