//01 - Calcular o pre�o de venda de um carro. 
//O pre�o de venda � formado pelo pre�o da montadora, 
//mais 15% de lucro, mais 11% de IPI, mais 17% de ICM. 
//As porcentagens s�o sobre o pre�o da montadora, que � lido. 
//Informe o pre�o final e o valor dos impostos.
//ENTRADAS -  pre�o da montadora
//SA�DAS - pre�o final, valor dos impostos
//PROCESSAMENTO - lucro = pre�o da montadora * 0.15
//                ipi = pre�o da montadora * 0.11
//                icm = pre�o da montadora * 0.17
//                valor final = pre�o da montadora + lucro + ipi + icm
//                valor dos impostos = ipi + icm
#include <stdio.h>
#include <locale.h>
int main(){
//declara��o de vari�veis   
   float pm, pf, vi, lucro, ipi, icm;
   setlocale(LC_ALL, "Portuguese");  
//entrada de dados   
   printf("Digite o pre�o da montadora: ");
   scanf("%f",&pm); 
//processamento   
   lucro = pm * 0.15;
   ipi = pm * 0.11;
   icm = pm * 0.17;
   pf = pm + lucro + ipi + icm;
   vi = ipi + icm;
//sa�da de dados
   printf("\nO valor dos impostos � de %.2f",vi);  
   printf("\nO valor final do ve�culo � de %.2f",pf);
//   printf("\nO valor do impostos � de %f e o valor final � de %f",vi,pf);
   	
   return 0;
}