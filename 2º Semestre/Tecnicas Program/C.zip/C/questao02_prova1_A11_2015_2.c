//De um modo geral, as liga��es telef�nicas s�o cobradas pelas suas dura��es. O sistema registra os instantes
//em que a liga��o foi iniciada e conclu�da e � acionado um programa que determina o intervalo de tempo decorrido
//entre aqueles dois instantes dados.
//Escreva um programa que receba n entradas, cada uma contendo a hora do in�cio e a hora final de uma liga��o
//(cada hora � composta de tr�s vari�reis inteiras: hora, minuto e segundo). Cada entrada (hora inicial e hora final)
//corresponde a uma chamada/liga��o.
//Calcule e mostre a dura��o de cada chamada (em horas, minutos e segundos), sabendo-se que o tempo m�ximo de dura��o
// de uma chamada � 24 horas, e que o tempo m�nimo � de 1 segundo, e que ela pode iniciar em um dia e terminar no dia seguinte.
//O final das n entradas � determinado quando a hora de in�cio e a hora de fim s�o todas iguais a -1.
//algoritmo "quest�o 02"
#include <stdio.h>
#include <locale.h>
main(){
  setlocale(LC_ALL, "Portuguese");
  int h1, m1, s1, h2, m2, s2, t1, t2, dif;

  do {
    printf("\nIn�cio da liga��o: (-1 em todos os campos para finalizar\n");
    printf("hora: ");
    scanf("%d",&h1);
    printf("minuto: ");
    scanf("%d",&m1);
    printf("segundo: ");
    scanf("%d",&s1);
    printf("\nT�rmino da liga��o: (-1 em todos os campos para finalizar\n");
    printf("hora: ");
    scanf("%d",&h2);
    printf("minuto: ");
    scanf("%d",&m2);
    printf("segundo: ");
    scanf("%d",&s2);
    dif = (h1 *3600 + m1 * 60 + s1) - (h2 *3600 + m2 * 60 + s2);
    if (dif < 0){
      dif = dif * -1;
     printf("\nTempo: %d h %d m %d s",dif / 3600, dif % 3600 / 60, dif % 3600 % 60);
    }
      else
        if (dif > 0){
          dif = 86400 - dif;
          printf("\nTempo: %d h %d m %d s",dif / 3600, dif % 3600 / 60, dif % 3600 % 60);
        }
          else
            if ((dif=0)&&(h1!=-1)&&(m1!=-1)&&(s1!=-1)&&(h2!=-1)&&(m2!=-1)&&(s2!=-1))
              printf("\nTempo total da liga��o: 24 horas\n");
   }while ((h1!=-1)&&(m1!=-1)&&(s1!=-1)&&(h2!=-1)&&(m2!=-1)&&(s2!=-1));
}
