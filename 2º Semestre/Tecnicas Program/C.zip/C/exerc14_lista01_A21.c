/*
14 � Obter dois n�meros quaisquer, e informar:
     a) a soma destes n�meros;
     b) a subtra��o destes n�meros;
*/
#include <stdio.h>
main(){

  float a, b;
/*
  printf("Digite o primeiro numero: ");
  scanf("%f",&a);
  printf("Digite o segundo numero: ");
  scanf("%f",&b);
*/
  srand((unsigned)time(NULL));
  a = rand()/100;
  b = rand()/100;
  printf("\nA soma de %2.2f e %2.2f e igual a %2.2f", a, b, a+b);
  printf("\nA subtracao de %2.2f e %2.2f e igual a %2.2f\n\n",a, b, a-b);
  system("pause");
}
