#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, a, b;

  for(n = 0000;n <= 9999;n = n + 1){
    a = n / 100;
    b = n % 100;
    if ((a + b) * (a + b) == n)
       printf("\n%02d + %02d = %04d",a,b,n);
  }

  return 0;
}
