#include <stdio.h>
#include <math.h>
main(){
  float n;
  printf("informe um numero: ");
  scanf("%f",&n);
  printf("\na raiz quadrada de %f eh ", pow(n,0.5));
  if (((pow(n,0.5) - (trunc(pow(n,0.5)))) == 0 ))
    printf ("\n.o numero inteiro que mais se aproxima da raiz quadrada de %0.2f eh %.0f", n,trunc(pow(n,0.5)));
    else if ((trunc((pow(n,0.5) - trunc(pow(n,0.5)))*10))  <= 4)
      printf ("\n..o numero inteiro que mais se aproxima da raiz quadrada de %0.2f eh %.0f", n,trunc(pow(n,0.5)));
      else
        printf ("\n...o numero inteiro que mais se aproxima da raiz quadrada de %0.2f eh %.0f", n,trunc(pow(n,0.5))+1);
}


