/*
Fa�a um algoritmo que receba o itiner�rio de uma viagem entre estas cidades (considere qualquer itiner�rio e tamb�m a
repeti��o de trechos entre as cidades com um m�ximo de 15 trechos percorridos), armazenados em um vetor da seguinte
forma (este vetor deve receber os dados do itiner�rio e o algoritmo deve permitir somente a digita��o dos c�digos que
existem no vetor de cidades).
mostre um relat�rio da seguinte forma:
Cidade	        quilometragem percorrida
Londrina
Ibipor�	                 15
Maring�	                105
Curitiba	            486
*/
#include <stdio.h>
#include <stdlib.h>

struct cidade{
 char nome[50];
 int q;
};
typedef struct cidade CID;

struct Node{
	int cod;
	struct Node *prox;
};
typedef struct Node node;

void insereFim(node *ITI, int n);
void libera(node *ITI);
void conta_cidades(CID[], node *ITI);
void exibe(node *ITI);
int **gerar_matriz(int, int);

int main(){

  int **m;  /* matriz a ser alocada */
  int r = 0, q = 0, i = 1, soma = 0, linha, coluna, x, cidade;
  CID *cid;

  printf("\nQuantas cidades existem em seu itinerario? ");
  scanf("%d", &q);
  if ((malloc(q * sizeof (CID)) == NULL)){
    printf("sem espa�o de mem�ria");
    exit(1);
  }
  cid = malloc(q * sizeof (CID));
  for(i = 0;i < q; i++){
    printf("Digite o nome da cidade %d ", i+1);
    fflush(stdin);
    gets(cid[i].nome);
    cid[i].q = 0;
  }

  m = gerar_matriz(q, q);

  printf("\nPreenchimento da matriz de dist�ncias: \n");
  for(linha = 0;linha < q;linha++)
    for(coluna = 0;coluna < linha;coluna++){
       printf("Informe a distancia entre %s e %s ", cid[coluna].nome, cid[linha].nome);
       scanf("%d",&m[coluna][linha]);
       m[linha][coluna] = m[coluna][linha];
    }

  printf("\nEsta eh a matriz de dist�ncias: \n");
  for(linha = 0;linha < q;linha++){
    for(coluna = 0;coluna < q;coluna++)
       printf("%5d ", m[linha][coluna]);
    printf("\n");
  }

  node *ITI = (node *)malloc(sizeof(node));

  if(!ITI){
	printf("Sem memoria disponivel!\n");
	exit(1);
  }

  ITI->prox = NULL;

  i = 1;
  while (r == 0){
     printf("Digite o codigo da %d cidade do itinerario (-1 finaliza): \n", i);
     for(x = 0;x < q;x++)
        printf("%d - %s\n",x, cid[x].nome);
     do{
       scanf("%d", &cidade);
     }while((cidade < 0) || (cidade > q-1));
     if (cidade == -1)
       r = 1;
       else
         if ((cidade < 0) || (cidade > q)){
           printf("\nO codigo deve estar entre 0 e 4!\n");
         }
         else{
           insereFim(ITI, cidade);
           i++;
         }
  }
  printf("\nItinerario percorrido: \n");
  exibe(ITI);
  printf("\n\ncidade\tkm percorrida\t km acumulada\n\n");
  node *temp1, *temp2;
  temp1 = ITI->prox;
  printf("%s\n", cid[temp1->cod].nome);
  temp2 = temp1->prox;
  while (temp2 != NULL){
    soma = soma + m[temp1->cod][temp2->cod];
    printf("%s    \t%5d\t\t%5d\n", cid[temp2->cod].nome,m[temp1->cod][temp2->cod],soma);
    temp1 = temp1->prox;
    temp2 = temp1->prox;
   }
  printf("\n\nKm total \t%5d\n\n", soma);
  conta_cidades(cid, ITI);
  return 0;
}

void insereFim(node *ITI, int n){
	node *novo=(node *) malloc(sizeof(node));
	if(!novo){
		printf("Sem memoria disponivel!\n");
		exit(1);
	}
	novo->cod = n;
	novo->prox = NULL;
    if(ITI->prox == NULL)
		ITI->prox = novo;
	else{
		node *temp = ITI->prox;
		while(temp->prox != NULL)
			temp = temp->prox;
		temp->prox = novo;
	}
}

void libera(node *ITI){
	if(ITI->prox == NULL){
		node *proxNode, *atual;
		atual = ITI->prox;
		while(atual != NULL){
			proxNode = atual->prox;
			free(atual);
			atual = proxNode;
		}
	}
}

void conta_cidades(CID c[], node *ITI){
  int j;
  node *temp;
  temp = ITI->prox;
  while(temp != NULL){
	c[temp->cod].q += 1;
	temp = temp->prox;
  }
  for(j = 0; j < 5;j++)
    printf("%s   \t%2d\n",c[j].nome, c[j].q);
}

void exibe(node *ITI){
	if(ITI->prox == NULL){
      printf("Lista vazia!\n\n");
      return ;
	}
	node *temp;
	temp = ITI->prox;
	while(temp != NULL){
		printf("%2d", temp->cod);
		temp = temp->prox;
	}
	printf("\n\n");
}

int **gerar_matriz(int linhas, int colunas)
{
  int **v;  /* ponteiro para a matriz */
  int   i, j;    /* variavel auxiliar      */
  if (linhas < 1 || colunas < 1) { /* verifica parametros recebidos */
     printf ("** Erro: Parametro invalido **\n");
     return (NULL);
     }

  /* aloca as linhas da matriz */
  v = (int**) malloc(linhas * sizeof(int*));

  if (v == NULL) {
     printf ("** Erro: Memoria Insuficiente **");
     return (NULL);
     }
  /* aloca as colunas da matriz */
  for (i = 0; i < linhas; i++ ) {
      v[i] = (int*) malloc (colunas * sizeof(int));
      if (v[i] == NULL) {
         printf ("** Erro: Memoria Insuficiente **");
         return (NULL);
         }
      }

  for(i = 0;i < linhas; i++)
    for(j = 0;j < colunas; j++)
       v[i][j] = 0;

  return (v); /* retorna o ponteiro para a matriz */
}
