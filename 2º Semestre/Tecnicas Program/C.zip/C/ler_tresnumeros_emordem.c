#include <stdio.h>
#include <locale.h>
void troca(int *a,int *b){
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
}
int main(){
	setlocale(LC_ALL,"Portuguese");
    int n1, n2, n3;
    n1 = 34;
    n2 = 27;
    n3 = 7;
    printf("\nantes - n1 %d  n2 %d  n3 %d",n1,n2,n3);	   

    if (n1 > n2)
		troca(&n1,&n2);
	if (n2 > n3)
		troca(&n2,&n3);
    if (n1 > n2)
    	troca(&n1,&n2);
    
    printf("\ndepois - n1 %d  n2 %d  n3 %d",n1,n2,n3);	 
      
    return 0;          
}