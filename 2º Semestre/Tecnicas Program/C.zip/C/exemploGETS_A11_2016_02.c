#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
int main(){
	char nome[50], rua[50], cidade[40], estado[3];
	int idade;
	setlocale(LC_ALL,"Portuguese");
	printf("\nDigite o nome: ");
	fflush(stdin);
	gets(nome);       //l� conte�do para a vari�vel nome
//	scanf("%s",&nome);//l� conte�do para a vari�vel nome, at� o primeiro espa�o
//	scanf("%[^\n]s",&nome);//l� conte�do para a vari�vel nome
	printf("\nDigite a idade: ");
	scanf("%d",&idade);
	printf("\nDigite a rua: ");
	fflush(stdin);
	gets(rua);
	printf("\nDigite a cidade: ");
	fflush(stdin);
	gets(cidade);
	printf("\nDigite o estado: ");
	fflush(stdin);
	gets(estado);
	
	printf("\nNome: %s\nRua: %s\nCidade: %s\nEstado: %s",nome,rua,cidade,estado);
	
	return 0;
}	