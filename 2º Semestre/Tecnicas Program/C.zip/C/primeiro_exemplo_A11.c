#include <stdio.h>

main(){
  float pm, pf, ipi, icm, lucro;
  printf("Informe o preco da montadora: ");
  scanf("%f",&pm);
  ipi = pm * 0.11;
  icm = pm * 0.17;
  lucro = pm * 0.15;
  pf = pm + ipi + icm + lucro;
  printf("\npreco final --> %.2f", pf);
  printf("\nimpostos -----> %.2f\n", ipi+icm);
  system("pause");
}
