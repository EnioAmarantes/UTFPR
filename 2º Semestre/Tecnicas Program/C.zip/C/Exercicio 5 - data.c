# include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*----------------------------------------------||---------------------------------------------------
Nome do Programa: Idade_dias
Autor: Aline Ferreira da Silva
Data: 09/09/2011
Disciplina: T�cnicas de Programa��o
Turma: C21
Objetivo: Fa�a um algoritmo que leia a idade de uma pessoa em anos, meses e dia e mostre-as expressa
em dia.
Dados de entrada: ano, mes, dia (inteiro)
Dados de sa�da: as variaveis ano, mes e dia transformadas somente em dias
Obs: digitar meses, anos e dia corretamente. A idade est� sendo contada de acordo com a data do sistema
-------------------------------------------------||------------------------------------------------*/
int main ()
{
    struct tm *local; //hor�rio no ponteiro 'local', que aponta para a estrutura tm.
    time_t t;
    int ano, mes, dia, contador, resposta, ano1, anoatual, mesatual, diaatual;
    t= time(NULL);
    local=localtime(&t);

    diaatual=local->tm_mday;
    mesatual=local->tm_mon+1;
    anoatual=local->tm_year+1900; //� necess�rio acrescentar 1900 ao ano, pois o sistema retorna a partir de 1900.
                         //Basicamente, no lugar de 2004, o sistema retorna 104.
    contador = 0;
    resposta = 0;
    ano1 = 0;
    printf("Informe o ano de nascimento: ");
    scanf("%d", &ano);
    printf("Informe o mes de nascimento: ");
    scanf("%d", &mes);
    printf("Informe o dia de nascimento: ");
    scanf("%d", &dia);
    if ((mes > mesatual) || ((mes == mesatual) && (dia > diaatual)))
    {
            for (ano1 = ano;  ano1 <= (anoatual - 1); ano1++)
            {
                if (ano1 % 4 == 0)
                    contador++;
            }
            resposta = (contador*366) + (((anoatual-1) - ano - contador)*365);
    }
    if ((mes < mesatual) || ((mes == mesatual) && (dia <= diaatual)))
    {
            for (ano1 = ano;  ano1 <= anoatual; ano1++)
            {
                if (ano1 % 4 == 0)
                    contador++;
            }
            resposta = (contador*366) + ((anoatual - ano - contador)*365);
    }

    if (mes > mesatual)
    {
            if (mesatual==1)
            {
                if (mes == 2)
                   resposta += 28 - dia + 306 + diaatual;
                else if (mes == 3)
                   resposta += 31 - dia + 275 + diaatual;
                else if (mes == 4)
                   resposta += 30 - dia + 245 + diaatual;
                else if (mes == 5)
                   resposta += 31 - dia + 214 + diaatual;
                else if (mes == 6)
                   resposta += 30 - dia + 184 + diaatual;
                else if (mes == 7)
                     resposta += 31 - dia + 153 + diaatual;
                 else if (mes == 8 )
                     resposta += 31 - dia + 122 + diaatual;
                 else if (mes == 9)
                     resposta += 30 - dia + 92 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 61 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 31 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + diaatual;
             }
            if (mesatual==2)
            {
                if (mes == 3)
                   resposta += 31 - dia + 306 + diaatual;
                else if (mes == 4)
                   resposta += 30 - dia + 276 + diaatual;
                else if (mes == 5)
                   resposta += 31 - dia + 245 + diaatual;
                else if (mes == 6)
                   resposta += 30 - dia + 215 + diaatual;
                else if (mes == 7)
                     resposta += 31 - dia + 184 + diaatual;
                 else if (mes == 8 )
                     resposta += 31 - dia + 153 + diaatual;
                 else if (mes == 9)
                     resposta += 30 - dia + 123 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 92 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 62 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 31 + diaatual;
             }
             if (mesatual==3)
            {
                if (mes == 4)
                   resposta += 30 - dia + 304 + diaatual;
                else if (mes == 5)
                   resposta += 31 - dia + 273 + diaatual;
                else if (mes == 6)
                   resposta += 30 - dia + 243 + diaatual;
                else if (mes == 7)
                     resposta += 31 - dia + 212 + diaatual;
                 else if (mes == 8 )
                     resposta += 31 - dia + 181 + diaatual;
                 else if (mes == 9)
                     resposta += 30 - dia + 151 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 120 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 90 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 59 + diaatual;
            }
            if (mesatual==4)
            {
                if (mes == 5)
                   resposta += 31 - dia + 304 + diaatual;
                else if (mes == 6)
                   resposta += 30 - dia + 274 + diaatual;
                else if (mes == 7)
                     resposta += 31 - dia + 243 + diaatual;
                 else if (mes == 8 )
                     resposta += 31 - dia + 212 + diaatual;
                 else if (mes == 9)
                     resposta += 30 - dia + 182 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 151 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 121 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 90 + diaatual;
            }
            if (mesatual==5)
            {
                if (mes == 6)
                   resposta += 30 - dia + 304 + diaatual;
                else if (mes == 7)
                     resposta += 31 - dia + 273 + diaatual;
                 else if (mes == 8 )
                     resposta += 31 - dia + 242 + diaatual;
                 else if (mes == 9)
                     resposta += 30 - dia + 212 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 181 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 151 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 120 + diaatual;
            }

            if (mesatual==6)
            {
                 if (mes == 7)
                     resposta += 31 - dia + 304 + diaatual;
                 else if (mes == 8 )
                     resposta += 31 - dia + 273 + diaatual;
                 else if (mes == 9)
                     resposta += 30 - dia + 243 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 212 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 182 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 151 + diaatual;
            }
            if (mesatual==7)
            {
                 if (mes == 8 )
                     resposta += 31 - dia + 303 + diaatual;
                 else if (mes == 9)
                     resposta += 30 - dia + 273 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 242 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 212 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 181 + diaatual;
            }
            if (mesatual==8)
            {
                 if (mes == 9)
                     resposta += 30 - dia + 304 + diaatual;
                 else if (mes == 10)
                    resposta += 31 - dia + 273 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 243 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 212 + diaatual;
            }
            if (mesatual==9)
            {
                 if (mes == 10)
                    resposta += 31 - dia + 304 + diaatual;
                 else if (mes == 11)
                     resposta += 30 - dia + 274 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 243 + diaatual;
            }
            if (mesatual==10)
            {
                 if (mes == 11)
                    resposta += 30 - dia + 304 + diaatual;
                 else if (mes == 12)
                     resposta += 31 - dia + 273 + diaatual;
            }
            if (mesatual==11)
                     resposta += 31 - dia + 304 + diaatual;
    }
    else if ((mes == mesatual) && (dia > diaatual))
    {
         if (mesatual==1)
            resposta += 31 - dia + 334 + diaatual;
         else if (mesatual==2)
            resposta += 28 - dia + 337 + diaatual;
         else if (mesatual==3)
            resposta += 31 - dia + 334 + diaatual;
         else if (mesatual==4)
            resposta += 30 - dia + 335 + diaatual;
         else if (mesatual==5)
            resposta += 31 - dia + 334 + diaatual;
         else if (mesatual==6)
            resposta += 30 - dia + 335 + diaatual;
         else if (mesatual==7)
            resposta += 31 - dia + 334 + diaatual;
         else if (mesatual==8)
            resposta += 31 - dia + 334 + diaatual;
         else if (mesatual==9)
            resposta += 30 - dia + 335 + diaatual;
         else if (mesatual==10)
            resposta += 31 - dia + 334 + diaatual;
         else if (mesatual==11)
            resposta += 30 - dia + 335 + diaatual;
         else if (mesatual==12)
            resposta += 31 - dia + 334 + diaatual;
    }
    else if ((mes == mesatual) && (dia <= diaatual))
           resposta += diaatual - dia;
    else if (mes < mesatual)
    {
         if (mesatual==2)
            resposta += 31 - dia + diaatual;
         else if (mesatual==3)
            resposta += 59 + diaatual;
         else if (mesatual==4)
            resposta += 90 + diaatual;
         else if (mesatual==5)
            resposta += 120 + diaatual;
         else if (mesatual==6)
            resposta += 151 + diaatual;
         else if (mesatual==7)
            resposta += 181 + diaatual;
         else if (mesatual==8)
            resposta += 212 + diaatual;
         else if (mesatual==9)
            resposta += 243 + diaatual;
         else if (mesatual==10)
            resposta += 273 + diaatual;
         else if (mesatual==11)
            resposta += 304 + diaatual;
         else if (mesatual==12)
            resposta += 334 + diaatual;
     }
     printf("Sua idade �: %d dias\n", resposta);

    system("pause");
    return 0;
}
