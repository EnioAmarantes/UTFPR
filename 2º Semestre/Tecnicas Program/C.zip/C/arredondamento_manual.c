#include <stdio.h>

int main(){
	float n;
	
	n = 13.56;

	printf("\nN -> %f",n);
	
	printf("\nN --> %d",(int)n);
		
	if ((int)((n - (int)n) * 10) < 5)
		printf("\nN ---> %d",(int)n);
	    else
	       printf("\nN ----> %d",(int)n+1);
	   	
	return 0;
}