#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int t1, t2, t3, c, qt;
  printf("Quantos termos para a s�rie de Fibonacci? ");
  scanf("%d",&qt);
  printf("\n1 1 ");
  c = 2;
  t1 = 1;
  t2 = 1;
  while (c < qt){
    t3 = t1 + t2;
    c = c + 1;
    printf("%d ",t3);
    t1 = t2;
    t2 = t3;
  }
  return 0;
}
