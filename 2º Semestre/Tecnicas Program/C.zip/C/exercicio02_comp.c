#include <stdio.h>
main(){
  int i, min, seg, nvr, vmr, nvl, vml, dist, cont, soma;
  vmr = 0;
  vml = 10000;
  cont = 0;
  soma = 0;
  do {
    printf("Digite o tempo da volta %d em minutos e segundos. \n\n", cont + 1);
    printf("Para finalizar digite -1 para os minutos e para os segundos. \n\n");
    printf("Primeiro os minutos e ENTER, depois os segundos e ENTER. \n");
    scanf("%d %d",&min, &seg);
    getchar();
    if (min > 0){
      cont = cont + 1;
      soma = soma +  min * 60 + seg;
      if (vmr < min * 60 + seg){
        vmr = min * 60 + seg;
        nvr = cont;
      }
      if (vml > min * 60 + seg){
        vml = min * 60 + seg;
        nvl = cont;
      }
    }
  } while (min > 0);
  if (cont != 0){
    printf("\nInforme a dist�ncia do circuito, em metros : ");
    scanf("%d", &dist);
    printf("\nA volta %d foi a mais rapida em %d min e%d seg", nvr, vmr / 60, vmr % 60);
    printf("\nA volta %d foi a mais lenta em %d min e %d seg",nvl, vml / 60, vml % 60);
    printf("\nO tempo medio das %d voltas foi de %d min e %d seg",cont, (soma / cont) / 60, (soma / cont) % 60);
    printf("\nA quantidade de combust�vel consumida foi de %d", dist * cont / 3950 * 2);
  }
}
