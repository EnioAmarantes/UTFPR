#include <stdio.h>
main(){
    int a[3][5],b[3][5],c[6][5],i,j,k,l;
//carrega a
    for(i=0;i<3;i++)
        for(j=0;j<5;j++){
            printf("Digite um valor: ");
            scanf("%d",&a[i][j]);
        }
//mostra a matriz a
    printf("\n\nMatriz A\n");
    for(i=0;i<3;i++){
        for(j=0;j<5;j++)
            printf(" %d \t ",a[i][j]);
        printf("\n");
    }
//carrega b
    for(i=0;i<3;i++)
        for(j=0;j<5;j++){
            printf("Digite um valor: ");
            scanf("%d",&b[i][j]);
        }
        printf("\n\n");
//mostra a matriz b
    printf("\n\nMatriz B\n");
    for(i=0;i<3;i++){
        for(j=0;j<5;j++)
            printf(" %d \t ",b[i][j]);
        printf("\n");
    }
    printf("\n\n\n");
//interpola a e b em c
    for(l=0, i=0;l<3;l++, i++)
        for(k=0, j=0;k<5;k++, j++){
             c[l][k]=a[i][j];
             c[l+3][k]=b[i][j];
        }


//mostra a matriz c
    printf("\n\nMatriz C\n");
    for(i=0;i<6;i++){
        for(j=0;j<5;j++)
            printf(" %d \t ",c[i][j]);
            printf("\n");
    }
}
