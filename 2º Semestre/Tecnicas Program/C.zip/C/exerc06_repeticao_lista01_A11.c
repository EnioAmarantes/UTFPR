//06 � Obter v�rios grupos de dois n�meros quaisquer,
//e informar (para cada grupo):
//a) a soma destes n�meros;
//b) a subtra��o destes n�meros;
#include <stdio.h>
int main(){
   float n1, n2;
   int q, c;
   printf("Quantos grupos de numeros serao informados? ");
   scanf("%d",&q);
   c = 1;
   while (c <= q)
      {
         printf("\nInforme dois numeros separados por / \n");
         scanf("%f/%f",&n1,&n2);
         printf("\nA soma e %f",n1+n2);
         printf("\nA subtracao e %f",n1-n2);
         c = c + 1;
      }
  return 0;
}
