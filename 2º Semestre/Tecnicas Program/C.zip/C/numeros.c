#include <stdio.h>
main (){
  int n, c, x, s, nr, ct;

  printf("digite um numero para elevar ao cubo: ");
  scanf("%d", &n);
  for(x = n - 1, c = 0; x >= 1; x = x - 1)
    c = c + x;
  for(nr = c * 2 + 1, ct = 1, s = 0; ct <= n; ct++, s = s + nr, nr = nr + 2)
    printf("\nnumero --> %d", nr);
  printf("\n\nnumero lido ao cubo --> %d\n\n", s);
}
