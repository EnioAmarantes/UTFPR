#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int x, y;
  x = 1;
  while (x < 4){
    y = 1;
    while (y < 4){
      printf("\nx(%d)  y(%d)",x,y);
      y = y + 1;
    }
    x = x + 1;
  }
  return 0;
}
