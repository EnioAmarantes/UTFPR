//4. Apresentar os n�meros inteiros m�ltiplos de 5, em um intervalo fornecido
//   pelo usu�rio
#include <stdio.h>
int main(){
  int n, li, ls;
  printf("Digite o limite inferior: ");
  scanf("%d",&li);
  printf("Digite o limite superior: ");
  scanf("%d",&ls);

//------WHILE------
  while (li <= ls)
  {
    if (li % 5 == 0)
      printf("%d ",li);
    li = li + 1;
  }
/*
  printf("\n\n");
//------FOR------
  for(;li <= ls;li = li + 1)
  {
    if (li % 5 == 0)
      printf("%d ",li);
    li = li + 1;
  }

  printf("\n\n");
//------DO...WHILE------
  do
  {
    if (li % 5 == 0)
      printf("%d ",li);
    li = li + 1;
  }while (li <= ls);
*/
  return 0;
}
