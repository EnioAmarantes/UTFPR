//1. Elaborar um programa que l� um conjunto de 30 valores e os coloca em 2 
//vetores conforme estes valores forem pares ou �mpares. O tamanho do vetor 
//� de 5 posi��es. Se algum vetor estiver cheio,
//escrev�-lo. Terminada a leitura escrever o conte�do dos dois vetores. 
//Cada vetor pode ser preenchido tantas vezes quantas for necess�rio.
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int par[5]={0,0,0,0,0}, impar[5]={0,0,0,0,0}, ipar, iimpar, count, n;
	ipar = 0;
	iimpar = 0;
	count = 1;
	while (count <= 30){
	  printf("Digite o %d� valor da s�rie, de um total de 30: ",count);	
	  scanf("%d",&n);
	  if ((n % 2 == 0) && (ipar < 5)){
		  par[ipar] = n;
		  ipar = ipar + 1;
		  if (ipar == 5){
		  	for(ipar = 0;ipar < 5;ipar++)
		  		printf("%d ",par[ipar]);
		  	printf("\n");
		  	ipar = 0;
		  }
	  }	
	  if ((n % 2 != 0) && (iimpar < 5)){
		  impar[iimpar] = n;
		  iimpar = iimpar + 1;
		  if (iimpar == 5){
		  	for(iimpar = 0;iimpar < 5;iimpar++)
		  		printf("%d ",impar[iimpar]);
		  	printf("\n");
		  	iimpar = 0;
		  }
	  }
	  count = count + 1;	
	}
    printf("\n");
  	for(n = 0;n < iimpar;n++)
  		printf("%d ",impar[n]);
    printf("\n");  	
  	for(n = 0;n < ipar;n++)
  		printf("%d ",par[n]);
	printf("\n");
	return 0;
}
