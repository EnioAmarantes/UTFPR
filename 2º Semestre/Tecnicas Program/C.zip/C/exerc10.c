#include <stdio.h>
main(){
  float s, x, y, fat, A, B;
  int flag;
  s = 1;
  x = 3;
  y = 2;
  flag = 0;
  while(y <= 50){
    A = y;
    B = y - 1;
    while (B > 1){
      A = A * B;
      B --;
      }
    if (flag == 0){
      s = s / (x / A);
      flag = 1;
    }
    else{
      s = s + (x / A);
      flag =0;
      }
    x = x + 2;
    y = y + 1;
  }
  printf("\no valor de S � %f", s);
}
