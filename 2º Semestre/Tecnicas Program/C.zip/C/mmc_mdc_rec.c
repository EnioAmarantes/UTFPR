#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int mdc(int,int);
int main(){
	setlocale(LC_ALL,"Portuguese");
    int n1, n2, aux;
    printf("Este programa calcula o MDC e o MMC de dois n�meros\n");
	printf("Digite o primero n�mero: ");
    scanf("%d", &n1);
    printf("Digite o segundo n�mero: ");
    scanf("%d", &n2);
    if (n1 < n2){
    	aux = n1;
    	n1 = n2;
    	n2 = aux;
    }
    printf("\nMDC = %d\nMMC = %d ", mdc(n1,n2), n1 * n2 / mdc(n1,n2));   
    return 0;
}
int mdc(int x, int y){
    if (x%y == 0)
      return y;
      else
        return mdc(y,x % y);
}