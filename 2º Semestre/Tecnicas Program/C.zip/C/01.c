#include <stdio.h>
int main(){
	char sexo;
	printf("Informe o seu sexo: (M/F): ");
	scanf("%c",&sexo);
	if ((sexo == 'm') || (sexo == 'M'))
		printf("Sexo: Masculino");
	   else
	     if ((sexo == 'f') || (sexo == 'F'))
   		 printf("Sexo: Feminino");
          else
		      printf("Sexo: Inv�lido!");
   return 0;
}
