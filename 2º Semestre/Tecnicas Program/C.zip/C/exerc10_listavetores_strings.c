/*
Quest�o 10: Fa�a um programa em C que carregue um vetor de 20 posi��es com
n�meros inteiros e que mostre os n�meros que aparecem mais de uma vez
e quantas vezes cada n�mero se repete, mostrando um relat�rio da seguinte forma:

0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19
5	4	3	18	6	15	48	3	12	7	9	8	5	1	0	3	4	9	18	27

O n�mero 5 aparece duas vezes no vetor, nas posi��es 0, 12
O n�mero 4 aparece duas vezes no vetor, nas posi��es 1, 16
O n�mero 3 aparece tr�s vezes no vetor, nas posi��es 2, 7, 15
O n�mero 18 aparece duas vezes no vetor, nas posi��es 3, 18
*/
/*
========================================
      STRINGS ao inv�s de INTEGER
========================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
main(){
//  char nomes[10][20] = {"Joao","Carlos","Antonio","Francisco","Joao","Maria","Carlos","Lucas","Antonio","Maria"};
  char nomes[10][20];
  int r, i, j, aux;
//preenchimento do vetor de nomes
  for(i = 0;i <= 9;i = i + 1){
    printf("Digite o nome para a posicao %d do vetor: ",i);
    fflush(stdin); //limpa o buffer para permitir a leitura da pr�xima string
    //scanf("%[^\n]s",&nomes[i]);
    gets(nomes[i]);
  }
  //mostra o conte�do do vetor
  for(i = 0; i <= 9; i++)
    printf("\n%d - %s ",i, nomes[i]);
  printf("\n\n");
  //verifica quantas vezes o valor da primeira posi��o do vetor est� repetido
  aux = 1;
  for(i = 1; i <= 9; i++)
    if (strcmp(nomes[i],nomes[0]) == 0)
      aux++;
  //mostra quantas vezes o valor da primeira posi��o do vetor est� repetido, e em que
  //local se encontra
  if (aux == 1)
    printf("O nome %s aparece uma vez no vetor, na posicao 0", nomes[0]);
    else{
      printf("O nome %s aparece %d vezes no vetor, nas posicoes ",nomes[0], aux);
   	  for(i = 0; i <= 19; i++)
   	    if (strcmp(nomes[i],nomes[0]) == 0)
   	      printf("%d ", i);
    }
  printf("\n");
  //percorre o vetor para verificar se cada valor nas posi��es maiores do que 0 repetem-se
  for(i = 1; i <= 9; i++){
    r = 0;
   	for(j = 0; j < i; j++) //verifica se o valor atual j� foi analizado
   	  if (strcmp(nomes[j],nomes[i]) == 0)   //caso positivo altera o valor de r de zero para um
   	    r = 1;
    //verifica quantas vezes o valor da posi��o atual do vetor est� repetido
   	if (r == 0){
   	  aux = 0;
	  for (j = 0; j <= 9; j++)
	    if ((j != 0) && ((strcmp(nomes[i],nomes[j]) == 0)))
          aux++;
	  //mostra quantas vezes o valor da posi��o atual do vetor est� repetido, e em que
      //local se encontra
      if (aux == 1)
        printf("O nome %s aparece uma vez no vetor, na posicao %d", nomes[i], i);
        else{
          printf("O nome %s aparece %d vezes no vetor, nas posicoes ",nomes[i], aux);
          for(j = 0; j <= 9; j++)
            if (strcmp(nomes[i],nomes[j]) == 0)
               printf("%d ", j);
        }
        printf("\n");
   	}
  }
}
