/*
5. Fa�a um programa que receba dois n�meros reais e execute as opera��es
listadas a seguir, de acordo com a escolha do usu�rio.
ESCOLHA DO USU�RIO OPERA��O
1 - M�dia entre os n�meros digitados.
2 - Diferen�a do maior pelo menor.
3 - Produto entre os n�meros digitados.
4 - Divis�o do primeiro pelo segundo.
Se a op��o digitada for inv�lida, mostre uma mensagem de erro e termine
a execu��o do programa. Lembre-se de que, na opera��o 4, o segundo n�mero
deve ser diferente de zero.
Use a estrutura switch..case para coordenar as escolhas do usu�rio.

entradas de dados:
   n�mero1, n�mero2, escolha
sa�das de dados:
   m�dia ou diferen�a ou produto ou divis�o ou mensagens de op��o inv�lida
   ou mensagem de divis�o por zero
processamento:
   obter o n�mero1
   obter o n�mero2
   mostrar o menu de op��es
   obter a op��o do usu�rio
   caso a op��o seja 1 realizar a m�dia entre os n�meros
   caso a op��o seja 2 realizar a diferen�a entre os n�meros
   caso a op��o seja 3 realizar o produto dos n�meros
   caso a op��o seja 4 verificar se o segundo n�mero � diferente de
      zero, se for, realizar a divis�o do primeiro pelo segundo,
      sen�o, mostrar mensagem de erro de divis�o por zero
   caso a op��o n�o seja nenhuma das anteriores, mostrar mensagem
      de op��o incorreta
*/
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  float n1, n2;
  int opcao;
  printf("\nDigite o primeiro n�mero: ");
  scanf("%f",&n1);
  printf("\nDigite o segundo n�mero: ");
  scanf("%f",&n2);
  printf("\nEscolha uma das op��es abaixo:");
  printf("\n1 - M�dia entre os n�meros digitados");
  printf("\n2 - Diferen�a do maior pelo menor");
  printf("\n3 - Produto entre os n�meros digitados");
  printf("\n4 - Divis�o do primeiro pelo segundo\n");
  scanf("%d",&opcao);
  switch (opcao)
  {
    case 1:
      printf("\nA m�dia � %f",(n1+n2)/2);
      break;
    case 2:
      printf("\nA diferen�a � %f",n1-n2);
      break;
    case 3:
      printf("\nO produto � %f",n1*n2);
      break;
    case 4:
      if (n2 != 0)
        {
           printf("\nA divis�o � %f",n1/n2);
        }
         else
         {
            printf("\nERRO de divis�o por zero");
         }
      break;
    default:
      printf("\nOp��o incorreta");
  }
  return 0;
}

