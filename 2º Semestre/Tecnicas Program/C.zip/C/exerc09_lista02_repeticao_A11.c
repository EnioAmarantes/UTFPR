//4.	9.	Fazer um algoritmo que calcule e escreva a soma dos
// 50 primeiros termos da s�rie:
//       1!    2!    3!    4!    5!       
//  S = --- - --- + --- - --- + --- - ... 
//       1     3     7     15    31      
//
//Entradas: nenhuma
//Sa�da: valor de S
//Processamento: podemos considerar que S � a soma consecutiva
//               da divis�o de X por Y sendo que X come�a em 1 e � 
//               incrementado de 1 em 1. Deve-se calcular o FATORIAL
//               de X.
//               Os termos s�o alternados entre soma e subtra��o.
//               O valor de Y � sempre o valor anterior de Y * 2 + 1
//               Este padr�o repete-se at� que seja atingido
//               o n�mero de 50 termos
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float x, y, s, fat, f;
	int sinal, cont;
	sinal = -1;
	x = 2;
	y = 3;
	cont = 0;
	s = 1;
	while(cont < 49){
	   fat = x;
	   f = x - 1;
	   while(f > 1){
		   fat = fat * f;
		   f = f - 1;	   
	   }
	   s = s + (fat / y) * sinal;
	   sinal = sinal * -1;
	   x = x + 1;
	   y = y * 2 + 1;
	   cont = cont + 1;		
	}
	printf("O valor de S � %f",s);
		
	return 0;
}
