#include <stdio.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 

  int a, b;
  
  printf("digite um n�mero para calcular a tabuada: ");
  scanf("%d",&a);
  for(b = 1;b <= 10;b++)
  	printf("\n%2d X %2d = %2d",a,b,a*b);

}


