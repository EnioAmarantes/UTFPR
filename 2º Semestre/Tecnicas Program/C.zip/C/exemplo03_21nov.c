#include <stdio.h>
#define MAXLINHA 100
#define MAXSEQ 100
int le_linha(char s[],int lim);
int procura_seq(char s[],char t[]);
int main() {
  int i=0;
  char linha[MAXLINHA], seq[MAXSEQ] = "e";
  scanf("%s",seq);
  while(le_linha(linha,MAXLINHA) > 0)
    if(procura_seq(linha,seq) >= 0) printf("%d: %s",++i,linha);
  return 0;
}
int le_linha(char s[],int lim) {
/* le uma linha e retorna o seu comprimento. Coloca \n no fim. */
  int c, i;
  for(i = 0; i < lim - 1 && (c = getchar()) != EOF && c != '\n'; i++)
    s[i] = c;
  if( c == '\n') s[i++] = c;
    s[i] = '\0';
  return(i);
}
int procura_seq(char s[],char t[]){
  int i,j,k;
  for(i = 0; s[i] != '\0'; i++) {
    for(j=i, k=0; t[k]!='\0' && s[j]==t[k]; j++,k++);
      if (k > 0 && t[k] == '\0') return i;
  }
  return -1;
}