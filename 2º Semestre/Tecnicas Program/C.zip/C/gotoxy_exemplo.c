
#include <stdio.h> 
#include <locale.h>
#include <math.h>
int main(){	
	setlocale(LC_ALL,"Portuguese");

    printf("\nCoseno de 45 --> %f",cos(45*M_PI/180));    
	

	return 0;
}