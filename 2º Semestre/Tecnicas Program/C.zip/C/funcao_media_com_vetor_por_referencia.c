#include <stdio.h>
#include <stdlib.h>
#define T 10
float media(float[], int);//prot�tipo da fun��o media
                          //float[] declara um ponteiro do tipo float para um vetor
                          //int declara uma var��vel do tipo inteiro
main(){
  float nota[T], m;
  int i = 0;
  srand(time(NULL));
  do{
 //   printf("\nDigite a nota do aluno %d ", i+1);
    nota[i] = rand()/1000+1.1*rand()/1000;
    printf("\n   nota --> %.2f", nota[i]);
    i++;
  }while (i < T);
  m = media(nota, T); //quando o nome de um vetor � passado como par�metro
                      //seu endere�o de mem�ria � enviado � fun��o, ou seja
                      //o vetor � passado � fun��o por refer�ncia,
                      //sem a necessidade do sinal &
  printf("\n\na media das notas e %.2f \n", m);
}

float media(float lista[], int tamanho) //para que a fun��o receba o vetor por refer�ncia
                                        //o mesmo � declarado 'sem tamanho', apenas com os colchetes
{
  int i;
  float m = 0.0;
  for(i = 0; i < tamanho; i++)
    m += lista[i];
  return m/tamanho;
}
