//
//       n!    (n+1)!  (n+2)!  (n+3)!  (n+3)!
//  s = ---- + ----- + ----- + ----- + ------ + ....
//       x!    (x+1)!  (x+2)!  (x+3)!  (x+4)!
//
#include <stdio.h>

int main(){
  float s, n, x, fatn, fatx, y;
  int c, q;

  printf("digite o valor de n: ");
  scanf("%f", &n);
  printf("digite o valor de x: ");
  scanf("%f", &x);
  printf("digite a quantidade de termos: ");
  scanf("%d", &q);

  s = 0;
  c = 0;

  while (c < q) {

    fatn = n;
    y = fatn - 1;
    while (y > 1) {
      fatn = fatn * y;
      y = y - 1;
      }

    fatx = x;
    y = fatx - 1;
    while (y > 1) {
      fatx = fatx * y;
      y = y - 1;
      }

    s = s + fatn / fatx;

    n = n + 1;
    x = x + 1;
    c = c + 1;
  }

  printf("%f", s);
  
  return 0;
}
