#include <stdio.h>
main(){
  int n, cont = 1, aux = 0, cont1, cont2, cont3, soma;
  printf("digite o valor de n: ");
  scanf("%d", &n);
  if (n < 0)
    printf("n negativo, digite novamente");
  else{
    while(aux == 0)
    {
        cont1 = n - cont;
        cont2 = n - (cont + 1);
        cont3 = n - (cont + 3);
        soma = cont1 + cont2 + cont3;
        if (soma == n)
            aux = 1;
        else
            cont++;
    }
    printf("soma --> %d  %d e perfeito pois %d + %d + %d = %d", soma, n, cont1, cont2, cont3, n);
  }
}
