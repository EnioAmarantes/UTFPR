#include <stdio.h>
#include <string.h>
main(){
  int x;      // 0,1,2,3,4,5,6,7,8,9
  int led[10] = {6,2,5,5,4,5,6,3,7,6};
  int q, i, soma;
  printf("\ninforme a quantidade de casos de teste: ");
  scanf("%d", &q);
  for(;q > 0;q--){
    printf("\nInforme o
            painel de leds ");
    scanf("%d",&x);
    soma = 0;
    i = x;
    while(i > 0){
      soma = soma + led[i%10];
      i = i / 10;
    }
    printf("\nserao necessarios %d leds",soma);
  }
}
