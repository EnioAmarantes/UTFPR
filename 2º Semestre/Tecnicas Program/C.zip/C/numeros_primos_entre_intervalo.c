//Quest�o 03 (1,0): 
//Escreva um algoritmo que mostre todos os n�meros primos em um intervalo
//fechado [N1,N2] fornecido pelo usu�rio.
#include <locale.h>
#include <stdio.h>
#include <conio.h>
int main() {
	setlocale(LC_ALL,"Portuguese");
  int soma, x, n1, n2;
  printf("digite o primeiro n�mero do intervalo\n");
  scanf("%d", &n1);
  printf("digite o segundo n�mero do intervalo\n");
  scanf("%d", &n2);
  while (n1 <= n2) {
    x = n1;
    soma = 0;
    while (x >= 1){
      if (n1 % x == 0)
        soma = soma + 1;
      x = x - 1;
    }
    if (soma == 2)
      printf("%d\n", n1);
    n1 = n1 + 1;
  }
  return 0;
}
