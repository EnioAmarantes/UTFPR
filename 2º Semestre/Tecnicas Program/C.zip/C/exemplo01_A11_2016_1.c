#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <windows.h>

gotoxy(int x, int y){
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x-1,y-1});
}

int soma(int a, int b){
  return a+b;
}

main(){

  setlocale(LC_ALL, "Portuguese");

  int n;

  printf("Digite um n�mero inteiro: ");
  scanf("%d",&n);
// = � o comando de atribui��o
// == � o operador relacional de igualdade
  if (n == 0){
    gotoxy(13,13);
    printf("\nZERO\n");
    }
    else {
      if (n % 2 == 0){ //se n MOD 2 igual a 0
        gotoxy(15,2);
        printf("\nO n�mero %d � par",n);
        n = n + 1;
        printf("\nAgora o n�mero %d � �mpar\n",n);
      }
      else{
        gotoxy(22,10);
        printf("\nO n�mero %d � �mpar",n);
        n = n + 1;
        printf("\nAgora o n�mero %d � par\n",n);
      }
    }

    printf("A soma entre 2 e 5 � igual a %d", soma(2,5));
  system("pause");
}
