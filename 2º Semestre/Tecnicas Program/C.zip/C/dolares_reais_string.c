#include <stdio.h>
#include <string.h>
main(){
  char op[10];
  float valor, cotacao;

  printf("Informe o valor que sera convertido: ");
  fflush(stdin);
  scanf("%f",&valor);
  printf("\nInforme: \nreais - para valores em Reais \ndolares - para valores em dolares \n");
  fflush(stdin);
  scanf("%s",&op);
  if (strcmp(op,"reais") == 0){
    printf("\ninforme a cotacao do dolar para conversao do valor de Reais para Dolares: ");
    scanf("%f",&cotacao);
    printf("\n%.2f Reais --> %.2f Dolares", valor, valor/cotacao);
  }
    else
      if (strcmp(op,"dolares") == 0){
        printf("\ninforme a cotacao do dolar para conversao do valor de Dolares para Reais: ");
        scanf("%f",&cotacao);
        printf("\n%.2f Dolares --> %.2f Reais", valor, valor*cotacao);
      }
      else
        printf("\nopcao invalida");
}
