/*
01 - Calcular o pre�o de venda de um carro. 
O pre�o de venda � formado pelo pre�o da montadora, mais 15% de lucro, 
mais 11% de IPI, mais 17% de ICM. 
As porcentagens s�o sobre o pre�o da montadora, que � lido. 
Informe o pre�o final e o valor dos impostos.
Entradas de dados: 
o	Pre�o da montadora
Sa�das de dados: 
o	Pre�o final e valor dos impostos
Processamento: 
o	Obter o pre�o da montadora
o	Calcular lucro, 15% do pre�o da montadora
o	Calcular ipi, 11% do pre�o da montadora
o	Calcular icm, 17% do pre�o da montadora
o	Mostrar pre�o final, pre�o da montadora + lucro +ipi + icm
o	Mostrar valor dos impostos, ipi + icm
F�rmulas
o	lucro = pm * 0.15
o	ipi = pm * 0.11
o	icm = pm * 0.17
o	pf = pm + lucro + ipi + icm
o	vi = ipi + icm
*/
#include <stdio.h> 
//insere no c�digo as fun��es para entrada e sa�da
#include <locale.h>
//insere no c�digo as fun��es que permitem visualiza��o de texto
int main(){
//in�cio da fun��o main()	
	setlocale(LC_ALL,"Portuguese");
//configura a linguagem para portugues, para acentua��o correta	
	float lucro, pm, ipi, icm, vi, pf;
//declara lista de vari�veis do tipo float (real)
	printf("Informe o pre�o da montadora: ");
//comando de sa�da, mostra conte�do na tela	
	scanf("%f",&pm);
//comando de entrada, l� um valor float e armazena no endere�o de
//mem�ria da vari�vel pm
	lucro = pm * 0.15;
//atribui para a vari�vel lucro 15% da vari�vel pm
	ipi = pm * 0.11;
//atribui para a ipi lucro 11% da vari�vel pm
	icm = pm * 0.17;
//atribui para a vari�vel icm 17% da vari�vel pm
	pf = pm + lucro + ipi + icm;
//atribui para a vari�vel pf a soma de pm + lucro + ipi +icm	
	vi = ipi + icm;
//atribui para a vari�vel vi a soma de ipi + icm	
	printf("\nO pre�o final do ve�culo � %0.2f", pf);
//comando de sa�da, mostra na tela o texto e o valor da vari�vel pf	
	printf("\nO valor dos impostos � %0.2f", vi);	
//comando de sa�da, mostra na tela o texto e o valor da vari�vel vi	
	return 0;
}