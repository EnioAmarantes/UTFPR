#include <stdio.h>
#include <locale.h>
//programa para mostrar a tabuada de um n�mero
//
//exemplo
//
//printf("\n 1 x %d = %d",2,2*1);
//printf("\n 2 x %d = %d",2,2*2);
//printf("\n 3 x %d = %d",2,2*3);
//printf("\n 4 x %d = %d",2,2*4);
//printf("\n 5 x %d = %d",2,2*5);
//printf("\n 6 x %d = %d",2,2*6);
//printf("\n 7 x %d = %d",2,2*7);
//printf("\n 8 x %d = %d",2,2*8);
//printf("\n 9 x %d = %d",2,2*9);
//printf("\n 10 x %d = %d",2,2*10);
//
//DO ... WHILE  - enquanto a condi��o for verdadeira os comandos
//                s�o executados.
//                A estrutura � executada 1 ou n vezes, uma vez
//                que os comandos s�o executados e depois
//                a condi��o primeiro � verificada
//
//  do
//  {
//     <comandos>
//  }while (<condi��o>);

int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, c;

  printf("\nDigite um n�mero para a tabuada: ");
  scanf("%d",&n);

  c = 1;
  do
  {
     printf("\n %d X %d = %d",c,n,c*n);
     c = c + 1;
  }while (c <= 10);

  return 0;
}
