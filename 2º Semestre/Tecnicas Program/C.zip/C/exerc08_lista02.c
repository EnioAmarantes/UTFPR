/*
8.	Fazer um algoritmo que calcule e escreva a soma dos 20 primeiros termos da serie:
100/0! + 99/1! + 98/2! + 97/3! + ...accumulate
*/
#include <stdio.h>

main(){

  float soma, den, num, fat, y;

  soma = 100;
  num = 99;
  den = 1;

  while (den <= 19) {
    fat = den;
    y = fat -1;
    while (y > 1){
      fat = fat * y;
      y = y - 1;
     }
    soma = soma + num / fat;
    num = num - 1;
    den = den + 1;
  }
  printf("WHILE --> %f", soma);


  for(soma = 100, num = 99, den = 1; den <= 19; num = num - 1, den = den + 1) {
    fat = den;
    y = fat -1;
    while (y > 1){
      fat = fat * y;
      y = y - 1;
     }
    soma = soma + num / fat;
  }
  printf("\n\nFOR --> %f", soma);
}
