//algoritmo "semnome"
//Escreva um algoritmo que leia os limites inferior e superior de um intervalo,
//imprima todos os n�meros pares no intervalo aberto e tamb�m a soma destes n�meros.
//Por exemplo:
//Limite inferior: 3
//Limite superior: 12
//N�meros pares no intervalo aberto: 4 6 8 10
//Soma dos n�meros pares no intervalo aberto: 28
#include <stdio.h>
main(){
  int li, ls, soma;
  printf("Digite o valor do limite inferior: ");
  scanf("%d",&li);
  printf("Digite o valor do limite superior: ");
  scanf("%d",&ls);
  if (li % 2 == 0)
    li = li + 2;
    else
      li = li + 1 ;
  if (ls % 2 == 0)
    ls = ls - 2;
    else
      ls = ls - 1;
  soma = 0;
  while (li <= ls){
    soma = soma + li;
    printf("%d ",li);
    li = li + 2;
  }
  printf("\nSoma %d",soma);
}
