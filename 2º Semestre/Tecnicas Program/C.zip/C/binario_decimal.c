/*
BIN�RIO PARA DECIMAL:
---------------------
A convers�o de n�meros bin�rios para n�meros decimais � realizada atrav�s de
uma somat�ria dos algarismos bin�rios da direita pra a esquerda onde cada
termo da somat�ria � multiplicado por 2 elevado a um n�mero sequencial iniciado em 0.

Vamos converter o n�mero 1000102 para a base decimal.

Primeiro invertermos o n�mero para fazermos a somat�ria da direita para a
esquerda do n�mero original.
100010 -> 010001
Agora vamos somar cada n�mero, multiplicando por 2 elevado a um n�mero
sequencial iniciado em 0.
0 * 2^0 + 1 * 2^1 + 0 * 2^2 + 0 * 2^3 + 0 * 2^4 + 1 * 2^5

0 + 1 * 2^1 + 0 + 0 + 0 + 1 * 2^5

1 * 2^1 + 1 * 2^5

2 + 32

Resultado: 34
-------------------------------------------------------------------------------
*/
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int bin, aux, i, dec;
  printf("Digite um n�mero bin�rio para convert�-lo para decimal: ");
  scanf("%d",&bin);
//  printf("\nO n�mero digitado possui %f d�gitos ", ceil(log10(bin+1)));
  dec = 0;
  aux = bin;
  i = 0;
//  for(i = 0;i < (int)ceil(log10(bin+1));i = i + 1){
  for(i = 0;aux > 0;i = i + 1){
    dec = dec + (aux % 10) * pow(2.0,i);
    aux = aux / 10;
  }
  printf("\nO n�mero bin�rio %d convertido para decimal � %d",bin,dec);
  return 0;
}
