/*
08 - Tendo como dados de entrada dois pontos quaisquer de um
     plano cartesiano P(X1,Y1)e Q(X2,Y2) calcule e mostre a dist�ncia entre eles.
     A dist�ncia � dada pela f�rmula: raiz((X2 - X1)^2 + (Y2 - Y1)^2)
*/
#include <stdio.h>
#include <math.h>
main(){
  float x1, x2, y1, y2, d;
  srand((unsigned)time(NULL));
  x1 = rand()/100;
  y1 = rand()/100;
  x2 = rand()/100;
  y2 = rand()/100;
  printf("\nx1 %2.2f\ny1 %2.2f\nx2 %2.2f\ny2 %2.2f\n", x1, y1, x2, y2);
//raiz((X2 - X1)^2 + (Y2 - Y1)^2)
  d = pow(pow(x2-x1,2.0)+pow(y2-y1,2.0),0.5);
  printf("\n\nA distancia e %2.2f", d);
  d = sqrt(pow(x2-x1,2.0)+pow(y2-y1,2.0));
  printf("\n\nA distancia e %2.2f", d);
  d = exp(0.5*((log(exp(2.0*log(x2-x1)))+log(exp(2.0*log(y2-y1))))));
  printf("\n\nA distancia e %2.2f", d);
}
