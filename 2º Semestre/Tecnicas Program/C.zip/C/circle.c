#include <conio.h>
#include <stdlib.h>

void main()	//define a funcao principal
//exit(1);	// retorna codigo de erro
//=================== inicializa ambiente grafico ==============
gdriver=DETECT;
 initgraph(&gdriver,&gmode,"c:\\borlandc\\bgi");
 errorcode=graphresult();
 if(errorcode!=grOk) { printf("Erro do adaptador grafico\n");
 printf("Falta o arquivo EGAVGA.BGI\n");
 printf("Pressione qualquer tecla para retornar");
 getch(); } //===================== inicia o programa propriamente dito ===========
 setcolor(YELLOW); //desenha em amarelo
 line(100,200,400,350); //desenha uma reta setcolor(RED); //desenha em vermelho

getch();	// espera que seja tocada uma tecla
closegraph();	//fecha o modo gr�fico
