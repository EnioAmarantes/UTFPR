#include <stdio.h>
#include <string.h>
int main(){
  char b[12] = {'65','66','\0'}, as[2];
  int i, a;
  printf("\n%s\nstrlen(b)%d\n",b,strlen(b));

  for(i = 0;i < strlen(b);i++){
    strncpy(as, &b[i], 1);
	a = atoi(as);
    printf(" %c ",a);
  }
  return 0;
}
