#include <stdio.h>
#include <math.h>
Swap(int *a,int *b){
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
}

int main (void)
{
  int x, y, z;
  x = 13;
  y = 7;
  z = 2;
  printf("\nX --> %d Y --> %d Z --> %d",x,y,z);
  if (x > y)
    Swap(&x,&y);
  if (y > z)
    Swap(&y,&z);
  if (x > y)
    Swap(&x,&y);
  printf("\nX --> %d Y --> %d Z --> %d",x,y,z);
  return 0;
}
