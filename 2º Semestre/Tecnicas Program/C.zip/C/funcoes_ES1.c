#include <stdio.h>
//prot�tipos das fun��es
int soma(int,int);       //par�metros por valor
int subtracao(int,int);  //par�metros por valor
void troca(int*,int*);   //par�metros por refer�ncia

int main(){
  int a, b, op;
  printf("Digite dois numeros inteiros separados por / : ");
  scanf("%d/%d",&a,&b);
  printf("\nEscolha a opcap: ");
  printf("\n1 - soma\n2 - subtracao\n");
  scanf("%d",&op);
  troca(&a,&b);
  if (op == 1){
    printf("\nA soma e %d",soma(a,b));
  }
  else
  {
    printf("\nA subtracao e %d", subtracao(a,b));
  }
  return 0;
}

int soma(int x, int y)
{
  x = 1;
  y = 1;
  return x + y;
}

int subtracao(int x, int y)
{
  return x - y;
}

void troca(int *x, int *y)
{
   int aux;
   aux = *x;
   *x = *y;
   *y = aux;
}
