#include <stdio.h>

main(){
  int num;

  printf("Informe o numero de aluno: ");
  scanf("%d",&num);

  printf("\nO numero de grupos com 4 alunos e de %d", num/4);

  printf("\nO numero de alunos fora dos grupos e de %d", num%4);

  system("cls");

}
