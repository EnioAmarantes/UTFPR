//6. Apresentar os n�meros inteiros entre 10 e 0,
//ou seja, em ordem decrescente.
#include <stdio.h>
int main(){
  int n;

//------WHILE------
  n = 10;
  while (n >= 0)
  {
    printf("%d ",n);
    n = n - 1;
  }

  printf("\n\n");
//------FOR------
  for(n = 10;n >= 0;n = n - 1)
  {
    printf("%d ",n);
  }

  printf("\n\n");
//------DO...WHILE------
  n = 10;
  do
  {
    printf("%d ",n);
    n = n - 1;
  }while (n >= 0);

  return 0;
}
