#include <stdio.h>
#include <locale.h>
int main(){
  int op;
  float a, b;
  setlocale(LC_ALL,"Portuguese");
  printf("\nEscolha uma das opera��es: ");
  printf("\n1 - Adi��o");
  printf("\n2 - Subtra��o");
  printf("\n3 - Multiplica��o");
  printf("\n4 - Divis�o");
  scanf("%d",&op);
  printf("Informe o primeiro n�mero: ");
  scanf("%f",&a);
  printf("Informe o segundo n�mero: ");
  scanf("%f",&b);
  switch (op){
	  case 1:
	    printf("\n%f + %f = %f",a,b,a+b); 
		break;
	  case 2:
	    printf("\n%f - %f = %f",a,b,a-b); 
		break;
	  case 3: 
	    printf("\n%f * %f = %f",a,b,a*b); 
		break;
	  case 4, 5, 6:
        if( b == 0)
          printf("\nErro de divis�o por zero");
          else
             printf("\n%f / %f = %f",a,b,a/b);
         break;
       default:
	      printf("\nOp��o inv�lida"); 
		  break;
  }
  
 /* 
  if (op == 1)
    printf("\n%f + %f = %f",a,b,a+b);
    else
      if (op == 2)
  	    printf("\n%f - %f = %f",a,b,a-b);
  	    else
    	  if (op == 3)
            printf("\n%f * %f = %f",a,b,a*b);
            else
               if (op == 4)	
               	 if( b == 0)
               	 	printf("\nErro de divis�o por zero");
               	    else
                      printf("\n%f / %f = %f",a,b,a/b);
                 else
				 	printf("\nOp��o inv�lida"); 
*/
  return 0;
}