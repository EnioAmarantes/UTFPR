/*
Quest�o 01:
Desenvolver um algoritmo que efetue a leitura de 5x5 elementos de uma matriz A.
Ao final, apresente o total da soma de todos os elementos que sejam �mpares.
*/
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int m[5][5], l, c, soma;
  srand(time(NULL));
//preenche a matriz com n�meros rand�micos
  for(l = 0;l < 5;l = l + 1)
    for(c = 0;c < 5;c = c + 1)
      m[l][c] = rand() /1000;
//imprime a matriz
  for(l = 0;l < 5;l = l + 1){
    for(c = 0;c < 5;c = c + 1)
      printf("%4d",m[l][c]);
    printf("\n");
  }
//soma todos os elementos �mpares da matriz
  soma = 0;
  for(l = 0;l < 5;l = l + 1)
    for(c = 0;c < 5;c = c + 1)
      if (m[l][c] % 2 != 0)
         soma = soma + m[l][c];
//mostra a soma
  printf("\nA soma dos valores �mpares � %d \n",soma);

  return 0;
}
