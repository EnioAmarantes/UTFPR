/*
Escreva um programa que receba um intervalo fechado [n1, n2] do usu�rio, e 
que mostre todos os n�meros na tela da seguinte forma: (na primeira coluna 
cada n�mero do intervalo, e na segunda coluna cada n�mero correspondente invertido)

1002 - 2001
1003 - 3001
.....
4521 - 1254

a)	Os limites do intervalo s�o fornecidos pelo usu�rio;
b)	O programa deve verificar se n1 e n2 s�o positivos e maiores do que 1;
c)	Caso n1 e/ou n2 sejam menores do que 1, ou se n1 for maior ou igual a n2, 
o programa deve solicitar novamente a entrada de dados;
d)	Este programa n�o pode utilizar nenhuma fun��o de manipula��o de strings
 e/ou de convers�o de tipos;
e)	Este programa deve utilizar somente vari�veis do tipo inteiro.
*/
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int n1, n2, aux;
    printf("\nInverte os n�meros no intervalo fechado N1..N2");
    do{
		printf("\nInforme o valor de N1: ");
		scanf("%d",&n1);
	}while (n1 < 2);
    do{
		printf("\nInforme o valor de N2: ");
		scanf("%d",&n2);
	}while (n2 <= n1);		
	while (n1 <= n2){
		printf("%d - ",n1);
		aux = n1;
		while (aux > 0){
			printf("%d",aux % 10);
			aux = aux / 10;
		}
		n1 = n1 + 1;
		printf("\n");
	}
	return 0;
}