//04 - Calcular o volume de um cilindro. Perguntar ao usu�rio se h� outros 
//c�lculos a serem realizados para continuar ou n�o o algoritmo.
//Entrada: altura e raio do cilindro
//Sa�da: volume do cilindro
//Processamento: volume = M_PI * pow(raio,2.0) * altura
//               executar o c�lculo para tantos casos quantos o usu�rio desejar
#include <math.h> 
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
    float raio, altura, volume;
    int op;
    op = 1;
    while(op == 1){
    	printf("Digite o raio do cilindro: ");
    	scanf("%f",&raio);
    	printf("Digite a altura do cilindro: ");
    	scanf("%f",&altura);  	
    	volume = M_PI * pow(raio,2.0) * altura;
//pow(x,y) - resolve x elevado a y; tanto x quanto y devem ser float ou double
        printf("O volume do cilindro � %f \n",volume);
		printf("\nDigite 1 para continuar ou 2 para encerrar: ");
		scanf("%d",&op);
	}

	return 0;	
}
