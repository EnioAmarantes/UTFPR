#include <stdio.h>
main(){
  int n;
  printf("Digite um numero inteiro: ");
  scanf("%d", &n);
  if ((n >= 1000) && (n <= 9999)){
    printf("\nnumero lido -> %d", n);
    printf("\nunidade -----> %d", n % 10);
    printf("\ndezena ------> %d", n % 100 - n % 10);
    printf("\ncentena -----> %d", n % 1000 - n % 100);
    printf("\nmilhar ------> %d", n % 10000 - n % 1000);
  }
  else
    printf("\nO numero esta fora da faixa de valores validos");
}
