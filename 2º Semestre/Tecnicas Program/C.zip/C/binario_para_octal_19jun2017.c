#include <stdio.h>
#include <string.h>
#include <locale.h>
void maiszeros(char [], int);
int main(){
	setlocale(LC_ALL,"Portuguese");
	int i;
	char valor[50];
	char copia[] = "\0\0\0";
   
    for(i = 0;i < 50;i++)
    	valor[i] = '\0';
			
    printf("\nDigite um valor binario: ");
    gets(valor);
      
	if (strlen(valor) % 3 == 1)
		maiszeros(valor,2);
	    else
	    	if (strlen(valor) % 3 == 2)
	    	    maiszeros(valor,1);
	
	for(i = 0;i < strlen(valor);i = i + 3){
		strncpy(copia, &valor[i], 3);
	    if (strcmp(copia,"000") == 0) 
		   printf("%d",0);
	       else if (strcmp(copia,"001") == 0) 
		      printf("%d",1);
		      else if (strcmp(copia,"010") == 0) 
			     printf("%d",2);
			     else if (strcmp(copia,"011") == 0) 
			        printf("%d",3);
					else if (strcmp(copia,"100") == 0) 
					   printf("%d",4);
				       else if (strcmp(copia,"101") == 0) 
					      printf("%d",5);
					      else if (strcmp(copia,"110") == 0) 
						     printf("%d",6);
						     else if (strcmp(copia,"111") == 0) 
							    printf("%d",7);			
	}
	return 0;
}

void maiszeros(char bin[], int t){
    int i;
	for(i = strlen(bin) + 1;i > t-1;i--){
		  bin[i] = bin[i - t];	
    }
	for(i = 0;i < t;i++){
		bin[i] = '0';
    }
}








