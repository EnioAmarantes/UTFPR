#include <stdio.h>
main(){
  char n[50];
  float p, a;
  printf("informe seu nome: ");
  gets(n);
  printf("informe sua altura: ");
  fflush(stdin);
  scanf("%f",&a);
  printf("informe seu peso: ");
  fflush(stdin);
  scanf("%f",&p);
  printf("%s seu peso eh %.2f e sua altura eh %.2f\n", n, p, a);
  system("pause");
}
