#include <stdio.h>

main(){
  float S, d;

/*  for(S = 1, d = 2; d <= 3; d++)
    S = S + ((d * 2) -1) / d;
*/

  S = 1;
  d = 2;
  while (d <= 3){
    S = S + ((d * 2) -1) / d;
    d++;
  }


  printf("%f",S);
}
