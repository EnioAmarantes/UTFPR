#include <stdio.h>
#include <stdlib.h>
main ()
{
printf("HORA: %s\n",__time64_t__);

}
