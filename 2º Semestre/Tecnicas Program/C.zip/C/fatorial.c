#include <stdio.h>

main(){
  float fat, y;

  scanf("%f",&fat);
  y = fat - 1;


  while(y > 1){
    fat = fat * y;
    y = y - 1;
  }

  do{
    fat = fat * y;
    y = y - 1;
  }while (y > 1);

  for(;y > 1;fat = fat * y, y--)

  printf("%f",fat);
}
