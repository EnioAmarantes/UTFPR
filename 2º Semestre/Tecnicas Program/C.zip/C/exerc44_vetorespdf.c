//44. Leia uma matriz M[5,5]. A seguir, ordene os elementos da matriz M e
// mostre como ficou a Matriz ordenada, linha por linha.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define L 5
#define C 5
int main(){
	int m[L][C], r, i, i2, j, j2, a, b, aux;
	
	srand(time(NULL));
		
  //preenche a matriz com n�meros rand�micos n�o repetidos
  i = 0;
  while (i < L){
    j = 0;
    while (j < C){
      aux = rand()/100;
      r = 0;
      for(i2 = 0; i2 <= i; i2++)
        for(j2 = 0; j2 <= j; j2++)
          if (m[i2][j2] == aux)
             r = 1;
      if (r == 0){
        m[i][j] = aux;
        j++;
      }
    }
    i++;
  }
  
    printf("\n");
//impress�o do conte�do da matriz
    for(i = 0;i < L;i = i + 1){
		for(j = 0;j < C;j = j + 1)
			printf("%4d",m[i][j]);
		printf("\n");    
	}	    
//ordena��o da matriz pelo m�todo da bolha
    for(i = 0;i < L;i++)
       for(j = 0;j < C;j++)
       	  for(a = 0;a < L;a++)
       	  	  for(b = 0;b < C;b++)
                 if (m[i][j] < m[a][b]){
	                aux = m[i][j];
	                m[i][j] = m[a][b];
                    m[a][b] = aux;
                 }
//impress�o da matriz ordenada                 
    printf("\n");
    for(i = 0;i < L;i = i + 1){
		for(j = 0;j < C;j = j + 1)
			printf("%4d",m[i][j]);
		printf("\n");    
	}
 
   return 0;  
} 