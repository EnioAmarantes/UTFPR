// A fun��o RandomInteger devolve um inteiro
// aleat�rio entre low e high inclusive,
// ou seja, no intervalo fechado low..high.
// O c�digo foi copiado da biblioteca random
// de Eric Roberts.

int RandomInteger (int low, int high)
{
    int k;
    double d;
    d = (double) rand () / ((double) RAND_MAX + 1);
    k = d * (high - low + 1);
    return low + k;
}
