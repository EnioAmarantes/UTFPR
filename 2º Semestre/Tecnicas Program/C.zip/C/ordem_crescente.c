#include <stdio.h>
main(){
  int a, b, c, d, aux;
  printf("\n digite um numero inteiro para a: ");
  scanf("%d", &a);
  printf("\n digite um numero inteiro para b: ");
  scanf("%d", &b);
  printf("\n digite um numero inteiro para c: ");
  scanf("%d", &c);
  printf("\n digite um numero inteiro para d: ");
  scanf("%d", &d);
  if (a > b) {
      aux = a;
      a = b;
      b = aux;
      }
  if (b > c) {
      aux = b;
      b = c;
      c = aux;
      }
  if (c > d) {
      aux = c;
      c = d;
      d = aux;
      }
  if (a > b) {
      aux = a;
      a = b;
      b = aux;
      }
  if (b > c) {
      aux = b;
      b = c;
      c = aux;
      }
  if (a > b) {
      aux = a;
      a = b;
      b = aux;
      }
  printf("\n%d %d %d %d\n", a, b, c, d);
  getch();
}
