/*04 -  Elaborar um programa que l� um conjunto de 30 valores e os coloca em 2 
vetores de dimens�o 5, uma para n�meros pares e outro para n�meros �mpares. 
Se algum vetor estiver cheio, mostrar o seu conte�do, e depois continuar a
preenche-lo do in�cio. Ao final da leitura dos 30 valores, escrever o conte�do 
dos dois vetores. Cada vetor pode ser preenchido tantas vezes quantas for 
necess�rio.*/
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T1 30
#define T2 5
main(){	
  int par[T2], impar[T2], total[T1];
  int i, j, ip, ii, aux;
//ip - �ndice par
//ii - �ndice �mpar  
  setlocale(LC_ALL, "Portuguese");
  srand(time(NULL));	
  ip = 0;
  ii = 0;	
  for(i = 0; i < T1; i++){
	 aux = rand()/100; 
	 total[i] = aux;
	 if ((aux % 2 == 0) && (ip < T2)){
	 	par[ip] = aux;
	 	ip++;
	 }
	 if ((aux % 2 != 0) && (ii < T2)){
		impar[ii] = aux;
		ii++; 
	 }
	 if (ip == T2){
	 	printf("\nVetor com n�meros pares\n");
	 	for(j = 0;j < T2; j++)
	 		printf("%4d",par[j]);
	 	ip = 0;
	 } 
 	 if (ii == T2){
	 	printf("\nVetor com n�meros �mpares\n");
	 	for(j = 0;j < T2; j++)
	 		printf("%4d",impar[j]);
	 	ii = 0;
	 } 
  }	
  printf("\nVetor com n�meros pares - final\n");
  for(j = 0;j < ip; j++)
	printf("%4d",par[j]);
  printf("\nVetor com n�meros �mpares - final\n");
  for(j = 0;j < ii; j++)
    printf("%4d",impar[j]);	
  printf("\nTodos os n�meros gerados\n");
  for(i = 0;i < T1; i++)
    printf("%4d",total[i]);	
  printf("\n");
}