#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
#define T 10 //dimens�o do vetor
#define L 15 //dimens�o das linhas da matriz
#define C 15 //dimens�o das colunas da matriz
int main(){
  setlocale(LC_ALL,"Portuguese");
  int v[T];
  int m[L][C];
// OU
//  int m[L][C] = {1,2,3,4,5,6,7,8,9};
  int i, j, maior;

//-----------VETOR-----------

//preenche o vetor
  srand(time(NULL));
  for(i = 0;i < T;i = i + 1){
//     printf("digite um valor para o vetor: ");
//     scanf("%d",&v[i]);
    v[i] = rand() / 1000;
  }
//imprime o vetor
  for(i = 0;i < T;i = i + 1){
     printf("%d ",v[i]);
  }
//encontrar o maior elemento do vetor]
  maior = v[0];
  for(i = 1;i < T;i = i + 1){
    if (v[i] > maior)
      maior = v[i];
  }
  printf("\nmaior --> %d",maior);

  printf("\n\n");
//-----------MATRIZ-----------

  for(i = 0;i < L;i = i + 1)
    for(j = 0;j < C;j = j + 1)
      m[i][j] = rand() / 100;

//imprime a matriz
  for(i = 0;i < L;i = i + 1){
    for(j = 0;j < C;j = j + 1)
      printf("%4d",m[i][j]);
    printf("\n");
  }

  return 0;
}
