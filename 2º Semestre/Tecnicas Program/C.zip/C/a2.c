#include<stdio.h>
main()
{
float ari, pon, har;
float a, b, c;
printf("Informe o valor de A: ");
scanf("%f",&a);
printf("Informe o valor de B: ");
scanf("%f",&b);
printf("Informe o valor de C: ");
scanf("%f",&c);

ari = ((a + b + c) / 3);
pon = ((a * 3 + b * 2 + c * 5) / 10);
har = (3 / (1 / a + 1 / b + 1 / c));

printf("A media aritimetica de %0.2f, %0.2f e %0.2f = %0.2f\n",a,b,c,ari);
printf("A media ponderada de %.2f, %.2f e %.2f = %.2f\n",a,b,c,pon);
printf("A media harmonica de %.2f, %.2f e %.2f = %.2f\n",a,b,c,har);
getchar();
getchar();
}
