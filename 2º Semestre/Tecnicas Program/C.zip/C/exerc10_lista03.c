//        1      3      5      7          99
// s = + ---- - ---- * ---- / ---- + ... ----
//        1      2      3      4          50
#include <stdio.h>
#include <stdlib.h>
int main(){
	float x, y, s;
	int sinal;
	x = 1;
	y = 1;
	s = 0;
	sinal = 0;
	while (x <= 99){
		if (sinal == 0){
		   s = s + (x / y);
		   sinal = 1;
		}
		else
			if (sinal == 1){
			   s = s - (x / y);
		       sinal = 2;
		    }
		    else
		    	if (sinal == 2){
					s = s * (x / y);
					sinal = 3;
				}
				else{
					s = s / (x / y);
					sinal = 0;
				}
		x = x + 2;
		y = y + 1;
	}
	printf("\n %f\n ",s);
	system("pause");
	return 0;
}