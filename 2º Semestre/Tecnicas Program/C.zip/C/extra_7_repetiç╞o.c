#include <stdio.h>
#include <math.h>

main(){

  int x, i, sinal;
  double j, k, soma, fat;
  soma=1;
  sinal = -1;
  j = 2;

printf("\nDigite um valor para calcular o coseno x:");
scanf("%d", &x);

for(i = 1 ; i <= 20 ; i++){

  fat = j;
  k = j - 1;
  while(k > 1){
    fat = fat * k;
    k--;
  }
   soma = soma + pow(x,j)/fat * sinal;
   sinal = sinal * -1;
   j = j + 2;
}
printf("\nSoma = %f", soma);
printf("\nCos = %f",cos(x));
printf("\nDiferenca entre cos e soma = %f",soma-cos(x) );

}
