//Quest�o 02 (1,0): 
//N�meros amig�veis s�o pares de n�meros onde um deles � a soma dos divisores 
//do outro. Por exemplo:
//Os divisores de 220 s�o 1, 2, 4, 5, 10, 11, 20, 22, 44, 55 e 110, cuja soma � 284. 
//Os divisores de 284 s�o 1, 2, 4, 71 e 142 e a soma deles � 220. 2.
//Escreva um programa que receba v�rios conjuntos de dois n�meros inteiros,
//mostrando se os mesmos s�o amig�veis ou n�o. O programa deve mostrar cada n�mero,
//seus divisores, e a soma dos divisores:
//Os divisores de 220 s�o 1, 2, 4, 5, 10, 11, 20, 22, 44, 55 e 110 = 284
//Os divisores de 284 s�o 1, 2, 4, 71 e 142 = 220
//Estes n�meros s�o amig�veis
//
//Os divisores de 1184 s�o 1, 2, 4, 8, 16, 32, 37, 74, 148, 296, 592 = 1210
//Os divisores de 1210 s�o 1, 2, 5, 10, 11, 22, 55, 110, 121, 242, 605 = 1184
//Estes n�meros s�o amig�veis

//Os divisores de 96 s�o 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48 = 156
//Os divisores de 76 s�o 1, 2, 4, 19, 38 = 64
//Estes n�meros n�o s�o amig�veis
#include <stdio.h>
#include <locale.h>

int somadiv(int);

int main(){
	setlocale(LC_ALL,"Portuguese");
    int n1, n2; 
	do{
       printf("\nDigite o primeiro n�mero (0 para encerrar): ");
       scanf("%d",&n1);
       printf("Digite o segundo n�mero (0 para encerrar): ");
       scanf("%d",&n2); 		
	   if ((n1 != 0) && (n2 != 0)){
	      if ((somadiv(n1) == n2) && (somadiv(n2) == n1))
	   	    printf("\nEstes n�meros s�o amig�veis\n");
	        else
	           printf("\nEstes n�meros n�o s�o amig�veis\n");
	   }
	}while ((n1 != 0) && (n2 != 0));
	return 0;
}	

int somadiv(int n){
  int a, soma;
  a = 1;
  soma = 0;
  printf("\nOs divisores de %d s�o ",n);	   	
  while (a < n){
    if (n % a == 0){
      printf("%d ",a);
	  soma = soma + a;
    }
	a = a + 1;  
  }
  printf(" = %d",soma);
  return soma;
}