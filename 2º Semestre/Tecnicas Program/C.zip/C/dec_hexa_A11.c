/*
Hexadecimal	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E e F
-----------------------------------------------------------
DECIMAL PARA HEXADECIMAL:
-----------------
Por exemplo, o n�mero 39:
397 div 16 = 24 (resto 13)
24 div 16 = 1 (resto 8) (n�o h� mais nenhuma divis�o, pois, o resto � menor do que 16)
O n�mero decimal 397, convertido para hexadecimal 18D
397 |__16__
 13   24 |__16__
       8   1
10 = A, 11 = B, 12 = C, 13 = D, 14 = E, 15 = F
     65      66      67      68     69       70
*/
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int hex[100], num, i, aux;
  printf("Digite um n�mero inteiro base 10: ");
  scanf("%d",&num);
  i = 0;
  while (num >= 16){
     aux = num % 16;
     switch (aux){
       case 10:
         hex[i] = 65;
         break;
       case 11:
         hex[i] = 66;
         break;
       case 12:
         hex[i] = 67;
         break;
       case 13:
         hex[i] = 68;
         break;
       case 14:
         hex[i] = 69;
         break;
       case 15:
         hex[i] = 70;
         break;
       default:
         hex[i] = aux;
         break;
     }
     i = i + 1;
     num = num / 16;
  }
  hex[i] = num;
  for(;i >= 0;i = i - 1){
    if(hex[i] <= 9)
      printf("%d",hex[i]);
      else
         printf("%c",hex[i]);
  }
  return 0;
}
