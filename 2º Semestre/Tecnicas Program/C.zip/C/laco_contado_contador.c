/*
PARA - Executa um grupo de comandos enquanto a condi��o
       l�gica da estrutura for verdadeira
       � executado 0 ou N vezes, uma vez que a condi��o
       � verificada antes da execu��o dos comandos 
           
SINTAXE:

for([<iniciali��o>];[<condi��o de controle>];[<inc/dec da vari�vel de controle>]) 
{
	[<comando(s)>]
}

<condi��o> - � uma express�o l�gica cujo resultado sempre ser�
             VERDADEIRO ou FALSO
*/
//***********************************************************************
//calcular a m�dia aritm�tica para um grupo de 5 valores reais fornecidos
//pelo usu�rio
//***********************************************************************
//entradas de dados: 
//                  cada um dos 5 valores que o usu�rio ir� fornecer
//sa�das de dados:
//                m�dia dos 5 valores fornecidos pelo usu�rio
//processamento:
//              para cada um dos 5 valores que o usu�rio fornecer, 
//              som�-lo ao valor
//              anterior j� armazenado em uma vari�vel e contar mais um
//              � quantidade de n�meros informados
//              ap�s o usu�rio informar o quinto n�mero
//              calcular a m�dia, dividindo a soma de todos os
//              n�meros por 5
#include <stdio.h>
int main(){ 
  float soma, numero;
  int quantidade;
  soma = 0;

//a estrutura de repeti��o a seguir � controlado por um CONTADOR
//que � uma vari�vel que ter� seu valor alterado (neste cado acrescido de
//1, cada vez que um novo valor for lido)
//quando o limite for alcan�ado a estutura de repeti��o ser� finalizada.
//Utilizamos um CONTADOR quando sabemos de antem�o quantas vezes
//uma estutura de repeti��o ser� executada 
   
  //inicializa��o da vari�vel de controle do la�o de repeti��o
  //condi��o de controle do la�o de repeti��o
  //altera��o do valor da vari�vel de controle
  for(quantidade = 0;quantidade < 5;quantidade = quantidade + 1 ){  
	 printf("Digite um numero: ");
	 scanf("%f",&numero);
	 soma = soma + numero; 
  }
  printf("\nA media e: %f",soma/quantidade);  	
  return 0;	
}