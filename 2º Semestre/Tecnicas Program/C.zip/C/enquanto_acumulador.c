/*
ENQUANTO - Executa um grupo de comandos enquanto a condi��o
           l�gica da estrutura for verdadeira
           � executado 0 ou N vezes, uma vez que a condi��o
           primeiro � verificada e depois os comandos s�o
           executados
           
SINTAXE:

while <condi��o>
{
	<comando(s)>
}

<condi��o> - � uma express�o l�gica cujo resultado sempre ser�
             VERDADEIRO ou FALSO
*/
//***********************************************************************
//calcular a m�dia aritm�tica para um grupo de N valores reais fornecidos
//pelo usu�rio, enquanto a soma destes valores n�o ultrapassar 200
//***********************************************************************
//entradas de dados: 
//                  cada um dos N valores que o usu�rio ir� fornecer
//sa�das de dados:
//                m�dia dos N valores fornecidos pelo usu�rio
//processamento:
//              para cada um dos N valores que o usu�rio fornecer, 
//              som�-lo ao valor anterior j� armazenado em uma vari�vel,
//              contar mais um  � quantidade de n�meros informados
//              e se a soma dos valores for maior que que 200
//              calcular a m�dia, dividindo a soma de todos os
//              n�meros pela quantidade de n�meros informados
#include <stdio.h>
int main(){ 
  float soma, numero;
  int quantidade;
  soma = 0;//inicializa��o da vari�vel de controle do la�o de repeti��o
  quantidade = 0;
//a estrutura de repeti��o a seguir � controlado por um ACUMULADOR
//que � uma vari�vel que ter� seu valor alterado (neste cado acrescido de
//cada valor lido)
//quando o limite for alcan�ado a estutura de repeti��o ser� finalizada.
//Utilizamos um ACUMULADOR quando n�o sabemos de antem�o quantas vezes
//uma estutura de repeti��o ser� executada, e quando o limite de repeti��es
//� determinado por um valor aleat�rio
  while (soma <= 200){  //condi��o de controle do la�o de repeti��o
	 printf("Digite um numero: ");
	 scanf("%f",&numero);
	 soma = soma + numero; //altera��o do valor da vari�vel de controle
	 quantidade = quantidade + 1;
  }
  printf("\nA media e: %f",soma/quantidade);  	
  return 0;	
}