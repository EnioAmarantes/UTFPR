#include <stdio.h>
#include <stdlib.h>
main(){

  int dist[5][5];// = {0,15,396,90,15,15,0,411,75,30,396,411,0,486,411,90,75,486,0,105,15,30,411,105,0};
  char cid[5][30];// = {"Londrina","Cambe","Curitiba","Maringa","Ibipora"};
  int iti[15];// = {0,4,3,2,1,0,3,2,4,1,0,2,1,4,1};
  int soma, i, l, c;
//preenche o vetor de cidades
  for(i = 0; i <= 4; i++){
    printf("\nDigite o nome da cidade com codigo %d : ",i);
    fflush(stdin);
    scanf("%[^\n]s",&cid[i]);
  }
//mostra o conteudo do vetor de cidades
  for(i = 0; i <= 4; i++)
    printf("\n%d - %s",i,cid[i]);
//preenche a diagonal principal da matriz de distancias com zeros
  for(i = 0; i <= 4; i++)
     dist[i][i] = 0;
//preenche a matriz de distancias
  for(l = 1; l <= 4; l++)
    for(c = 0; c < l; c++){
      printf("\nDigite a distancia entre %s e %s : ",cid[l],cid[c]);
      scanf("%d",&dist[l][c]);
      dist[c][l] = dist[l][c];
    }
//mostra o conteudo da matriz de distancias
  for(l = 0; l <= 4; l++){
    for(c = 0; c <= 4; c++)
      printf("%5d",dist[l][c]);
    printf("\n");
    }
//preencher o vetor de itinerario
  for(i = 0; i<= 14; i++){
    printf("Informe o codigo para a %d cidade no itinerario: ",i);
    for(l = 0;l <= 4; l++)
       printf("\n%d - %s",l,cid[l]);
    scanf("\n%d",&iti[i]);
    system("cls");
  }

  printf("\nCidade   \tQuilometragem percorrida\n");
  printf("%s\n",cid[iti[0]]);

  for(i = 1, soma = 0; i <= 14; i++){
     printf("%s   \t%3d\n",cid[iti[i]], dist[iti[i-1]][iti[i]]);
     soma = soma + dist[iti[i-1]][iti[i]];
  }
  printf("\nQuilometragem total\t %d",soma);
}
