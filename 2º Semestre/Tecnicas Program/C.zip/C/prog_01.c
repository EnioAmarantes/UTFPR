#include <stdio.h>
#include <math.h>
main(){
  float m = 2, n = 3;

  printf("\n%f elevado a %f = %f",m,n,pow(m,n));
}
