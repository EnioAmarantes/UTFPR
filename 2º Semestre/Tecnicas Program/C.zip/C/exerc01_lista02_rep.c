#include <stdio.h>
main(){
  float x, y, soma;
  x = 1;
  y = 1;
  soma = 0;
  while(x <= 50){
    soma = soma + y / x;
    x = x  + 1;
    y = y + 2;
  }
  printf("\nSoma --> %f\n", soma);
}
