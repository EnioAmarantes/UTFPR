#include <stdio.h>
#define I 15
#define L 15
#define C 4
void preenchevetor(int[]);
void mostramatriz(int m[L][C]);
void mostravetor(int[]);
int primo(int);
main(){
  int IMPAR[I], R[L][C], i, np1, np2, np3, OK;
  preenchevetor(IMPAR);
  printf("\n\nVetor IMPAR\n\n");
  mostravetor(IMPAR);
//------------------
  srand(time(NULL));
  i = 0;
  while (i < L){
    OK = 0;
    do{
      do{
       np1 = rand()/10;
      }while ((np1 > IMPAR[i]) || (np1 % 2 == 0));
      do{
       np2 = rand();
      }while ((np2 > np1) || (np2 % 2 == 0));
      do{
       np3 = rand();
      }while ((np3 > np2) || (np3 % 2 == 0));
      if ((primo(np1)) && (primo(np2)) && (primo(np3)) && (np1+np2+np3 == IMPAR[i]) && (np1 != np2) && (np2 != np3)){
        R[i][0] = IMPAR[i];
        R[i][1] = np1;
        R[i][2] = np2;
        R[i][3] = np3;
        printf("\n%2d --> %4d = %4d + %4d + %4d",i,R[i][0],R[i][1],R[i][2],R[i][3]);
        i = i + 1;
        OK = 1;
       }
    }while (!(OK));
  }
  printf("\n\nMatriz R\n\n");
  mostramatriz(R);
  printf("\n\n");
 //----------------------
}
void preenchevetor(int v[]){
  int i, x, j, n;
  for(i = 0; i <= I; i++)
    v[i] = 0;
  i = 0;
  srand(time(NULL));
  while (i <= I){
    do{
      x = rand()/10;
    }while ((x <= 5) || (x % 2 == 0));
    n = 0;
    for(j = 0; j < i; j++)
      if (v[j] == x)
        n = 1;
    if (n == 0) {
      v[i] = x;
      i++;
    }
  }
}
void mostravetor(int v[]){
  int i;
  for(i = 0; i < I; i++)
    printf("%d ",v[i]);
  printf("\n");
}
void mostramatriz(int m[L][C]){
  int l, c;
  for(l = 0; l < L; l++){
    for(c = 0; c < C; c++)
      printf("%5d ",m[l][c]);
    printf("\n");
  }
}
int primo(int n){
  int x, p;
  p = 0;
  x = n;
  while (x >= 1) {
    if (n % x == 0)
      p++;
    x--;
  }
  if (p == 2)
    return 1;
    else
       return 0;
}
