#include <stdio.h>

  float soma(n1, n2) float n1, n2;
    {
      return (n1 + n2);
    }

  float subtracao(n1, n2) float n1, n2;
    {
      return (n1-n2);
    }

  float multiplicacao(n1, n2) float n1, n2;
    {
      return (n1*n2);
    }

  float divisao(n1, n2) float n1, n2;
    {
      if ((n1 == 0) || (n2 == 0))
        return 0;
        else
          return (n1/n2);
    }
  main(){
    float a, b;
    int op;
    printf("\ndigite o primeiro numero: ");
    scanf("%f", &a);
    printf("\ndigite o segundo numero: ");
    scanf("%f", &b);
    printf("\nescolha uma das opcoes\n\n1 - soma\n2 - subtracao\n3 - divisao\n4 - multiplicacao\n5 - fim\n") ;
    scanf("%d", &op);
    if (op == 1) printf("a soma e %.2f", soma(a,b));
    if (op == 2) printf("a subtracao e %.2f", subtracao(a,b));

    if (op == 3) printf("a divisao e %.2f", divisao(a,b));
    if (op == 4) printf("a multiplicacao e %.2f", multiplicacao(a,b));
  }
