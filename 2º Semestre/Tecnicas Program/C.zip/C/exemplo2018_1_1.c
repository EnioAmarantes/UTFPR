#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
//soma dois n�meros e mostra o resultado
int main(){
  setlocale(LC_ALL,"Portuguese");

  int i;
  char nomes[3][50];

  printf("digite o primeiro nome: ");
  fflush(stdin);
  gets(nomes[0]);
  printf("digite o segundo nome: ");
  fflush(stdin);
  gets(nomes[1]);
  printf("digite o terceiro nome: ");
  fflush(stdin);
  gets(nomes[2]);

  printf("\nnome 1 --> %s",nomes[0]);
  printf("\nnome 2 --> %s",nomes[1]);
  printf("\nnome 3 --> %s",nomes[2]);

  return 0;

}
