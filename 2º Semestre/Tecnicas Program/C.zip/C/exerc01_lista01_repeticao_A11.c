//01 - Obter o nome e a idade de um usu�rio e escrever na tela a seguinte mensagem:
//Hello! FULANO, voc� tem XX anos, para um grupo de 10 pessoas.
//Entradas: nome e idade
//Sa�da: mensagem 
//Processamento: obter o nome e a idade e mostar a mensagem, 10 vezes.
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	char nome[50];
	int idade, cont;
//cont � um contador que ir� controlar a repeti��o que ser� realizada
//10 vezes, portanto precisa ser inicializado
    cont = 1;
	while (cont <= 10){
		printf("Digite o nome da %d� pessoa: ",cont);
		fflush(stdin);
		gets(nome);
		printf("Digite a idade da %d� pessoa: ", cont);
		scanf("%d",&idade);
		printf("Hello! %s, voc� tem %d anos\n",nome, idade);
		cont = cont + 1;		
	}	
	return 0;
}