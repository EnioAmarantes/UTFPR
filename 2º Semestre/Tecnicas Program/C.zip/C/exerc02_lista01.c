/*
Escreva um programa em linguagem C chamado exercicio2.c que
contenha a declara��o de uma vari�vel do tipo char chamada sexo.
Pe�a ent�o para a pessoa informar por meio do teclado um valor
para esta vari�vel. Se o valor for igual a �M� exiba a seguinte
mensagem �Sexo: Masculino�. Se o valor for igual a �F� exiba a
seguinte mensagem �Sexo: Feminino�. Se for outro valor qualquer
exiba a seguinte mensagem �Sexo: Inv�lido!�.
*/
#include <stdio.h>
#include <locale.h>
 int main(){
   setlocale(LC_ALL,"Portuguese");
   char sexo;
   printf("Digite \"F\" para feminino ou \"M\" para masculino: ");
   scanf("%c",&sexo);
//SEs SIMPLES
   if ((sexo == 'F') || (sexo == 'f'))
     {
       printf("\n1sexo FEMININO");
     }
   if ((sexo == 'M') || (sexo == 'm'))
     {
       printf("\n1sexo MASCULINO  ");
     }
   if ((sexo != 'F') && (sexo != 'f') && (sexo != 'M') && (sexo != 'm'))
     {
       printf("\n1sexo INV�LIDO");
     }
//SEs ENCADEADOS
   if ((sexo == 'F') || (sexo == 'f'))
     {
       printf("\n2sexo FEMININO");
     }
     else
       if ((sexo == 'M') || (sexo == 'm'))
         {
           printf("\n2sexo MASCULINO");
         }
         else
           {
             printf("\n2sexo INV�LIDO");
           }
//SWITCH..CASE
  switch (sexo){
     case 'f': case 'F':
       printf("\n3sexo FEMININO");
       break;
     case 'm': case 'M':
       printf("\n3sexo MASCULINO");
       break;
     default:
       printf("\n3sexo INV�LIDO");
       break;
  }
  return 0;
}
