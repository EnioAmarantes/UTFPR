#include <stdio.h>
main(){
  int n;

  n = 1;

  printf("%d %d %d %d %d",n,n++,++n,n++,++n);


}
