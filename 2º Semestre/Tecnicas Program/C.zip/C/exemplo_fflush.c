#include <stdio.h>
#include <stdlib.h>
int main(){
  int i, id;
  char nome[50];

  for(i = 0;i < 3;i = i + 1){
     printf("Digite a idade: ");
     scanf("%d",&id);
     printf("Digite o nome: ");
     fflush(stdin);
     gets(nome);
     printf("\nNome: %s - idade: %d\n",nome,id);
  }
  return 0;
}
