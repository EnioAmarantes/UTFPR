#include <stdio.h>

main() {
  int n;
  do{
    printf("Digite um numero inteiro: (zero para finalizar) ");
    scanf("%d", &n);
  }while (n != 0);
}
