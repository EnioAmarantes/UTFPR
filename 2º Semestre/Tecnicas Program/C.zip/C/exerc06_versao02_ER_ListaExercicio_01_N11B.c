//6. Apresentar os n�meros inteiros entre 10 e 0,
//ou seja, em ordem decrescente e os n�meros entre
//20 e 30 em ordem crescente
#include <stdio.h>
int main(){
  int n, y;

//------WHILE------
  n = 10;
  y = 20;
  while (n >= 0)
  {
    printf("\n%3d\t%3d",n,y);
    n = n - 1;
    y = y + 1;
  }

  printf("\n\n");
//------FOR------
  for(n = 10, y = 20;n >= 0;n = n - 1, y = y + 1)
  {
    printf("\n%3d\t%3d",n,y);
  }

  printf("\n\n");
//------DO...WHILE------
  n = 10;
  y = 20;
  do
  {
    printf("\n%3d\t%3d",n,y);
    n = n - 1;
    y = y + 1;
  }while (n >= 0);

  return 0;
}
