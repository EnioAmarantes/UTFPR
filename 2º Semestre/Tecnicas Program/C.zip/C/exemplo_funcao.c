//este programa possui uma fun��o para calcular o quadrado de um n�mero
#include <stdio.h>
#include <math.h>
main ()
{
	float x,y;
	printf("X --> ");
	scanf("%f",&x);
	printf("Y --> ");
	scanf("%f",&y);
	printf("\n%f elevado a %f --> %f",x, y, exp(y * log(x)));
	printf("\n%f raiz de %f --> %f",x, y, exp(1.0/y * log(x)));
}
