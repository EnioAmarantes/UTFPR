/*
Voc� deve construir um programa em C, para auxiliar a equipe de controle de uma corrida de autom�veis
(considere que cada corrida possui sempre 20 voltas e 12 carros)
Sua aplica��o dever� informar:
1. Para cada volta (utilizando obrigatoriamente, uma fun��o ou procedimento para cada item abaixo):
  a - n�mero do carro e o tempo da volta mais r�pida;
  b - n�mero do carro e o tempo da volta mais lenta.
2. Para a corrida completa (utilizando obrigatoriamente, uma fun��o ou procedimento para cada item abaixo):
  a - n�mero do carro e o tempo da volta mais r�pida;
  b - n�mero do carro e o tempo da volta mais lenta;
  c - tempo de volta m�dio da corrida;
  d - quais os carros que realizaram volta(s) com tempo menor do que o tempo m�dio de volta da corrida, e em que volta(s) isso aconteceu.
Para tanto, voc� deve utilizar:
  a - Um vetor com dimens�o 264, que dever� armazenar os tempos de cada volta, para tanto considere que os carros s�o
numerados de 0 a 11, e que as 12 primeiras posi��es do vetor (0 a 11) correspondem � primeira volta, as posi��es 12 a 23 � segunda volta,
e assim sucessivamente.
MATRIZ DE INDICES PARA O VETOR QUE CONTER� OS TEMPOS DAS 22 VOLTAS PARA CADA UM DOS 12 CARROS (DIMENS�O 240)
	0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19
0	0	12	24	36	48	60	72	84	96	108	120	132	144	156	168	180	192	204	216	228
1	1	13	25	37	49	61	73	85	97	109	121	133	145	157	169	181	193	205	217	229
2	2	14	26	38	50	62	74	86	98	110	122	134	146	158	170	182	194	206	218	230
3	3	15	27	39	51	63	75	87	99	111	123	135	147	159	171	183	195	207	219	231
4	4	16	28	40	52	64	76	88	100	112	124	136	148	160	172	184	196	208	220	232
5	5	17	29	41	53	65	77	89	101	113	125	137	149	161	173	185	197	209	221	233
6	6	18	30	42	54	66	78	90	102	114	126	138	150	162	174	186	198	210	222	234
7	7	19	31	43	55	67	79	91	103	115	127	139	151	163	175	187	199	211	223	235
8	8	20	32	44	56	68	80	92	104	116	128	140	152	164	176	188	200	212	224	236
9	9	21	33	45	57	69	81	93	105	117	129	141	153	165	177	189	201	213	225	237
10	10	22	34	46	58	70	82	94	106	118	130	142	154	166	178	190	202	214	226	238
11	11	23	35	47	59	71	83	95	107	119	131	143	155	167	179	191	203	215	227	239
*/
#include <stdio.h>

f1(float v[], int carro){  //a - n�mero do carro e o tempo da volta mais r�pida
  float tempo;
  tempo = v[carro];

}

f2(float v[], int carro){  //b - n�mero do carro e o tempo da volta mais lenta

}

main(){

}
