//numero perfeito e um numero cuja soma de seus divisores, exceto ele mesmo
//� igual ao pr�prio n�mero.
//escreva um programa em C que mostre todos os n�meros perfeitos em um 
//intervalo fechado N1..N2 fornecido pelo usu�rio
#include <stdio.h>
#include <windows.h>
void gotoxy(int x, int y){
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x-1,y-1});
}
int main(){
	int n1, n2, soma, aux, linha;
	do{
	  printf("Informe o valor de N1: ");
	  scanf("%d",&n1);
	}while (n1 <= 0);  
	do{
	  printf("Informe o valor de N2: ");
	  scanf("%d",&n2);
	}while (n2 < n1);  
	linha = 3;
    while (n1 <= n2){
  	aux = 1;
  	soma = 0;
	  while ((aux < n1) && (soma <= n1)){
		if (n1 % aux == 0)
			soma = soma + aux;
		aux = aux + 1;
	  }
      if (n1 == soma){
      	gotoxy(1,linha);
      	linha = linha + 1;
		printf("\nO numero %d e perfeito",n1);	
	  }
	  gotoxy(50,1);
	  printf("%d",n1);
	  n1 = n1 + 1;
	}
	gotoxy(1,20);
	return 0;
}