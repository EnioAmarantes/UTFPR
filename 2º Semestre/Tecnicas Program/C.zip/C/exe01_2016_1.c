#include <stdio.h>
int main()
{
   int a, b;
   float x, y;
   a = 13;
   b = 2;
   x = 13;
   y = 2;

   printf("\na mod b %d",a % b);
   printf("\na div b %d",a / b);
   printf("\nx / y %f",x / y);
   printf("\na / y %f",a / y);

   return 0;

}


