#include <stdio.h>

main(){

  int i;

  for(i = 32760; i <= 32800 ; i++)
    printf("%d ",i);
}
