/*
Pit�goras descobriu que existe outra forma de calcula pot�ncia de grau 2: 
atrav�s da soma de n�meros �mpares.
Ele descobriu que n2 � igual a soma dos n primeiros n�meros naturais �mpares.
Exemplo: 5^2 = 1 + 3 + 5 + 7 + 9 = 25
Escreva um programa que utilize o m�todo descrito anteriormente 
para mostrar a pot�ncia de grau 2 de todos os n�meros em um 
intervalo fechado [n1, n2] informado pelo usu�rio.
*/
#include <stdio.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 
  int n1, n2, n, c, impar, soma;
  printf("Calcula a pot�ncia de grau 2 de um n�mero utilizando o m�todo de Pit�goras:");
  printf("\nInforme o valor inicial do intervalo de n�meros: ");
  scanf("%d",&n1);
  printf("\nInforme o valor final do intervalo de n�meros: ");
  scanf("%d",&n2);
  while (n1 <= n2){
    soma = 0;
    impar = 1;
    c = 0;
    n = n1;
    printf("%02d^2 = ",n);
    while(c < n){
  	  printf("%d ",impar);
	  soma = soma + impar;
	  impar = impar + 2;
	  c = c + 1;
	  if(c < n)
	  	printf("+ ");
    }
    printf("= %d\n",soma);
    n1 = n1 + 1;
  }
}