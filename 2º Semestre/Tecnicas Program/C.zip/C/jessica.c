#include <stdio.h>
main()
{
    int mat[5][5], vetit[15], i, j, soma=0, aux=0;
    char vetcid[5][10] = {"Londrina",
                         "Ibipora ",
                         "Maringa ",
                         "Curitiba",
                         "Cambe   "};
    printf("\nPreencha a dist�ncia entre as cidades: ");
    for (i=0; i<5; i++)
    {
        for (j=0+aux; j<5; j++)
        {
            if (i == j)
                mat[i][j] = 0;
            else
            {
                printf("\n%d X %d: ", i, j);
                scanf("%5d", &mat[i][j]);
                mat[j][i] = mat[i][j];
            }
        }
        aux++;
    }
    printf("\n\nPreencha o itiner�rio: ");
    for (i=0; i<15; i++)
    {
        printf("\n%d: ", i);
        scanf("%d", &vetit[i]);
    }
    printf("\n\nDistancia: \n");
    for (i=0; i<5; i++)
    {
        for (j=0; j<5; j++)
          printf("%d ", mat[i][j]);
        printf("\n");
    }
    printf("\n\nItiner�rio: \n");
    for (i=0; i<15; i++)
        printf("%d ", vetit[i]);
    printf("\n\nCidade   Km Percorrida   Km Acumulada \n");
    for (i=0; i<15; i++)
    {
        printf("%s", vetcid[vetit[i]]);
        printf("     ");
        if (i == 0)
            printf(" 0             0");
        else
        {
            soma+= mat[vetit[i]][vetit[i+1]];
            printf("%d            %d", mat[vetit[i]][vetit[i+1]], soma);
        }
        printf("\n");
    }
}
