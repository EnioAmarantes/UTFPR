#include <stdio.h>
#include <string.h>
main(){
  int num;
  char nome[10]="joao";
  char op;
  num = 0;
//0 (zero) � FALSO
//1 (um) � VERDADEIRO
  scanf("%c",&op);

  if (toupper(op) == 'X')
    printf("X");


  if (num)
    printf("\nVERDADEIRO\n");
  else
    printf("\nFALSO\n");

  if ((strcmp("gabriel", nome)) == 0)
    printf("\nigual\n");
  else
    printf("\ndiferente\n");

  printf("\n\nvalor da compara��o STRCMP(gabriel,nome) --> %d\n\n",strcmp("gabriel", nome));
//Um valor menor que zero significa que string1 � menor que string2.
//Um valor zero significa que ambas as strings s�o iguais.
//Um valor maior que zero significa que string1 � maior que string2.
}
