#include <stdio.h>
#include <windows.h>

int main() {
    int i, j;
    int inicio, final, tmili;

    inicio = GetTickCount();
    printf("\ninicio --> %d", inicio);
    /* Substitua o for a seguir pelo trecho de c�digo
       cujo tempo de execu��o dever� ser medido. */
    for (j = 0; j < 10000; j ++)
        for (i = 0; i < 10000; i ++);
    final = GetTickCount();

    printf("\nfinal --> %d", inicio);
    tmili = final - inicio;

    printf("tempo decorrido: %d\n", tmili);
    return 0;
}
