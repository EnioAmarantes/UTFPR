#include <stdio.h>
main(){
  int i, x, maior, menor;
  i = 1;
  maior = -999999;
  menor = 999999;
  do{
    printf("Digite um numero inteiro (0 para finalizar): ");
    scanf("%d",&x);
    i = x;
    if (x > maior)
        maior = x;
    if (x < menor)
        menor = x;
  }while (i != 0);
  printf("\nO maior numero e --> %d", maior);
  printf("\nO menor numero e --> %d", menor);
}
