#include <stdio.h>
main()
{
    float v1, d1, d2;
    printf("digite seu salario: ");
    scanf("%f",&v1);
    d2 = v1*0.02;
    d1 = v1/d2;
    printf("\n\no seu salario e %f", v1);
    printf("\ne o numero de dependentes para esse salario e %f\n", d1);
}
