#include <stdio.h>

main() {
  int n, x;
  printf("Mostra na tela a tabuada de um numero informado pelo usuario\n");
  printf("Digite um numero inteiro: ");
  scanf("%d", &n);

  for(x=0;;)
    printf("%d x %d = %d \n", n, x, (n*x));

  getch();
}
