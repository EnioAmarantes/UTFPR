#include <stdio.h>
#include <time.h>
#define MICRO_PER_SECOND 1000000

main(){
  struct timeval start_time;
  struct timeval stop_time;
  float resul = 0.0;
  gettimeofday( &start_time, NULL );

  gettimeofday( &stop_time, NULL ); no fim

  resul = (float)(stop_time.tv_sec - start_time.tv_sec);
  resul += (stop_time.tv_usec - start_time.tv_usec)/(float)MICRO_PER_SECOND;

  printf("Tempo: %.6f -- ",resul);
}
