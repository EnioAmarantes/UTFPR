#include <stdio.h>
int main(){
  int n, maior, menor, i;
  i = 1;

  printf("Digite o %d numero: ", i);
  scanf("%d",&n);
  maior = n;
  menor = n;
  for(i = 2;i <= 10;i = i + 1){
    printf("Digite o %d numero: ", i);
    scanf("%d",&n);
    if (n > maior)
       maior = n;
    if (n < menor)
       menor = n;
  }
	printf("\nO maior valor e %d",maior);
	printf("\nO menor valor e %d",menor);
  return 0;
}
