#include <stdio.h>

main(){
  int a, b;
  a = 0;
  b = 0;

  while ((a > 0) || (b > 0)){

    printf("%d ", a);

  }

}
