#include <stdio.h>
void preenche(int [], int);
void mostra(int[], int);
int main(){
  int vetor[5];
  printf("\nEndereco de memoria de vetor[0] %d \n",&vetor[0]);
  printf("\nConte�do de vetor[0] %d \n",vetor[0]);
  preenche(vetor,5);
  mostra(vetor,5);
  return 0;
}
void preenche(int v[],int q){
  int i;
  printf("\nEndereco de memoria de v %d \n",&v);
  printf("\nConte�do para o qual aponta v %d \n",*v);
  printf("\nConte�do de v %d \n",v);

  for(i = 0;i < q;i = i + 1,v = v + 1){
    printf("\nDigite o %d valor para o vetor: ",i+1);
    //scanf("%d",&v[i]);
    scanf("%d",v);
  }
}
void mostra(int v[],int q){
  int i;
  printf("\n");
  for(i = 0;i < q;i = i + 1){
    printf("%4d",v[i]);
  }
  printf("\n");
}

