#include <stdio.h>
#define D 6
main(){
  int i, j, x, y, m[D][D];

  //inicializa a matriz com zeros
  for(i = 0; i < D; i++)
    for(j = 0; j < D; j++)
       m[i][j] = 0;

  //mostra o conte�do da matriz
  for(i = 0; i < D; i++){
    for(j = 0; j < D; j++)
      printf("%d\t",m[i][j]);
    printf("\n");
  }

  //preenche a matriz com n�meros rand�micos n�o repetidos
//recebe 1:
//sempre que a linha for 0 ou for 5 i
//sempre que a coluna for 0 ou for 5 j 
  y = 0;
  i = y;
  x = 5;
  while(i < x){
    j = y;
	while (j < x){
	   m[y][j] = y + 1;
       m[x][j] = y + 1;      
       x = x - 1;
   	}
	y = y + 1;
  }

  //mostra o conte�do da matriz
  printf("\n");
  for(i = 0; i <= 5; i++){
    for(j = 0; j <= 5; j++)
      printf("%d\t",m[i][j]);
    printf("\n");
  }
}
