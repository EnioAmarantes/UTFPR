#include <stdio.h>
main(){
  float S, num, n, x, d, y;
  int sinal;

  printf("informe o valor de N: ");
  scanf("%f", &n);

  S = (1 / n) - (2 / (n - 1));
  num = 2;
  sinal = 2;
  d = 3;

  while ((n - num) != 1){
    x = d; y = x - 1;
    while (y > 1){  //calcula o fatorial do numerador
      x = x * y;
      y--;
    }
    if (sinal == 0){
      S = S + (x / (n - num));
      sinal = 1;      }
      else
        if (sinal == 1) {
          S = S - (x / (n - num));
          sinal = 2;
        }
        else
          if (sinal == 2){
            S = S * (x / (n - num));
            sinal = 3;
          }
          else{
            S = S / (x / (n - num));
            sinal = 0;
          }
    num=num*2;
    d++;
  }
  printf("%f", S);
}
