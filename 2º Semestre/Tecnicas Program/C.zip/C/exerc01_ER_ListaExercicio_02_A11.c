/*Um funcion�rio de uma empresa recebe, anualmente, aumento salarial. Sabe-se que:
a) Esse funcion�rio foi contratado em 2005, com sal�rio inicial de R$ 1.000,00.
b) Em 2006, ele recebeu aumento de 1,5% sobre seu sal�rio inicial.
c) A partir de 2007 (inclusive), os aumentos salariais sempre corresponderam
ao dobro do percentual do ano anterior.
Fa�a um programa que determine o sal�rio atual desse funcion�rio.*/
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  float perc, sal;
  int ano, anoatual;
  ano = 2005;
  sal = 1000;
  perc = 1.5;

  printf("\nInforme o ano atual: ");
  scanf("%d",&anoatual);

  printf("\nSal�rio em %d : R$ %2.2f",ano,sal);

  for(ano = 2006;ano <= anoatual;ano = ano + 1){
     printf("\nSal�rio em %d : R$ %2.2f (%2.1f%%)",ano,sal*(perc/100)+sal,perc);
     sal = sal * (perc/100) + sal;
     perc = perc * 2;
  }
  printf("\n\nNovo sal�rio R$ %2.2f\n",sal);
  return 0;
}
