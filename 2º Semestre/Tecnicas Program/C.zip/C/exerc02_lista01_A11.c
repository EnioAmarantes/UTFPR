/*
2. Escreva um programa em linguagem C chamado exercicio2.c que contenha a
declara��o de uma vari�vel do tipo char chamada sexo. Pe�a ent�o para a
pessoa informar por meio do teclado um valor para esta vari�vel.
Se o valor for igual a �M� exiba a seguinte mensagem �Sexo: Masculino�.
Se o valor for igual a �F� exiba a seguinte mensagem �Sexo: Feminino�.
Se for outro valor qualquer exiba a seguinte mensagem �Sexo: Inv�lido!�.
*/
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  char sexo;
  printf("Digite M para masculino ou F para feminino: ");
  scanf("%c",&sexo);
  switch (sexo)
  {
    case 'm':
      printf("\nMasculino");
      break;
    case 'M':
      printf("\nMasculino");
      break;
    case 'f':
      printf("\nFeminino");
      break;
    case 'F':
      printf("\nFeminino");
      break;
    default:
      printf("\nOp��o incorreta");
  }
  return 0;
}
