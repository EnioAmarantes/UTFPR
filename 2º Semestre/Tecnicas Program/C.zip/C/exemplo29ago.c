//03.	Quais os valores armazenados em SOMA, NOME e TUDO, supondo-se que NUM, X, COR, DIA, TESTE e TESTE2 valem,
//respectivamente, 5, 2, "AZUL", "TER�A", FALSE e TRUE
//a. NOME <- DIA
//b. SOMA <- (NUM*2/X) + (X + 1)
//c.  TUDO <- NAO ((TESTE OU TESTE2) E (X <> NUM))
#include <stdio.h>
int main(){
  int teste, teste2, x, num;
  teste = 0;
  teste2 = 1;
  x = 2;
  num = 5;
  printf("%d",!((teste || teste2) && (x != num)));
  return 0;
}
