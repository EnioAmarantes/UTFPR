#include <stdio.h>
main(){
  int n;
  float peso;
  printf("Digite seu peso: ");
  scanf("%f", &peso);
  printf("Selecione uma das opcoes:\n");
  printf("1 - Mercurio\n2 - Venus\n3 - Marte\n4 - Jupiter\n5 - Saturno\n6 - Urano\n");
  scanf("%d", &n);
  switch (n){
    case 1:
        printf("Seu peso em Mercurio e de %2.2f\n", peso/10*0.37);
        break;
    case 2:
        printf("Seu peso em Venus e de %2.2f\n", peso/10*0.88);
        break;
    case 3:
        printf("Seu peso em Marte e de %2.2f\n", peso/10*0.38);
        break;
    case 4:
        printf("Seu peso em Jupiter e de %2.2f\n", peso/10*2.64);
        break;
    case 5:
        printf("Seu peso em Saturno e de %2.2f\n", peso/10*1.15);
        break;
    case 6:
        printf("Seu peso em Urano e de %2.2f\n", peso/10*1.17);
        break;
    default:
        printf("Opcao invalida\n");
  }
  system("pause");
}
