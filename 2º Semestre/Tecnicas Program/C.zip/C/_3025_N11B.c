//o n�mero 3025 possui a seguinte caracter�stica:
//   30 + 25 = 55 --> 55^2 = 3025
//escreva um programa que receba que encontre
//todos os n�meros de quatro d�gitos que possuem a
//mesma caracter�stica do n�mero 3025
#include <stdio.h>
int main(){
  int n, a, b;
  n = 1000;
  while (n <= 9999){
    a = n / 100;
    b = n % 100;
    if ((a + b) * (a + b) == n)
      printf("\n%02d + %02d = %02d --> %02d^2 = %d",a,b,a+b,a+b,n);
    n = n + 1;
  }
  system("pause");
  return 0;
}

