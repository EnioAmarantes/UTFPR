//Quest�o 02 (1,0): 
//
//N�meros amig�veis s�o pares de n�meros onde um deles � a soma dos divisores do outro. 
//Por exemplo:
//Os divisores de 220 s�o 1, 2, 4, 5, 10, 11, 20, 22, 44, 55 e 110, cuja soma � 284. 
//Os divisores de 284 s�o 1, 2, 4, 71 e 142 e a soma deles � 220. 2.
//Escreva um programa que mostre todos os n�meros amig�veis em um intervalo
//fechado [n1, n2] informado pelo usu�rio
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
    int n1, N1, n2, N2, soma1, soma2, prox, a, s;    
//n1 - in�cio do intervalo
//n2 - fim do intervalo
//N1 - recebe o valor atual de n1 - 1 para realizar divis�es sucessivas at� 1
//prox - o pr�ximo valor de n1
//N2 - recebe o valor atual de prox - 1 para realizar divis�es sucessivas at� 1
//soma1 - recebe a soma dos divisores de n1
//soma2 - recebe a soma dos divisores de prox
//a - mostra os divisores de n1 e de prox quando forem amig�veis
//s - mostra a somat�ria de n1 e de prox quando forem amig�veis

//O while 1 percorre o intervalo de n1 a n2
//O while 2 percorre todos os n�meros de n1-1 at� 1, procurando seus divisores;
//          quando uma divis�o exata � encontrada, o valor do divisor � somado a soma1
//O while 3 percorre todo o intervalo de n1 + 1 (prox) at� n2
//O while 4 percorre todos os n�meros de prox - 1 at� 1, procurando seus divisores;
//          quando uma divis�o exata � encontrada, o valor do divisor � somado a soma2
//O if 5    verifica se o valor de soma1 (os divisores do valor atual de n1, que foram obtidos
//          na while 2) � igual a prox E se 0 valor de soma2(os divisores do valor atual de prox,
//          que foram obtidos no while 4) � igual ao valor de n1
//O for 6   mostra todos os dividores do valor atual de n1 e ao final a soma dos mesmos
//O for 7   mostra todos os dividores do valor atual de prox e ao final a soma dos mesmos
    printf("Informe o primeiro valor do intervalo: ");
    scanf("%d",&n1);
    printf("Informe o segundo valor do intervalo: ");
    scanf("%d",&n2);
    while(n1 < n2){ //1
		soma1 = 0;
		N1 = n1 - 1;
		while (N1 >= 1){ //2
			if (n1 % N1 == 0){
				soma1 = soma1 + N1;
			}
			N1 = N1 - 1;
		} //final do while 2
		prox = n1 + 1;
		while(prox <= n2){ //3
		   soma2 = 0;
		   N2 = prox - 1;
		   while (N2 >= 1){//4
			   if (prox % N2 == 0){
			   	  soma2 = soma2 + N2; 
			   }
		       N2 = N2 - 1;
		   }//final do while 4
		   if ((soma1 == prox) && (soma2 == n1)){//5
		   	   printf("\n%d e %d s�o n�meros amig�veis", n1, prox);
               printf("\n   %5d - ",n1);
		   	   for(a = n1 - 1,s = 0;a >= 1;a--){//6
	     	      if (n1 % a == 0){
		   	  	 	 printf("%5d",a);
		   	  		 s = s + a;
                  }
			   }//final do for 6
               printf(" --> %5d",s);  
               printf("\n   %5d - ",prox);
		   	   for(a = prox - 1,s = 0;a >= 1;a--){//7
		   	  	   if (prox % a == 0){
		   	  		  printf("%5d",a);
		   	  		  s = s + a;
                   }
		       }//final do for 7
               printf(" --> %5d",s); 
	       }//final do if 5
  		   prox = prox + 1;
		}//final do while 3
       n1 = n1 + 1;
	} //final do while 1
    return 0;
}