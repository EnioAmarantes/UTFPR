#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int n1, n2, s, x;
	printf("Digite o valor do in�cio do intervalo: ");
	scanf("%d",&n1);
	printf("Digite o valor do fim do intervalo: ");
	scanf("%d",&n2);
    while (n1 <= n2){
  	  x = n1;
	  s = 0;
	  while (x > 0){
		if (n1 % x == 0)
			s = s + 1;
		x = x - 1;
	  }
	  if (s == 2)
		printf("\nO n�mero %d � primo",n1);

	  n1 = n1 + 1;
	}
  return 0;	
}

