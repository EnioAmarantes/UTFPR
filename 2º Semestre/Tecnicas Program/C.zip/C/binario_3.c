//converte um n�mero base 10 para base 2
#include <stdio.h>
int main(){
  int n, x, i, b[100];
  
  printf("Digite um nr para que seja convertido para base 2: ");
  scanf("%d",&n);
  
  x = n;
  i = 0;
  while(x > 0){
     b[i] = x % 2;
	 x = x / 2;
	 i = i + 1; 	   
  }
  printf("\n%d = ",n);
  for(i = i - 1;i >= 0;i--)
  	printf("%d",b[i]);
  
  
  return 0;
}