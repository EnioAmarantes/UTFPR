//1.Construa um algoritmo que, dado um conjunto de valores inteiros e positivos,
// /determine qual o menor valor do conjunto.  O final do conjunto de valores �
//  conhecido atrav�s do valor zero, que n�o deve ser considerado.
#include <stdio.h>
int main(){
	int n, menor, r;
/*
    r = 1;
	do{
		do{
		  printf("Digite um numero inteiro e positivo. Zero para finalizar. ");
		  scanf("%d",&n);
		}while (n < 0);
		if (r == 1){
			menor = n;
			r = 0;
		}
		if ((n < menor) && (n >0))
			menor = n;		
	}while (n != 0);
*/

	for(r = 1, n = -1;n != 0;  ){
		do{
		  printf("Digite um numero inteiro e positivo. Zero para finalizar. ");
		  scanf("%d",&n);
		}while (n < 0);		
		if (r == 1){
			menor = n;
			r = 0;
		}
		if ((n < menor) && (n >0))
			menor = n;			
	}
	
	
	printf("\nO menor numero e %d",menor);
	return 0;
}  
  
  