//Elabore um algoritmo que receba 2 (dois) n�meros reais e execute as opera��es listadas a seguir de acordo com a escolha do usu�rio. Para outras op��es n�o listadas, uma mensagem de erro deve ser informada.
//Escolha do usu�rio	Opera��o
//1	M�dia entre os n�meros digitados.
//2	Diferen�a do maior pelo menor.
//3	Produto entre os n�meros digitados.
//4	Divis�o do primeiro pelo segundo.
//0	Encerrar
//Na opera��o 4 (quatro) n�o pode ser realizada divis�o por 0(zero), e isto deve ser controlado pelo algoritmo.
//O algoritmo deve ser encerrado quando o usu�rio escolher a op��o 0 (zero).
//algoritmo "quest�o 01"
#include <stdio.h>
#include <locale.h>
main(){
  setlocale(LC_ALL, "Portuguese");
  float n1, n2; //  n1, n2 : real
  int opcao; //  opcao : inteiro
//inicio
  opcao = 1; //  opcao <- 1
  while (opcao != 0) {  //  enquanto (opcao <> 0) faca
//    escreval
    printf("\nEscolha uma das op��es abaixo:"); //    escreval("Escolha uma das op��es abaixo: ")
    printf("\n1 - M�dia entre os n�meros digitados");//    escreval("1 - M�dia entre os n�meros digitados")
    printf("\n2 - Diferen�a do maior pelo menor"); //    escreval("2 - Diferen�a do maior pelo menor")
    printf("\n3 - Produto entre os n�meros digitados");//    escreval("3 - Produto entre os n�meros digitados")
    printf("\n4 - Divis�o do primeiro pelo segundo"); //    escreval("4 - Divis�o do primeiro pelo segundo")
    printf("\n0 - Encerrar\n");//    escreval("0 - Encerrar")
    scanf("%d",&opcao);//    leia(opcao)
    if ((opcao >= 1) && (opcao <=4)){   //     se ((opcao >= 1) e (opcao <= 4)) entao
      printf("Digite o primeiro n�mero: "); //escreva("Digite o primeiro numero: ")
      scanf("%f",&n1); //leia(n1)
      printf("Digite o segundo n�mero: "); //escreva("Digite o segundo numero: ")
      scanf("%f",&n2); //leia(n2)
      printf("\n");//escreval
    } //fimse
    if (opcao == 1) //se (opcao = 1) entao
      printf("\nA m�dia � %f\n",(n1+n2)/2); //escreva("A m�dia � ", (n1+n2)/2)
      else //senao
        if (opcao == 2) //se (opcao = 2) entao
          if (n1 > n2) //se (n1 > n2) entao
            printf("\nDiferen�a do maior para o menor %f\n",n1-n2); //escreva("Diferen�a do maior pelo menor ", n1 - n2)
            else //senao
              if (n1 < n2)// se (n1 < n2) entao
                printf("\nDiferen�a do maior pelo menor %f\n",n2-n1);//escreva("Diferen�a do maior pelo menor ", n2 - n1)
                else //senao
                  printf("\nOs n�meros s�o iguais, n�o h� diferen�a entre eles\n");//escreva("Os n�meros s�o iguais, n�o h� diferen�a entre eles")
              //fimse
           //fimse
           else //senao
             if (opcao == 3) //se (opcao = 3) entao
               printf("\nO produto entre os n�meros � %f\n",n1*n2);//escreva("O produto entre os n�meros � ", n1 * n2)
               else //senao
                 if (opcao == 4) //se (opcao = 4) entao
                   if (n2 != 0) //se (n2 <> 0) entao
                     printf("\nA divis�o do primeiro pelo segundo n�mero � %f\n",n1/n2);//escreva("A divis�o do primeiro pelo segundo n�mero � ", n1 / n2)
                     else//senao
                       printf("\nN�o � poss�vel realizar divis�o por zero\n");//escreva("N�o � poss�vel realizar divis�o por zero")
                   //fimse
                   else//senao
                     if (opcao != 0)//se (opcao <> 0) entao
                       printf("\nOp��o incorreta\n");//escreva("Op��o incorreta")
                     //fimse
                 //fimse
             //fimse
        //fimse
    //fimse
  }//fimenquanto
}//fimalgoritmo
