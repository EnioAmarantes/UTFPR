#include <stdio.h>

main() {
  int n, x;
  printf("Mostra na tela a tabuada de um numero informado pelo usuario\n");
  for(n = 1;n <= 10;n++){
    for(x = 1;x <= 10;x++)
      printf("\n%2d x %2d = %2d",n,x,n*x);
    printf("\n\n");
  }
}
