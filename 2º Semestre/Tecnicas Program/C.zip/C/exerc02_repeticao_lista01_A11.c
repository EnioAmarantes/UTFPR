#include <stdio.h>
#include <stdlib.h>
int main(){
   float n1, n2, n3, n4, media, soma;
   int q;
   q = 1;
   soma = 0;
   while (q <= 3)
      {
         printf("\nInforme suas quatro notas separadas por / \n");
         scanf("%f/%f/%f/%f",&n1,&n2,&n3,&n4);
         media = (n1 + n2 + n3 + n4) / 4;
         soma = soma + media;
         printf("\nA media do %d aluno e %2.1f",q,media);
         q = q + 1;
      }
   printf("\nA media da turma e %2.1f",soma/3);
  return 0;
}
