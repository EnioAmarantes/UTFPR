#include <stdio.h>

main()
{
  int num;

  scanf("%d", &num);

  printf("valor da variavel --> %d\n", num);
  printf("endereco de memoria inteiro da variavel --> %d\n", &num);
  printf("endereco de memoria hexadecimal da variavel --> %x\n", &num);


}
