/*
Quest�o 04: 
Os n�meros bin�rios s�o utilizados pelos computadores para processar dados. 
� um sistema de numera��o que, em vez de utilizar 10 algarismos, utiliza apenas 2 (0 e 1).
Veja como converter valores decimais em bin�rios:
Um modo simples de fazer essa convers�o � dividir o n�mero decimal que voc� quer 
converter em bin�rio por dois. Fa�a a divis�o "na m�o", e anote o resto (ser� 0 ou 1). 
Pegue o quociente dessa divis�o e divida-o, tamb�m, por dois. Anote outra vez o resto. 
Fa�a assim at� que o quociente de sua divis�o seja 1 (isto �, a divis�o de 2 por 2). 
O seu n�mero em bin�rio � o quociente da �ltima divis�o mais todos os restos das divis�es, 
do quociente menor para o maior.
Por exemplo, o n�mero 39:
39 � 2 = 19 (resto 1)
19 � 2 = 9 (resto 1)
9 � 2 = 4 (resto 1)
4 � 2 = 2 (resto 0)
2 � 2 = 1 (resto 0)
Logo o n�mero decimal 39, convertido para bin�rio � 100111
Outro exemplo, agora com o n�mero 322
322 � 2 = 161 (resto 0)
161 � 2 = 80 (resto 1)
80 � 2 = 40 (resto 0)
40 � 2 = 20 (resto 0)
20 � 2 = 10 (resto 0)
10 � 2 = 5 (resto 0)
5 � 2 = 2 (resto 1)
2 � 2 = 1 (resto 0)
Logo o n�mero decimal 322, convertido para bin�rio � 101000010
Construa um algoritmo que receba um n�mero inteiro (decimal) e mostre o seu 
correspondente em bin�rio.
*/
#include <stdio.h>
int main(){
	int v[100], i;
	int n, a;
	printf("Digite um numero inteiro: ");
	scanf("%d",&n);
	for(i = 0, a = n;a > 0;i++){
		printf("\n%d mod %d = %d (resto %d)",a,2,a/2,a%2);
		v[i] = a % 2;
		a = a / 2;
	}
	printf("\n");
	for(i = i - 1;i >= 0;i = i - 1)
		printf("%d",v[i]);
	return 0;
}

