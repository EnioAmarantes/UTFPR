#include <stdio.h>
#include <time.h>
main(){
  int a, b, c, aux;
  printf("informe o valor de A: ");
  scanf("%d", &a);
  printf("informe o valor de B: ");
  scanf("%d", &b);
  printf("informe o valor de C: ");
  scanf("%d", &c);
  if (a > b){
    aux = a;
    a = b;
    b = aux;
  }
  if (b > c){
    aux = b;
    b = c;
    c = aux;
  }
  if (a > b){
    aux = a;
    a = b;
    b = aux;
  }
  printf("%d %d %d", a, b, c);
}
