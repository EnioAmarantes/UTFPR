//Escreva um algoritmo que determine se dois valores inteiros e positivos A e B s�o primos entre si.
//Dois n�meros inteiros s�o ditos primos entre si, caso n�o exista divisor comum aos dois n�meros.
#include <stdio.h>
#include <locale.h>
main(){
  setlocale(LC_ALL, "Portuguese");
  int a, b, aux, i, ok;
  printf("digite o valor de a: ");
  scanf("%d", &a);
  printf("digite o valor de b: ");
  scanf("%d", &b);
  if (a > b){
    aux = a;
    a = b;
    b = a;
  }
  i = 2;
  ok = 1;
  while (i < a){
    if ((a % i == 0) && (b % i == 0)){
      printf("\n%d e %d n�o s�o primos entre si.\n",a,b);
      i = a + 1;
      ok =0;
    }
    i++;
  }
  if (ok)
    printf("\n%d e %d s�o primos entre si.\n",a,b);
}
