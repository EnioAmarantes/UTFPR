#include <stdio.h>

main(){

  float soma, c;

  soma = -(2.0 / 50.0);
  c = 49;

  printf("WHILE\n");
  while (c >= 1){
    printf("%.0f - ", c);
    soma = soma + 2 / c;
    c = c - 1;
  }
  printf("\n%f", soma);

  soma = -(2.0 / 50.0);
  c = 49;

  printf("\n\nDO WHILE\n");
  do{
    printf("%.0f - ", c);
    soma = soma + 2 / c;
    c = c - 1;
  } while (c >= 1);
  printf("\n%f", soma);

  printf("\n\nFOR\n");
  for(soma = -(2.0 / 50.0), c = 49; c >= 1; c = c - 1)
  {
    printf("%.0f - ", c);
    soma = soma + 2 / c;
 }
  printf("\n%f", soma);


}
