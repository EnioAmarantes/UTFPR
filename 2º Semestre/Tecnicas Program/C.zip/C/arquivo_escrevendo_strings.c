/* Programa que escreve strings num arquivo.
 * Para encerrar o programa o usu�rio dever� inserir uma linha em branco.
 * Como gets() n�o armazena o caractere de nova linha, � adicionado um antes da string ser gravada no arquivo.
 * Isto � feito para que a string possa ser lida, posteriormente, com fgets() j� que esta fun��o l� a string at� que seja
 * encontrado um caracter de nova linha.
 */
#include <stdio.h>
#include <string.h>
int main()  {
   char string[80];
   FILE *arquivo;

   if((arquivo = fopen("arquivo_1.txt","w")) == NULL)      {
      printf("Erro ao abrir arquivo!!!\n\n");
      return 1;
   }

   do{
     gets(string);
     strcat(string,"\n");
     fputs(string,arquivo);
   }while(*string != '\n');

   fclose(arquivo);

   if((arquivo = fopen("arquivo_1.txt","r")) == NULL)      {
      printf("Erro ao abrir arquivo!!!\n\n");
      return 1;
   }

   while(fgets(string, 20, arquivo) != NULL)
       printf("%s", string);

   fclose(arquivo);

   return(0);
 }
