#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
    int qt, c;
    float n, soma;
    printf("Este programa calcula m�dia geom�trica");
	do{
	  printf("\nInforme a quantidade de n�meros para a m�dia. M�nimo 2 e m�ximo 10 valores: ");
	  scanf("%d",&qt);
	}while ((qt < 2) && (qt > 10));  
	n = 0;
	soma = 1;
	c = 1;
	while (c <= qt){
		printf("Digite o %d� valor: ", c);
		scanf("%f",&n);
		soma = soma * n;
		c = c + 1;
	}
	printf("\n\nA m�dia geom�trica � %f",pow(soma,1.0/qt));
	return 0;
}