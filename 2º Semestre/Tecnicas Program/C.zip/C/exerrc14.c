/*
14. Fa�a um programa que receba o ano de nascimento (int) de uma pessoa
e o ano atual (int), calcule e mostre:
a. A idade dessa pessoa em anos;
b. A idade dessa pessoa em meses;
c. A idade dessa pessoa em dias;
d. A idade dessa pessoa em semanas.
Considere um ano igual a 365 dias e um m�s contendo 30 dias.

entradas de dados:
      ano de nascimento, ano atual
sa�das de dados:
      a. A idade dessa pessoa em anos;
      b. A idade dessa pessoa em meses;
      c. A idade dessa pessoa em dias;
      d. A idade dessa pessoa em semanas.
processamento
      obter o ano de nascimento
      obter o ano atual
      calcular:
         a. A idade dessa pessoa em anos
            ano atual - ano de nascimento
         b. A idade dessa pessoa em meses
            (ano atual - ano de nascimento) / 12
         c. A idade dessa pessoa em dias
            (ano atual - ano de nascimento) / 365
         d. A idade dessa pessoa em semanas
            (ano atual - ano de nascimento) / 48
*/
#include <stdio.h>
 #include <locale.h>
 int main(){
   setlocale(LC_ALL,"Portuguese");
   int an, at;
//   printf("Informe o ano de nascimento: ");
//   scanf("%d",&an);
//   printf("Informe o ano atual: ");
//   scanf("%d",&at);
//OU
   printf("Informe o ano de nascimento separado por / pelo ano atual: ");
   scanf("%d/%d",&an,&at);
   printf("\nIdade em anos...: %d", at - an);
   printf("\nIdade em meses..: %d", (at - an) * 12);
   printf("\nIdade em dias...: %d", (at - an) * 365);
   printf("\nIdade em semanas: %d", (at - an) * 48);
   return 0;
 }
