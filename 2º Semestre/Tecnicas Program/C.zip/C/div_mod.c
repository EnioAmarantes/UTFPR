/*
algoritmo "semnome"
//05 - Ler um n�mero inteiro representando a quantidade
//de alunos de uma turma e informe a quantidade de grupos
//de 4 alunos que podem ser formados, e quantos alunos
//ficam de fora, sem formar um grupo completo
//
//ENTRADA DE DADOS: quantidade de alunos
//
//SA�DA DE DADOS: quantidade de grupos com 4 alunos e quantidade de
//                alunos sem grupo
//
//PROCESSAMENTO: obter o quociente da divis�o inteira da quantidade de
//               alunos por 4 para ter a quantidade de grupos
//               obter o resto da divis�o inteira da quantidade de
//               alunos para ter a quantidade de alunos sem grupo
var
  q, ag, an : inteiro
inicio
  escreva("Informe a quantidade de alunos na turma: ")
  leia(q)
  ag <- q div 4
  an <- q mod 4
  escreval("Haver� ",ag," grupos com 4 alunos na turma")
  escreval("Haver� ",an," alunos sem grupos na turma")

fimalgoritmo
*/
#include <stdio.h>
int main(){

//  int quant, grupos, sem;
  float quant, grupos, sem;
  printf("Digite a quantidade de alunos: ");
//  scanf("%d",&quant);
  scanf("%f",&quant);

  grupos = (int)quant / 4;
  sem = (int)quant % 4;

//  printf("\nGrupos --> %d",grupos);
//  printf("\nAlunos sem grupos --> %d",sem);

  printf("\nGrupos --> %f",grupos);
  printf("\nAlunos sem grupos --> %f",sem);

  return 0;
}
