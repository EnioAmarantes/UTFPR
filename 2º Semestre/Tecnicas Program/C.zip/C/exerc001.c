#include <stdio.h>
main(){
  char n[50];
  float p, a;
  printf("\nInforme seu nome: ");
  gets(n);
  printf("\nInforme seu peso: ");
  fflush(stdin);
  scanf("%f",&p);
  printf("\nInforme sua altura: ");
  fflush(stdin);
  scanf("%f",&a);
  printf("%s sua altura eh %.2f e seu peso eh %.2f\n", n,a,p);
  system("pause");
}
