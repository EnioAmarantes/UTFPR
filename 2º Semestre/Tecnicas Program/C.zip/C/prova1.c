#include <stdio.h>
main(){
  int q, c, sinal;
  float soma, x, y, f, r;
  printf("Informe a quantidade de termos: ");
  scanf("%d", &q);
  c = 0;
  x = 1;
  y = 1;
  soma = 0;
  sinal = 1;
  while (c < q){
    f = x;
    r = x - 1;
    while (r > 0){
      f = f * r;
      r--;
    }
    soma = soma + x / y * sinal;
    sinal = sinal * -1;
    x++;
    y = y * 2 + 1;
    c++;
  }
  printf("Soma -> %f", soma);
}
