#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int count, op;
	float soma, n, peso, somap;
	printf("\nEscolha a m�dia que ser� calculada:");
	printf("\n1 - M�dia aritm�tica");
	printf("\n2 - M�dia ponderada");
	printf("\n3 - M�dia geom�trica");
	printf("\n4 - M�dia harm�nica\n");
	scanf("%d",&op);
	switch (op){
	  case 1:
	  	count = 0;
	  	soma = 0;
	  	do{
		  printf("Digite o %d valor para a m�dia artim�tica (-1 para finalizar): ",count);
		  scanf("%f",&n);
		  if (n >= 0){
		    soma = soma + n;
		    count = count + 1;
	  	  }
	    }while (n != -1);	  	
		printf("M�dia artim�tica --> %f",soma/count);	 
		  break;
	  case 2:
	  	count = 0;
	  	soma = 0;
	  	somap = 0;
	  	do{
		  printf("Digite o %d valor para a m�dia ponderada (-1 para finalizar): ",count);
		  scanf("%f",&n);
		  if(n > -1){
		    printf("Digite o peso do %d� valor para a m�dia ponderada: ",count);
		    scanf("%f",&peso);
		  }
		  if (n >= 0){
		    soma = soma + n * peso;
		    somap = somap + peso;
		    count = count + 1;
	  	  }
	    }while (n != -1);	  	
		printf("M�dia ponderada --> %f",soma/somap);	 
  	    break;
	  case 3:
        count = 0;
        soma = 1;
        do{
	  	  printf("Digite o %d valor para a m�dia geom�trica (-1 para finalizar): ",count);
		  scanf("%f",&n);
		  if (n >= 0){
		    soma = soma * n;
		    count = count + 1;
		  }
	    }while (n != -1);
        soma = pow(soma,1.0/count);
        printf("M�dia geom�trica --> %f",soma);	  	
	    break;	  	
	  case 4:
        count = 0;
        soma = 0;
        do{
	  	  printf("Digite o %d valor para a m�dia harm�nica (-1 para finalizar): ",count);
		  scanf("%f",&n);
		  if (n >= 0){
		    soma = soma + (1.0/n);
		    count = count + 1;
		  }
	    }while (n != -1);
        soma = soma / count;
        soma = pow(soma,-1.0);
        printf("M�dia harm�nica --> %f",soma);	  	
	    break;
     default:
     	printf("\nOp��o inv�lida");
     	break;
	}
  return 0;
}