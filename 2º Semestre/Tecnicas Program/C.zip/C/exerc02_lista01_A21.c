/*
02 - Em uma empresa, os funcion�rios que
   forem solteiros n�o receber�o b�nus natalinos.
   que n�o forem solteiros e tiverem filhos receber�o um b�nus de 20% de seu sal�rio-base
   que n�o forem solteiros e n�o tiverem filhos receber�o um b�nus de 15% de seu sal�rio-base
*/
#include <stdio.h>
main(){
  float salario;
  char es, f;
  printf("Informe o sal�rio: ");
  scanf("%f", &salario);
  printf("O funcionario e solteiro? S para sim ou N para nao ");
  fflush(stdin);
  es = getchar();  //scanf("%c",&es);
  if (es == 'S')
    printf("Dancou, sem bonus...");
    else{
        printf("Possui filhos? S para sim ou N para nao ");
        fflush(stdin);
        f = getchar();  //scanf("%c",&f);
        if (f == 'S')
          printf("Bonus --> %2.2f", salario*0.2);
          else
            printf("Bonus --> %2.2f", salario*0.15);
    }
}
