/*
01 - Calcular o pre�o de venda de um carro.
O pre�o de venda � formado pelo pre�o da montadora, mais 15% de lucro,
mais 11% de IPI, mais 17% de ICM.
As porcentagens s�o sobre o pre�o da montadora, que � lido.
Informe o pre�o final e o valor dos impostos.

entradas de dados: pre�o da montadora
sa�das de dados: pre�o de venda e valor dos impostos
processamento:
              calcular lucro --> pre�o * 0.15
              calcular o IPI --> pre�o * 0.11
              calcular o ICM --> pre�o * 0.17
              calcular o valor de venda --> pre�o + lucro + IPI + ICM
              calcular o valor do impostos --> IPI + ICM
*/
#include <stdio.h> //permite a utiliza��o de comandos de entrada e de sa�da
#include <locale.h> //permite a utiliza��o de acentua��o de caracteres
int main(){
//declara��o de vari�veis
//SINTAXE --> TIPO_DE_DADO lista_de_vari�veis;
  float preco, valorvenda, valorimpostos, ipi, icm, lucro;
  setlocale(LC_ALL,"Portuguese"); //configura a sa�da de tela para apresentar caracteres acentuados da l�ngua portuguesa
//printf --> comando de sa�da SINTAXE -->  printf("constante caracter");
  printf("Informe o pre�o da montadora: ");//  escreva("Informe o pre�o da montadora: ")
//scanf --> comando de entrada SINTAXE --> scanf("diretiva",endere�o_de_mem�ria_da_vari�vel);
//                                         diretiva --> indica o tipo de dado da vari�vel que ser� lida
  scanf("%f",&preco); //leia(preco)
//em algoritmo o comando de atribui��o � uma seta para a esquerda <-
//em linguagem C o comando de atribui��o � o sinal de igual =
  lucro = preco * 0.15; //lucro <- preco * 0.15
  ipi = preco * 0.11;   //ipi <- preco * 0.11
  icm = preco * 0.17;   //icm <- preco * 0.17
  valorimpostos = ipi + icm; //valorimpostos <- ipi + icm
  valorvenda = preco + lucro + ipi +icm; //valorvenda <- preco + lucro + ipi + icm
//printf("constante caracter DIRETIVA",vari�vel);
//  \n --> insere uma quebra de linha no texto
  printf("\nO pre�o de venda do ve�culo � de %2.2f",valorvenda);
//  escreval("O pre�o de venda do ve�cula � de ",valorvenda)
  printf("\nO valor dos impostos � de %2.2f",valorimpostos);
//  escreval("O valor dos impostos � de ",valorimpostos)
  return 0;
}
