/*
OCTAL PARA BIN�RIO:

A convers�o de octal para bin�rio � feita convertendo d�gito a d�gito de octal
em bin�rio, da direita para a esquerda. Cada digito � convertido para um grupo
de 3 bits, conforme tabela a seguir:

Octal	Bin�rio
0		000
1		001
2		010
3		011
4		100
5		101
6		110
7		111

Para entender esse processo, vamos converter o n�mero 17548 para bin�rio:

1	7	5	4
001	111	101	100
1754 = 001111101100
*/
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <string.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  char v[100], R[100]; //v - � o n�mero octal
                       //R - � o n�mero bin�rio
  int i, j;
  printf("Digite um n�mero octal (base 8): ");
  fflush(stdin);
  gets(v);
//strlen(v) - devolve a quantidade de elementos armazenados no vetor
  for(i = 0,j = 0;i < strlen(v);i = i + 1,j = j + 3){
    if (v[i] == '0'){
	  R[j] = '0';
	  R[j+1] = '0';
	  R[j+2] = '0';
	}
      else if (v[i] == '1'){
	    R[j] = '0';
	    R[j+1] = '0';
	    R[j+2] = '1';
      }
        else if (v[i] == '2'){
	      R[j] = '0';
	      R[j+1] = '1';
	      R[j+2] = '0';
        }
          else if (v[i] == '3'){
	        R[j] = '0';
	        R[j+1] = '1';
	        R[j+2] = '1';
		  }
            else if (v[i] == '4'){
	          R[j] = '1';
	          R[j+1] = '0';
	          R[j+2] = '0';
			}
              else if (v[i] == '5'){
	            R[j] = '1';
	            R[j+1] = '0';
	            R[j+2] = '1';
			  }
			    else if (v[i] == '6'){
	              R[j] = '1';
	              R[j+1] = '1';
	              R[j+2] = '0';
				}
                  else if (v[i] == '7'){
	                R[j] = '1';
	                R[j+1] = '1';
	                R[j+2] = '1';
				  }
  }
  R[j] = '\0';

  printf("\n%s\n",R);

  return 0;
}
