#include<stdio.h>
main()
{
char frase[50];
printf("Digite a uma frase: ");
scanf("%[0-9]s",&frase);
printf("A frase digitada foi: %s\n", frase);
}
