#include <stdio.h>
#include <math.h>
int main(){

  printf("\nf)23 mod 4 --> %d",23 % 4);

  return 0;
}
