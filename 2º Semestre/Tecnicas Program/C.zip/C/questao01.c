/*
Quest�o 01 (5,0):
Escrever um algoritmo, utilizando sele��o encadeada, para ler 3(tr�s) notas,
o n�mero de faltas e o nome do aluno e informar se ele foi aprovado ou n�o,
considerando a tabela abaixo:

Faltas       Media   Mensagens a serem mostradas

  <9       <7   Quantidade de faltas aceit�veis, mas o aluno foi reprovado por nota.
  <9       >=7   Quantidade de faltas aceit�veis, o aluno foi aprovado.
  >8 e <18    <8   Para essa quantidade de faltas a media foi baixa.
  >8 e <18   >=8   Aluno aprovado apesar das faltas
  >17 e <26   <9   Para essa quantidade de faltas a media foi baixa.
  >17 e <26   >=9   Aluno aprovado apesar das faltas.
  >25       <10   Para essa quantidade de faltas a media foi baixa.
  >15       =10   Esse n�o precisava mesmo assistir as aulas.
*/
#include <stdio.h>

main(){
  char nome[50];
  float n1, n2, n3, media;
  int faltas;

  printf("Digite o nome do aluno: ");
  scanf("%s", &nome);
  printf("Digite a primeira nota: ");
  scanf("%f",&n1);
  printf("Digite a segunda nota: ");
  scanf("%f",&n2);
  printf("Digite a terceira nota: ");
  scanf("%f",&n3);
  printf("Digite a quantidade de faltas: ");
  scanf("%d",&faltas);
  media = (n1 + n2 + n3) / 3.0;
  if ((faltas < 9) && (media  < 7))
    printf("1 - Quantidade de faltas aceit�veis, mas o aluno foi reprovado por nota.");
    else
      if ((faltas < 9) && (media  >= 7))
        printf("2 - Quantidade de faltas aceit�veis, o aluno foi aprovado.");
        else
          if ((faltas > 8) && (faltas < 18) && (media  < 8))
            printf("3 - Para essa quantidade de faltas a media foi baixa.");
            else
              if ((faltas > 8) && (faltas < 18) && (media  >= 8))
                printf("4 - Aluno aprovado apesar das faltas");
                else
                  if ((faltas > 17) && (faltas < 26) && (media  < 9))
                    printf("5 - Para essa quantidade de faltas a media foi baixa.");
                    else
                      if ((faltas > 17) && (faltas < 26) && (media  >= 9))
                        printf("6 - Aluno aprovado apesar das faltas.");
                          else
                          if ((faltas > 25) && (media  < 10))
                            printf("7 - Para essa quantidade de faltas a media foi baixa.");
                            else
                              if ((faltas > 15) && (media  == 10))
                                printf("8 - Esse n�o precisava mesmo assistir as aulas.");
}
