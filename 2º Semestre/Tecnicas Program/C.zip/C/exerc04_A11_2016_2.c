//04 - Tendo como dados de entrada dois pontos quaisquer de um plano 
//cartesiano P(X1,Y1)e Q(X2,Y2) calcule e mostre a dist�ncia entre eles.
//A dist�ncia � dada pela f�rmula: raiz((X2 - X1)^2 + (Y2 - Y1)^2)
//Entradas: x1, y1, x2, y2
//Sa�da: d
//Processamento: d = pow(pow(x2-x1,2) + pow(y2-y1,2),1.0/2.0)
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(){
  float x1, x2, y1, y2, d;
  setlocale(LC_ALL,"Portuguese");
  printf("Digite os valores de X e Y para o primeiro ponto (pressione ENTER ap�s cada n�mero): ");
  scanf("%f %f",&x1, &y1);
  printf("Digite os valores de X e Y para o segundo ponto (pressione ENTER ap�s cada n�mero): ");
  scanf("%f %f",&x2, &y2);
  d = pow(pow(x2-x1,2) + pow(y2-y1,2),1.0/2.0);
  printf("\nA dist�ncia entre os dois pontos � de %f\n",d);
  system("pause");
  return 0;
}  