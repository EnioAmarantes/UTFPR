#include <stdio.h>
#include <locale.h>
 int main(){
   setlocale(LC_ALL,"Portuguese");
   int op;
   float  temp;
   printf("Digite \n1 para temperatura em CELSiUS ou \n2 para temperatura em FARENHEIT\n");
   scanf("%d",&op);
/*
//SEs ENCADEADOS
   if (op == 1)
    {
      printf("Digite a temperatura em CELSIUS: ");
      scanf("%f",&temp);
      printf("A temperatura em FARENHEIT й de %f",1);
    }
    else
    {
      if (op == 2)
      {
        printf("Digite a temperatura em FARENHEIT: ");
        scanf("%f",&temp);
        printf("A temperatura em CELSIUS й de %f",2);
      }
      else
      {
        printf("opзгo incorreta");
      }
    }
*/
//SWITCH..CASE
  switch (op){
     case 1:
       printf("Digite a temperatura em CELSIUS: ");
       scanf("%f",&temp);
       printf("A temperatura em FARENHEIT й de %f",1);
       break;
     case 2:
       printf("Digite a temperatura em FARENHEIT: ");
       scanf("%f",&temp);
       printf("A temperatura em CELSIUS й de %f",1);
       break;
     default:
       printf("opзгo incorreta");
       break;
  }
  return 0;
 }
