/*
08 - Calcular o sal�rio final de um trabalhador, recebendo a quantidade de
horas trabalhadas, a quantidade de horas extras,
quantidade de horas ausentes e o valor do sal�rio m�nimo, sabendo que:
a)as horas trabalhadas e ausentes valem 4% do sal�rio m�nimo;
b)as horas extras valem 50% a mais do que as horas trabalhadas;
c)o sal�rio final � igual a soma das horas trabalhadas com as hora extras,
descontadas as horas ausentes e 11% de INSS.

entradas de dados:
      quantidade de horas trabalhadasv - qht
      quantidade de horas extras - qhe
      quantidade de horas ausentes - qha
      valor do sal�rio m�nimo - vsm
sa�das de dados:
      sal�rio final
processamento:
      obter qht
      obter qhe
      obter qha
      obter vsm
      calcular o valor total de horas trabalhadas: - vht
            valor de horas trabalhadas = qht * (vsm * 0.04)
      calcular o valor total de horas ausentes: - vha
            valor de horas ausentes = qha * (vsm * 0.04)
      calcular o valor total de horas extras: - vhe
            valor de horas extras = qhe * (vsm * 0.06)
      calcular o sal�rio final:
            sf  = (vht + vhe - vha) * 0.89
            ou
            sf = (vht + vhe - vha) - ((vht + vhe - vha) * 0.11)
            ou
            sf = (vht + vhe - vha) - ((vht + vhe - vha) * 11 / 100)
 */
 #include <stdio.h>
 #include <locale.h>
 int main(){
   setlocale(LC_ALL,"Portuguese");
   float qht, qhe, qha, vsm, vht, vhe, vha, sf;
   printf("Informe a quantidade de:\nhoras trabalhadas\nhoras extras\nhoras ausentes\nseparadas por / : ");
   scanf("%f/%f/%f",&qht,&qhe,&qha);
   printf("Informe o valor do sal�rio m�nimo: ");
   scanf("%f",&vsm);
   vht = qht * (vsm * 0.04);
   vha = qha * (vsm * 0.04);
   vhe = qhe * (vsm * 0.06);
   sf  = (vht + vhe - vha) * 0.89;
   printf("\nO sal�rio final ser� de %f",sf);
   return 0;
 }

