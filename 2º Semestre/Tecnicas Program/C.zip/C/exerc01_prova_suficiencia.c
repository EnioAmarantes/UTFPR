#include <stdio.h>
main() {
int d, x, y = 0, z;
scanf("%d", &d);
printf("�ltimo d�gito do meu RA: %d\nResultados:\n", d);
x = 5 + d;
z = d;
y = (x % 2) + 10 * y;
printf("x=%d, y=%d, z=%d\n", x, y, z);
if (d % 2)
z = x++;
else
z = y++;
x /= 2;
y *= 2;
printf("x=%d\ty=%d\tz=%d\n\n", x, y, z);
}
