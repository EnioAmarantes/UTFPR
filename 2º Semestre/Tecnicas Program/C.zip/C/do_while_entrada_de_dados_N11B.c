#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
//programa para mostrar a tabuada de um n�mero
//
//exemplo
//
//DO ... WHILE  - enquanto a condi��o for verdadeira os comandos
//                s�o executados.
//                A estrutura � executada 1 ou n vezes, uma vez
//                que os comandos s�o executados e depois
//                a condi��o primeiro � verificada
//
//  do
//  {
//     <comandos>
//  }while (<condi��o>);

int main(){
  setlocale(LC_ALL,"Portuguese");
  int opcao, controle;
  float a, b;
  controle = 0;
  while (controle == 0) //controla a execu��o completa do programa
  {
    printf("\nInforme dois n�meros reais separados por / \n(utilize , como separador de decimais): ");
    scanf("%f/%f",&a,&b);
//
//DO...WHILE com FLAG - depende da interven��o do usu�rio
//                      para a finaliza��o da repeti��o
//
    do
    {
      system("cls");
      printf("\nEscolha uma das op��es a seguir: ");
      printf("\n1 - M�dia entre os n�meros digitados");
      printf("\n2 - Diferen�a do maior pelo menor");
      printf("\n3 - Produto entre os n�meros digitados");
      printf("\n4 - Divis�o do primeiro pelo segundo\n");
      scanf("%d",&opcao);
    }while ((opcao < 1) || (opcao > 4));

    system("cls");

    switch (opcao){
      case 1:
        printf("\nA m�dia � %f",(a+b)/2);
        break;
      case 2:
        if (a > b)
           printf("\nA diferen�a � %f",a - b);
           else
              if (a < b)
                 printf("\nA diferen�a � %f", b - a);
                 else
                    printf("\nOs n�meros s�o iguais");
        break;
      case 3:
        printf("\nO produto � %f",a * b);
        break;
      case 4:
        if (b == 0)
           printf("\nErro de divis�o por zero");
           else
              printf("\nA divis�o � %f", a / b);
        break;
    }
    printf("\nDigite 0 para continuar ou 1 para encerrar: ");
    scanf("%d",&controle);
  }
  return 0;
}
