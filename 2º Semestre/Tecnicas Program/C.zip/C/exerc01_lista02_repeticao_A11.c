//1.	Fazer um algoritmo que calcule e escreva o valor de S:
//        1      3     5      7            99
//  S = ---- + ---- + ---- + ---- + ... + ----
//        1      2     3      4            50 
//
//Entradas: nenhuma
//Sa�da: valor de S
//Processamento: podemos considerar que S � a soma consecutiva
//               da divis�o dos valor de X por Y, sendo que
//               X come�a em 1, e � incrementado de 2 em 2 at�
//               99, e Y come�a em 1, e � incrementado de 1 em
//               1 at� 50
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float x, y, s;
	s = 0; 	
	x = 1; 
	y = 1;
	while (x <= 99){
		s = s + x / y;
		x = x + 2;
		y = y + 1;
	}
    printf("\nO valor de S � %f",s);
    return 0;
}