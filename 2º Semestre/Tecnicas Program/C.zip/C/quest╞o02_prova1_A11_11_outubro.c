/*
Recentemente, conduziu-se uma experi�ncia para determinar a acelera��o da 
gravidade em Saskatoon. Deixou-se cair uma bola, a partir do repouso, do 
alto de v�rios edif�cios. O tempo gasto para atingir o solo foi registrado 
em cada caso. Foram realizadas 15 medi��es contendo, cada uma:
a altura do pr�dio (em metros) (y)
o tempo gasto para a bola atingir o solo (em segundos) (t)
Preparar um programa para calcular a acelera��o gravitacional g, a partir 
dos dados coletados, utilizando a f�rmula:

y = (1/2)*g*t^2

y representa a dist�ncia percorrida pela bola
t o tempo gasto para atingir o solo. 
O "melhor valor" para g para a localidade de Saskatoon, com base nos 
resultados obtidos, � dado pela m�dia aritm�tica do resultado das medidas. 
O algoritmo deve ler os dados fornecidos e apresentar o "melhor valor".
*/
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int qt;
	float y, g, t, soma;
	qt = 1;
	soma = 0;
	while (qt <= 15){
	  printf("Digite a altura da %d� medida: ",qt);
	  scanf("%f",&y);
	  printf("Digite o tempo da %d� medida: ",qt);
	  scanf("%f",&t);
	  g = 2*y/pow(t,2.0);
	  soma = soma + g;
	  qt = qt + 1;
	}
	printf("O melhor valor � %f",soma/15);
	return 0;
}	
