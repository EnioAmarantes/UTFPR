/*18.	O n�mero 3025 possui a seguinte caracter�stica:
30 + 25 = 55
55^2 = 3025
Fazer um algoritmo para um programa que pesquise e imprima todos os n�meros de quatro algorit�mos
que apresentam tal caracter�stica.
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
main(){
  int n;
  float N, n1, n2;
  char num[4], valor[]="\0\0";
  for(n = 1000; n <= 9999; n++){
    itoa(n,num, 10);
    n1 = atof(strncpy(valor, &num[0], 2));
    n2 = atof(strncpy(valor, &num[2], 2));
    N = pow(n1+n2,2.0);
    if (N == n)
       printf("%d = %.0f\n", n, n1+n2);
  }
}
