#include <stdio.h>
#include <math.h>
exemplo(int *a,int *b, int x, int y){
  *a = x + y;
  *b = x * y;
}

void main (void)
{
  int n1 ,n2, n3, n4;
  n1 = 0;
  n2 = 0;
  n3 = 2;
  n4 = 3;
  
  printf("\nn1 = %d, n2 = %d, n3 = %d, n4 = %d",n1,n2,n3,n4);
  
  exemplo(&n1, &n2, n3, n4);
  
  printf("\nn1 = %d, n2 = %d, n3 = %d, n4 = %d",n1,n2,n3,n4);
 
}
