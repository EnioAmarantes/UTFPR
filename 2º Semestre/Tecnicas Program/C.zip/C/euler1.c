#include <stdio.h>
#include <math.h>

main(){
  float d = 1, s = 0, qt;

  scanf("%f", &qt);

  while (d <= qt){
    s = s + 1 / (d * d);
    d++;
  }

  printf("%f ", pow(s*6.0, 0.5));


}
