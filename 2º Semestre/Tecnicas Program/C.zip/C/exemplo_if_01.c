#include <stdio.h>
main(){
  int n;
  printf("digite um n�mero: ");
  scanf("%d", &n);
  if (n == 0)
    printf("\n\nZERO\n\n");
    else
      if (n % 2 == 0)
        printf("\n\nPAR\n\n");
        else
          printf("\n\nIMPAR\n\n");
}
