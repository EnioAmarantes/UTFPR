#include <stdio.h>
main(){
  int h1, m1, h2, m2, h3, m3, dif;
  printf("Digite hora e minuto inicial (ENTER apos cada valor): ");
  scanf("%d %d", &h1, &m1);
  printf("Digite hora e minuto final (ENTER apos cada valor): ");
  scanf("%d %d", &h2, &m2);
  if ((h1 == 0) && (m1 == 0) && (h2 == 0) && (m2 == 0))
    printf("Dados incorretos!!");
    else{
      dif = (h2 * 60 + m2) - (h1 * 60 + m1);
      if (dif == 0)
        printf("A ligacao teve duracao de 24 horas");
        else
          if (dif > 0){
            h3 = dif / 60;
            m3 = dif % 60;
            printf("A ligacao teve duracao de %dH e %dM", h3, m3);
          }
          else{
            dif = dif + 1440;
            h3 = dif / 60;
            m3 = dif % 60;
            printf("A ligacao teve duracao de %dh e %dmin", h3, m3);
          }
    }
}
