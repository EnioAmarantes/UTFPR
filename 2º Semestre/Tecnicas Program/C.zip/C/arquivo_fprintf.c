#include <stdio.h>
#include <stdlib.h>

main(){
 FILE * pFile = fopen ("myfile.txt","w");
 int n;
 char name [100];
 for (n = 0;n < 3;n++)
 {
    printf("please, enter a name: ");
    gets(name);
    fprintf(pFile,"Name %d [%-10.10s]\n",n,name);
 }
 fclose (pFile);
}
