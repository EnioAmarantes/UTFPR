/*
a)	Preencher um vetor A com 25 n�meros inteiros e positivos, sem repeti��es
    (o algoritmo deve controlar estas restri��es).
b)	Inserir em um vetor B, a partir do seu in�cio, os n�meros pares do vetor A e,
    a partir do seu final, os n�meros �mpares do vetor A
    (este item deve ser resolvido com apenas uma �nica estrutura de repeti��o).
c)	Mostrar o conte�do do vetor B, indicando a posi��o de cada n�mero no vetor B e no vetor A.
d)	Intercalar o conte�do dos vetores A (a partir do in�cio) e B (a partir do final) em um vetor C
    (com tamanho 50) (este item deve ser resolvido com apenas uma �nica estrutura de repeti��o).
e)	Mostrar o vetor C.
*/

#include <stdio.h>

main(){

int A[25], B[25], C[50], n, i, j, x, par, imp;

  srand(time(NULL));
  i = 0;
  while (i < 25){
    x = rand()/100;
    n = 0;
    for(j = 0; j < i; j++)
      if (A[j] == x)
        n = 1;
    if (n == 0) {
      A[i] = x;
      i++;
    }
  }

  for(i = 0, par = 0, imp = 24;i < 25; i++){
    if (A[i] % 2 == 0){
       B[par] = A[i];
       par++;
    }
    else{
       B[imp] = A[i];
       imp--;
    }
  }

  for(i = 0;i < 25;i++){
    printf("\nO numero %4d e o elemento %2d em B ", B[i], i);
    for(j = 0; j < 25; j++)
      if(A[j] == B[i])
        printf("e o elemento %2d em A", j);
  }

  for(i = 0, par = 0, imp = 24;i < 50; i=i+2, par++, imp--){
    C[i] = A[par];
    C[i+1] = B[imp];
  }

  printf("\n\nVetor A\n");
  for(i = 0;i < 25; i++)
    printf("%d - ",A[i]);

  printf("\n\nVetor B\n");
  for(i = 0;i < 25; i++)
    printf("%d - ",B[i]);

  printf("\n\nVetor C\n");
  for(i = 0;i < 50; i++)
    printf("%d - ",C[i]);
}



