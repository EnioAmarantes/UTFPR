#include <stdio.h>
#include <math.h>
#include <locale.h>
main(){
  float y, m, r;
  int c, ap;
  setlocale(LC_ALL, "Portuguese"); 
  printf("Informe um n�mero para calcular sua raiz quadrada: ");
  scanf("%f", &y);
//  printf("Informe o n�mero de aproxima��es desejadas: ");
//  scanf("%d",&ap);
  r = y / 2.0;
  c = 0;
  do{
    r = (r * r + y) / (2 * r);
    c++;
  } while (c < 20);
  //while (r - (pow(y,0.5)) > 0.00000001);
  printf("\nA raiz quadrada de %f calcula pelo programa � %f",y,r);
  printf("\nPela fun��o pow(y,0.5) � %f",pow(y,0.5));
  printf("\nAproxima��es %d",c);
}

