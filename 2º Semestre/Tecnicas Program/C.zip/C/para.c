#include <stdio.h>
#define LIMITE 3
main(){
  float nota, soma, media;
  int n, i;
  srand(time(NULL));
  n = 1;
  media = 0;
  soma = 0;
  while (n <= LIMITE){
    i = 1;
    while (i <= 4){
      do{
         nota = rand()/1000;
      }while (nota > 10);
      printf("\tnota %2d do aluno %2d = %2.2f\n",i,n,nota);
      soma = soma + nota;
      i++;
    }
    printf("A media do %2d aluno e %2.2f\n", n, soma/4);
    media = media + soma/4;
    soma = 0;
    n = n + 1;
  }
  printf("\nA media da turma e %2.2f\n",media/LIMITE);
}
