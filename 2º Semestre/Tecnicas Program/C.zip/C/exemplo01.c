#include <stdio.h>
#include <locale.h>
int main(){
    setlocale(LC_ALL,"Portuguese");
    float a = 10.123456789123456789;
    printf("\n%f \n%2.2f \n%10.2f \n%50.25f",a,a,a,a);
    return 0;
}
