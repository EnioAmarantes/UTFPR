/*
calcular o valor de S para os N primeiros termos da s�rie:
      x!     (x+1)!   (x+2)!   (x+3)!   (x+4)!
S = ------ - ------ * ------ / ------ + ------ - ...
      y!     (y+2)!   (y+4)!   (y+6)!   (y+8)!
*/
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float s, x, y, fatx, faty, aux;
	int sinal, qt, c;
    printf("      x!     (x+1)!   (x+2)!   (x+3)!   (x+4)!\n");
    printf("S = ------ - ------ * ------ / ------ + ------ - ...\n");
    printf("      y!     (y+2)!   (y+4)!   (y+6)!   (y+8)!\n");
	printf("\nInforme a quantidade de termos para a s�rie: ");
	scanf("%d",&qt);
	printf("\nInforme o valor incial de x: ");
	scanf("%f",&x);
	printf("\nInforme o valor incial de y: ");
	scanf("%f",&y);
	c = 1;
	sinal = 0;
	s = 0;
	while (c <= qt){
//calcula o fatorial de x
      fatx = x;
	  aux = x - 1;
	  while (aux > 1){
		  fatx = fatx * aux;
		  aux = aux - 1;
	  }	
//calcula o fatorial de y
  	  faty = y;
	  aux = y - 1;
	  while (aux > 1){
		  faty = faty * aux;
		  aux = aux - 1;
	  }		 
//executa as express�es selecionando o valor da vari�vel sinal
//utilizando SWITCH..CASE	   
	  switch (sinal){
		  case 0:
		  	s = s + (fatx/faty);
			sinal = 1;
			break;		  
		  case 1:
		  	s = s - (fatx/faty);
			sinal = 2;
			break;		  
		  case 2:
		  	s = s * (fatx/faty);
			sinal = 3;
			break;		  
		  case 3:
		  	s = s / (fatx/faty);
			sinal = 0;
			break;		  
	  }
//executa as express�es selecionando o valor da vari�vel sinal
//utilizando IF..ELSE
  /*
      if (sinal == 0){
         s = s + (fatx/faty);
		 sinal = 1;
	  }
	  else
	    if (sinal == 1){
		  	s = s - (fatx/faty);
			sinal = 2;
	    }
		else
		  if (sinal == 2){  
		     s = s * (fatx/faty);
			 sinal = 3;
	      }
		  else{ 		  
		  	s = s / (fatx/faty);
			sinal = 0;
	      }      
*/	    
	  x = x + 1;
	  y = y + 2;
	  c = c + 1;
  	}
	printf("\nS --> %f",s);
	return 0;
}