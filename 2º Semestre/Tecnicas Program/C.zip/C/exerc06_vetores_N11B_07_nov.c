/*
Quest�o 06: Construa um programa em C para:
a)	Preencher um vetor A com 25 n�meros inteiros e positivos, sem repeti��es 
    (o algoritmo deve controlar estas restri��es).
b)	Inserir em um vetor B, a partir do seu in�cio, os n�meros pares do vetor 
    A e, a partir do seu final, os n�meros �mpares do vetor A (este item deve ser 
    resolvido com apenas uma �nica estrutura de repeti��o).
c)	Mostrar o conte�do do vetor B, indicando a posi��o de cada n�mero no vetor 
    B e no vetor A.
d)	Intercalar o conte�do dos vetores A (a partir do in�cio) e B (a partir do 
    final) em um vetor C (com tamanho 50) (este item deve ser resolvido com apenas
    uma �nica estrutura de repeti��o).
e)	Mostrar o vetor C.

Exemplo:

A
0	1	2	3	4	5	6	7	8	9	10		19	20	21	22	23	24
13	15	22	96	37	45	68	54	71	102	51		49	11	7	2	11	14

B
0	1	2	3	4	5	6		19	20	21	22	23	24
22	96	68	54	102	2	14		51	71	45	37	15	13

O n�mero 22 � o elemento 0 em B e o elemento 2 em A
O n�mero 96 � o elemento 1 em B e o elemento 3 em A
...
O n�mero 15 � o elemento 23 em B e o elemento 1 em A
O n�mero 13 � o elemento 24 em B e o elemento 0 em A 

C
0	1	2	3	4	5	6	7	8	9	
13	13	15	15	22	37	96	45	37	71	
*/
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	srand(time(NULL));
	int A[25], B[25], C[50],i, j, n, x;
//preenche o vetor A sem n�meros repetidos	
	i = 0;
    while (i <= 24){
    x = rand()/1000;
    n = 0;
    for(j = 0; j < i; j++)
      if (A[j] == x){
        n = 1;
        j = i + 1;
      }
     if (n == 0) {
      A[i] = x;
      i++;
    }
  }
//insere em B os valores pares e �mpares de A
  i = 0;  //insere os pares em B
  j = 24; //insere os �mpares em B
  x = 0;  //percorre A
  while (x <= 24){
	  if (A[x] % 2 == 0){
		  B[i] = A[x];
		  i = i + 1;
		  x = x + 1;
	  }
	  else{
		  B[j] = A[x];
		  j = j - 1;
		  x = x + 1;
	  }
  }
//Mostrar A, B, os valores de B e suas posi��es em B e em A
  printf("\nVetor A\n");
  for(i = 0;i <= 24;i++)
  	printf("%d ",A[i]);

  printf("\nVetor B\n");
  for(i = 0;i <= 24;i++)
  	printf("%d ",B[i]);
  
  printf("\n");
  for(i = 0;i <= 24;i++){
  	for(j = 0;j <= 24;j++){
       if (B[i] == A[j]){
          printf("\nO n�mero %d � o elemento %d em B e o elemento %d em A",B[i],i,j);
		  break;        
	   }	    
   }
  }
//intercalor A a partir do in�cio e B a partir do final em C
  i = 0;  //percorre A
  j = 24; //percorre B 
  x = 0;  //percorre C
  while (x <= 49){
     C[x] = A[i];
     C[x+1] = B[j];
     x = x + 2;
     i = i + 1;
     j = j - 1;
  }
  printf("\nVetor C\n");
  for(i = 0;i <= 49;i++)
  	printf("%d ",C[i]);	  
  return 0;	  
}
	