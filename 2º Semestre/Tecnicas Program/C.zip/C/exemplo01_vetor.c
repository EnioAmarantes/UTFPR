#include <stdio.h>

main(){
  int n[10], i, j, aux;

  printf("\nvetor antes do preenchimento\n");
  for(i = 0;i < 10; i++)
    printf("%d ", n[i]);

  for(i = 0, j = 150;i < 10; i++, j= j -7)
    n[i] = j;
//    {
//    do {
//      printf("\ndigite o %d valor para o vetor: ", i + 1);
//      scanf("%d", &n[i]);
//    }while ((n[i] <= 0) || (n[i] % 2 != 0));
//  }

  printf("\nvetor original\n");
  for(i = 0;i < 10; i++)
    printf("%d ", n[i]);

  for(i = 0; i < 8; i++){
    for(j = i + 1; j < 9; j++){
  	   if(n[i] > n[j]){
	     aux = n[i];
	     n[i] = n[j];
	     n[j] = aux;
	   }
     }
   }

  printf("\nvetor ordenado\n");
  for(i = 0;i < 10; i++)
    printf("%d ", n[i]);

  aux = n[4];
  for(i = 3; i >= 0; i--)
    n[i+1] = n[i];
  n[0] = aux;

  printf("\nnovo vetor\n");
  for(i = 0;i < 10; i++)
    printf("%d ", n[i]);

  for(i = 0;i < 10; i++)
    if (n[i] > 12)
      n[i] = 0;

  printf("\nnovo vetor com zeros\n");
  for(i = 0;i < 10; i++)
    printf("%d ", n[i]);


}
