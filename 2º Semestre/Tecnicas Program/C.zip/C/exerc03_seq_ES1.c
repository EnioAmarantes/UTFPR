//03 - Calcular e apresentar a quantidade de gal�es de 5 litros
//de combust�vel necess�ria em uma viagem utilizando-se um autom�vel que
//faz 12Km/l.
//O usu�rio fornecer� o tempo gasto e a velocidade m�dia na viagem.
/*
ENTRADAS DE DADOS: tempo, velocidade m�dia
SA�DAS DE DADOS: quantidade de gal�es de 5 litros
PROCESSAMENTO: sabendo-se que o ve�culo faz 12km/l, e de posse da
               velocidade m�dia e do tempo gasto, primeiro devemos
               calcular a dist�ncia percorrida multiplicandoa velocidade
               pelo tempo.
               de posse da dist�ncia percorrida devo dividi-la por 12 para
               saber quantos litros foram gastos e este resultado dividir por
               5 para saber quantos gal�es foram gastos
*/
#include <stdio.h>
int main(){
  float t, vm, d, g;
  printf("Informe o tempo da viagem: ");
  scanf("%f",&t);
  printf("Informe a velocidade m�dia da viagem: ");
  scanf("%f",&vm);
  d = t * vm;
  g = d / 12 / 5;
  printf("\nSerao necessarios %f galoes de 5 litros ", g);
  return 0;





}


