/*
N�meros amig�veis s�o pares de n�meros onde um deles � a soma dos divisores do
outro. Por exemplo,
Os divisores de 220 s�o 1, 2, 4, 5, 10, 11, 20, 22, 44, 55 e 110, cuja soma � 284.
Os divisores de 284 s�o 1, 2, 4, 71 e 142 e a soma deles � 220.
2. Escreva um programa que mostre todos os pares de n�meros amig�veis em um intervalo 
fechado [n1, n2] informado pelo usu�rio.
*/
#include <stdio.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 
  int n1, n2, n1a, soma1, soma2, c, x;
  printf("Encontra pares de n�meros amigos em um intervalo fornecido pelo usu�rio");
  printf("\nInforme o valor de in�cio do intervalo ");
  scanf("%d",&n1);
  printf("\nInforme o valor de final intervalo ");
  scanf("%d",&n2);
  while (n1 <= n2){
	 soma1 = 0;
	 c = 1;
	// printf("\nos divisores de %d s�o ",n1);
	 while (c < n1){
	 	if (n1 % c == 0){
		  // printf("%d ",c);
           soma1 = soma1 + c;
		 }
	    c++;	 
	 }
//	 printf("cuja soma � %d",soma1);
	 n1a = n1 + 1;
	 while(n1a <= n2){
	   soma2 = 0;
	   c = 1;
	  // printf("\n..os divisores de %d s�o ",n1a);
	   while (c < n1a){
  	 	 if (n1a % c == 0){
		  // printf("%d ",c);
           soma2 = soma2 + c;
		 }
	     c++;	 
	   }
	 //  printf("cuja soma � %d",soma2);
	   if ((soma1 == n1a) && (soma2 == n1)){
	   	 printf("\n------------------------------------------");
         printf("\nOs n�meros %d e %d s�o amigos",n1,n1a);
         printf("\nDivisores de %d s�o: ",n1);
	     for(c = 1;c < n1;c++){
			if(n1 % c == 0)
				printf(" %d",c); 
		 }
         printf("\nDivisores de %d s�o: ",n1a);
	     for(c = 1;c < n1a;c++){
			if(n1a % c == 0)
				printf(" %d",c); 
		 }
	   }	     	
	   n1a++; 
	 }
	 n1++; 
  }
}