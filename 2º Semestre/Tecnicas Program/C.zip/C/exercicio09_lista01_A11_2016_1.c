//01 - Obter o nome e a idade de um usu�rio e escrever na tela a seguinte mensagem:
//Hello! FULANO, voc� tem XX anos, para um grupo de 10 pessoas.
//
//09 - Refazer o exerc�cio n� 01, obtendo o sexo do usu�rio (masculino ou feminino),
//e alterar a mensagem para:
//Hello! Sr. Fulano, voc� ainda n�o atingiu a maioridade!
//ou
//Hello! Sra. Ciclana, voc� ainda n�o atingiu a maioridade!
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
main(){
	setlocale(LC_ALL, "Portuguese"); 
	int idade, c;
	int sexo;
	char nome[50];
//	char sexo[10];
/*	c = 1;
	while (c <= 10){
		printf("\nDigite o %d� nome: ",c);
		fflush(stdin);
		scanf("%[^\n]s",&nome);
		printf("Digite sua idade: ");
		scanf("%d",&idade);
		printf("Digite MASCULINO ou FEMININO: ");
		fflush(stdin);
		scanf("%[^\n]s",&sexo);   
		if ((idade < 18) && (strcmp(strupr(sexo),"MASCULINO")==0))
			printf("\nHello! Sr. %s, voc� ainda n�o atingiu a maioridade\n",nome);
		if ((idade < 18) && (strcmp(strupr(sexo),"FEMININO")==0))
			printf("\nHello! Sra. %s, voc� ainda n�o atingiu a maioridade\n",nome);
        c = c + 1;
	}	
*/
	for(c = 1;c <= 10; c++){
		printf("\nDigite o %d� nome: ",c);
		fflush(stdin);
		scanf("%[^\n]s",&nome);
		printf("Digite sua idade: ");
		scanf("%d",&idade);
		printf("Digite 1 para MASCULINO ou 2 para FEMININO: ");
		scanf("%d",&sexo);   
		if ((idade < 18) && (sexo == 1))
			printf("\nHello! Sr. %s, voc� ainda n�o atingiu a maioridade\n",nome);
		if ((idade < 18) && (sexo == 2))
			printf("\nHello! Sra. %s, voc� ainda n�o atingiu a maioridade\n",nome);
	}



}