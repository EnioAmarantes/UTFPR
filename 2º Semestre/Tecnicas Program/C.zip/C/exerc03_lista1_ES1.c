/*
03 - Calcular e apresentar a quantidade de gal�es cheios de 5 litros de 
combust�vel necess�ria em uma viagem utilizando-se um autom�vel que faz 12Km/l. 
O usu�rio fornecer� o tempo gasto e a velocidade m�dia na viagem.
*/
#include <stdio.h> 
#include <locale.h>
int main(){	
	setlocale(LC_ALL,"Portuguese");
	float d, v, t, q;
	printf("Informe o tempo gasto: ");
	scanf("%f",&t);
	printf("Informe a velocidade m�dia: ");
	scanf("%f",&v);
    d = v * t;
	printf("\n1 - A quantidade de gal�es � %d",(int)(d / 12 / 5) + 1);
	printf("\n2 - A quantidade de gal�es � %f",d / 12 / 5);
	
	return 0;
}