#include <stdio.h>

int main(){
  int n;
  
  printf("Digite um n�mero inteiro: ");
  scanf("%d",&n);
// = � o comando de atribui��o
// == � o operador relacional de igualdade  
  if (n % 2 == 0) //se n MOD 2 igual a 0
    printf("\nO n�mero %d � par",n);

  return 0;    
}
