#include <stdio.h>
// Fun��o que retorna verdadeiro se o valor do par�metro formal "n" corresponde
// a um numero primo, falso, caso contr�rio.
int primo(int n) {
    int ehPrimo = 1;
    int i = 2;
    while ((ehPrimo == 1) && (i <= (n / 2))) {
      if ((n % i) == 0)
         ehPrimo = 0;
      else i++;
    }
    return (ehPrimo);
  }
main(){
 int n;
 printf("Numeros primos entre 2 e 100\n");
 printf("----------------------------\n");
 for (n = 2; n <= 100; n++) {
 if (primo(n) == 1)
    printf("%d\n",n );
    }
 }
