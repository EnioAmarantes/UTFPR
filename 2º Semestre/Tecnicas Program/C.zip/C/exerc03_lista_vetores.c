//3. Escreva um programa que leia dois vetores de 10 posi��es e fa�a
//a multiplica��o dos elementos de mesmo �ndice, colocando o resultado
//em um terceiro vetor. Mostre o vetor resultante.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
	int a[10], b[10], c[10], i;
	
	srand(time(NULL));
	
	for(i = 0;i < 10;i = i + 1){
	  a[i] = rand()/1000;
	  b[i] = rand()/1000;
	  c[i] = a[i] * b[i];
	}
    printf("\n");
	for(i = 0;i < 10;i = i + 1) 
		printf("%4d",a[i]);
	
	printf("\n");	
	for(i = 0;i < 10;i = i + 1)
		printf("%4d",b[i]);

	printf("\n");
	for(i = 0;i < 10;i = i + 1)
		printf("%4d",c[i]);
	
	return 0;
}