#include <stdio.h>
#include <math.h>
int main(){
  float a, b, c, delta, x1, x2;
  printf("Digite o valor de a: ");
  scanf("%f",&a);
  if (a == 0)
	 printf("\n1 - Nao e possivel calcular as raizes");
	 else{
	   printf("Digite o valor de b: ");
	   scanf("%f",&b);
      printf("Digite o valor de c: ");
	   scanf("%f",&c);
		delta = pow(b,2.0) - 4 * a  * c;
      if (delta < 0)
		  printf("\n2 - Nao e possivel calcular as raizes - delta = %f",delta);
		  else
			 if (delta == 0){
			   x1 = -b / (2 * a);
		      x2 =  x1;
				printf("\nDelta - 0\nx1 = %f\nx2 = %f",x1,x2);
				}
			     else{
					 x1 = (-b + pow(delta,0.5))/(2 * a);
                x2 = (-b - pow(delta,0.5))/(2 * a);
					 printf("\nx1 = %f\nx2 = %f",x1,x2);
				  }
	 }
  return 0;
}
