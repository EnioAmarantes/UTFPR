//Construa um programa que receba uma frase do usu�rio e dia se a mesma � pal�ndroma (n�o deve ser utilizada a fun��o strrev()).
//Um pal�ndromo � uma palavra, frase ou qualquer outra sequ�ncia de unidades (como uma cadeia de ADN; Enzima de restri��o)
//que tenha a propriedade de poder ser lida tanto da direita para a esquerda como da esquerda para a direita.
//Num pal�ndromo, normalmente s�o desconsiderados os sinais ortogr�ficos (diacr�ticos ou de pontua��o),
//assim como os espa�os entre as palavras.
//Exemplos
//Socorram-me, subi no onibus em Marrocos
//Anotaram a data da maratona
//Assim a aia a missa
//A mala nada na lama
//A torre da derrota
//Saud�vel leva duas
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
int main(){
  char frase[255];
  int i, j, aux, ok;
  setlocale(LC_ALL, "Portuguese");
  printf("Digite uma frase com no m�ximo 250 caracteres: ");
  fflush(stdin);
  gets(frase);
//elimina os espa�os em branco na frase
  j = strlen(frase);
  for(i = 0;i < j;i++){
    if (frase[i] == ' '){
       for(aux = i;aux < j;aux++)
          frase[aux] = frase[aux+1];
       j--;
    }
  }
//
  for(i = strlen(frase) - 1, j = 0, ok = 0;i >= 0; i--, j++){
    if (frase[i] != frase[j]){
      ok = 1;
      i = -1;
    }
  }
//
  if (ok == 0)
    printf("\nA frase � pal�ndroma\n");
    else
      printf("\nA frase n�o � pal�ndroma\n");

  return 0;
  system("pause");
}
