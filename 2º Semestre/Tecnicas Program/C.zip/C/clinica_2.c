#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Rebanho{
	int tipo[2];
};
typedef struct Rebanho rebanho;
struct Propriedade{
	int cod;
	char nome[50];
	char nomep[50];
	float tamanho;
	rebanho qtd;
	float valor;
};
typedef struct Propriedade prop;
void preencher(prop f[], int);
void financiamento(prop f[] , int);
void maiormenor(prop f[], int, int);
int totalcabecas(prop f[], int q, int);
float valortotal (prop f[], int , int);
void relatorio (prop f[], int , int );
void exibir(prop f[], int);
void apagar(prop f[] , int *);
main(){
	int q,
		totalTipo1 = 0,
		totalTipo2 = 0,
		opc,
		n,
		cap,
		i,
		j;
	FILE *fp;
	float 	valorTipo1 = 0,
			valorTipo2 = 0;
	prop *fazendas;
	fp = fopen("fazendas.txt", "r");

	if(fp == NULL){
		n = 0 ;
		cap = 20;
		fazendas = (prop*)malloc(sizeof(prop)*cap);
		fclose(fp);
	}
	else{
		fread(&n , sizeof(int), 1, fp);
		cap = n*2;
		fazendas = (prop*)malloc(sizeof(prop)*cap);
		fread(fazendas, sizeof(prop), n,fp);
		fclose(fp);
	}

	do{

		printf("**MENU**\n");
		printf("1) Cadastrar fazenda\n");
		printf("2) Exibir fazendas\n");
		printf("3) Apagar\n");
		printf("4) Sair\nOpcao: ");
		scanf("%d", &opc);
		if(opc == 1){
			if(n == cap){
				cap*=2;
				fazendas = (prop*)realloc(fazendas,sizeof(prop)*cap);
			}
			preencher(fazendas, n);
			n++;
		}
		else if(opc == 2){
			exibir(fazendas , n);
		}
		else if(opc == 3){
			apagar(fazendas , &n);
		}
	}while(opc!=4);
	if( n > 0){
		fp = fopen("fazendas.txt","w");
		fwrite(&n , sizeof(int), 1, fp);
		fwrite(fazendas , sizeof(prop), n, fp);
		fclose(fp);
	}
	free(fazendas);
	return 0;
}
void preencher(prop f[], int q){
		fflush(stdin);
		printf("Fazenda %d\nDigite o Codigo da propriedade\n", q+1);
		scanf("%d", &f[q].cod);
		printf("Digite o nome da propriedade\n");
		scanf("%s", &f[q].nome);
		printf("Digite o nome do proprietario\n");
		scanf("%s", &f[q].nomep);
		printf("Digite o tamanho da propriedade\n");
		scanf("%f", &f[q].tamanho);
		printf("Digite o tamanho do rebanho de corte\nCorte:");
		scanf("%d", &f[q].qtd.tipo[0]);
		printf("Digite o tamanho do rebanho de leite\nLeite:");
		scanf("%d", &f[q].qtd.tipo[1]);
		system("cls");

}
void financiamento(prop f[] , int a){

	f[a].valor = 0;
	if((f[a].qtd.tipo[0]+f[a].qtd.tipo[1])<= 250)
		f[a].valor = ((float)(f[a].qtd.tipo[0] + f[a].qtd.tipo[1])* 1.75) + ((float)f[a].qtd.tipo[1] * 0.06);

	else if ( (f[a].qtd.tipo[0]+f[a].qtd.tipo[1]) > 250 && (f[a].qtd.tipo[0]+f[a].qtd.tipo[1]) <= 750)
		f[a].valor = ((float)(f[a].qtd.tipo[0] + f[a].qtd.tipo[1])* 1.50) + ((float)f[a].qtd.tipo[1] * 0.06);

	else
		f[a].valor = ((float)(f[a].qtd.tipo[0] + f[a].qtd.tipo[1])* 1.25) + ((float)f[a].qtd.tipo[1] * 0.06);

}
void maiormenor(prop f[], int q, int tipo){
	int a,
		contMaior = 0,
		contMenor = 0;
	float maior = 0,
		  menor = 9999;
	for( a = 0 ; a < q ; a++){
		if(tipo == 1){
			if(f[a].qtd.tipo[0] > maior){
				maior = f[a].qtd.tipo[0];
				contMaior = a;
			}
			if(f[a].qtd.tipo[0] < menor){
				menor = f[a].qtd.tipo[0];
				contMenor = a;
			}
		}
		else{
			if(f[a].qtd.tipo[1] > maior){
				maior = f[a].qtd.tipo[1];
				contMaior = a;
			}
			if(f[a].qtd.tipo[1] < menor){
				menor = f[a].qtd.tipo[1];
				contMenor = a;
			}
		}
	}
	printf("Codigo da fazenda maior: %d\n", f[contMaior].cod);
	printf("Tamanho do rebanho: %d\n", f[contMaior].qtd);
	printf("Valor: %.2f\n\n", f[contMaior].valor);
	printf("Codigo da fazenda  menor: %d\n", f[contMenor].cod);
	printf("Tamanho do rebanho: %d\n", (f[contMenor].qtd.tipo[0]+f[a].qtd.tipo[1]));
	printf("Valor: %.2f\n\n", f[contMenor].valor);
}
int totalcabecas(prop f[], int q, int tipo){
	int a, soma = 0;
	for( a = 0 ; a < q ; a++){
		if(tipo == 1)
			soma += f[a].qtd.tipo[0];
		else
			soma += f[a].qtd.tipo[1];
	}
	return soma;
}
float valortotal (prop f[], int q, int tipo){
	int a;

	float total = 0;
	for ( a = 0 ; a < q ; a++){
		if(tipo == 1)
			if((f[a].qtd.tipo[0]+f[a].qtd.tipo[1])<= 250)
				total+= (float)f[a].qtd.tipo[0]*1.75;
			else if ( (f[a].qtd.tipo[0]+f[a].qtd.tipo[1]) > 250 && (f[a].qtd.tipo[0]+f[a].qtd.tipo[1]) <= 750)
				total+= (float)f[a].qtd.tipo[0]*1.5;
			else
				total+= (float)f[a].qtd.tipo[0]*1.25;
		else if (tipo == 2){
			if((f[a].qtd.tipo[0]+f[a].qtd.tipo[1])<= 250)
				total += (float)f[a].qtd.tipo[1]*1.81;
			else if ( (f[a].qtd.tipo[0]+f[a].qtd.tipo[1]) > 250 && (f[a].qtd.tipo[0]+f[a].qtd.tipo[1]) <= 750)
				total+= (float)f[a].qtd.tipo[1]*1.56;
			else
				total+= (float)f[a].qtd.tipo[1]*1.31;
		}
	}
	return total;
}
void relatorio (prop f[], int q, int tipo){
	int i = 0,
		j = 0,
		aux = 0,
		a = 0,
		b = 0,
		v[q],
		conta = 0;

	for(a = 0; a < q; a++){
		if(tipo == 1){
			v[b] = a;
			b++;
			conta++;
		}
		else{
			v[b] = a;
			b++;
			conta++;
		}
	}
	if(tipo == 1){
		for(i = 0 ; i < conta ; i++){
	        for(j = i + 1 ; j < conta ; j++){
	            if(f[v[i]].qtd.tipo[0] > f[v[j]].qtd.tipo[0]){
	        	    aux  = v[i];
	                v[i] = v[j];
	                v[j] = aux;
	            }
				if(f[v[i]].qtd.tipo[0] == f[v[j]].qtd.tipo[0]){}
	        }
	    }
	}
	else{
		for(i = 0 ; i < conta ; i++){
	        for(j = i + 1 ; j < conta ; j++){
	            if(f[v[i]].qtd.tipo[1] > f[v[j]].qtd.tipo[1]){
	        	    aux  = v[i];
	                v[i] = v[j];
	                v[j] = aux;
	            }
				if(f[v[i]].qtd.tipo[1] == f[v[j]].qtd.tipo[1]){}
	        }
	    }
	}
    for(a = 0 ; a < conta ; a++)
    	printf("TamanhoPropri: %.f \nTamanhoReba Corte: %d \nTamanhoReba Leite: %d \nNomePropri: %s \nValor: %.2f\n", f[v[a]].tamanho , f[v[a]].qtd.tipo[0], f[v[a]].qtd.tipo[1]  , f[v[a]].nomep , f[v[a]].valor);
}
void apagar(prop f[], int *n){
	int codigo;
	int j,i;
	printf("Digite o codigo da fazenda que deseja apagar\nCOD:");
	scanf("%d", &codigo);
	for(i = 0; i <= *n; i++){
		if(f[i].cod == codigo ){
			for(j = i+1; j <= *n ; j++){
				f[j-1].cod = f[j].cod;
				strcpy(f[j-1].nome , f[j].nome);
				strcpy(f[j-1].nomep , f[j].nomep);
				f[j-1].tamanho = f[j].tamanho;
				f[j-1].qtd.tipo[0] = f[j].qtd.tipo[0];
				f[j-1].qtd.tipo[1] = f[j].qtd.tipo[1];
				f[j-1].valor = f[j].valor;
			}
			*n = *n -1;
			i = *n;
		}
	}
}
void exibir(prop f[], int q){
	int aux;
	for(aux = 0; aux < q ; aux++){
		printf("***FAZENDA %d ***\n", aux+1);
		printf("CODIGO: %d\n", f[aux].cod);
		printf("NOME DA FAZENDA: %s\n", f[aux].nome);
		printf("NOME DO PROPRIETARIO: %s\n", f[aux].nomep);
		printf("TAMANHO DA FAZENDA: %6.2f\n",f[aux].tamanho);
		printf("QUANTIDADE DE GADO: %d\n", f[aux].qtd);
		printf("TIPO DE GADO (1 - CORTE / 2 - LEITE): %d  // %d\n", f[aux].qtd.tipo[0], f[aux].qtd.tipo[1]);
		financiamento(f, aux);
		printf("VALOR FINANCIAMENTO GADO: %6.2f\n", f[aux].valor);

	}
}
