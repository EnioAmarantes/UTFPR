/*
Dizemos que um n�mero natural � triangular se ele � produto de tr�s
n�meros naturais consecutivos.
Exemplo: 120 � triangular, pois 4 * 5 * 6 = 120.
Escrever um programa em C que mostre todos os n�meros triangulares
entre n1 e n2.
*/
#include <stdio.h>
#include <locale.h>
int main(){
   setlocale(LC_ALL,"Portuguese");
   int n1, n2, i, x;
   printf("Digite valor do in�cio do intervalo: ");
   scanf("%d",&n1);
   printf("Digite valor do final do intervalo: ");
   scanf("%d",&n2);
   while(n1 <= n2){
     for(x = 1;x *(x+1)*(x+2) <= n1;x = x + 1)
       if (x *(x + 1) *(x + 2) == n1)
         printf("%6d � = %2d * %2d * %2d\n", n1, x, x + 1, x + 2);
     n1 = n1 + 1;
   }
   return 0;
}
