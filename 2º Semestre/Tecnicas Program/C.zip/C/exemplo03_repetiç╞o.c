/*Construa um algoritmo que, dado um conjunto de valores inteiros
e positivos, determine qual o menor valor do conjunto.
O final do conjunto de valores � conhecido atrav�s do valor zero,
que n�o deve ser considerado.*/
#include <stdio.h>
main(){
  int n, menor, maior;
  do{
    printf("digite um valor maior do que zero: ");
    scanf("%d", &n);
  } while (n <= 0);
  menor = n;
  maior = n;
  while (n != 0){
    printf("digite um valor maior do que zero. Zero finaliza o programa: ");
    scanf("%d", &n);
    if ((n > 0) && (n < menor))
      menor = n;
    if ((n > 0) && (n > maior))
      maior = n;

  }
  printf("\no menor valor da serie eh %d", menor)  ;
  printf("\no maior valor da serie eh %d", maior)  ;
}
