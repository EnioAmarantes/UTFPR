/*13. Escreva um programa que leia um vetor G de 20 elementos do tipo caracter 
que representa o gabarito de uma prova. A seguir, para cada um dos 50 alunos da
 turma, leia o vetor de respostas (R) do aluno e conte o n�mero de acertos. 
 Mostre o n� de acertos do aluno e uma mensagem APROVADO, se a nota for maior 
 ou igual a 6; e mostre uma mensagem de REPROVADO, caso contr�rio.*/
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T 10
#define Q 20
#define CORTE 0.6
main(){	
  char gabarito[Q], prova[Q];
  int i, j, nota;
  setlocale(LC_ALL, "Portuguese");
  srand(time(NULL));	
  for(i = 0;i < Q;i++){
	  do{
		  gabarito[i] = rand()/100;
	  }while ((gabarito[i] < 97) || (gabarito[i] > 101));
  }
  printf("\nGabarito: (nota para aprova��o: %d)\n",(int)(Q*CORTE));
  for(i = 0;i < Q;i++){
     printf("%c ",gabarito[i]);
  }
  for(j = 1;j <= T;j++){
    for(i = 0;i < Q;i++){
	  do{
		  prova[i] = rand()/100;
	  }while ((prova[i] < 97) || (prova[i] > 101));
    }
    printf("\nProva do aluno %d:\n",j);
    for(i = 0;i < Q;i++){
      printf("%c ",prova[i]);
    }   
	for(i = 0, nota = 0;i < Q;i++){
		if (gabarito[i] == prova[i])
			nota++;
	}
	if (nota >= (int)(Q * CORTE))
	  printf(" - APROVADO com nota %d",nota);
	  else
		printf(" - REPROVADO com nota %d",nota);
  }
}