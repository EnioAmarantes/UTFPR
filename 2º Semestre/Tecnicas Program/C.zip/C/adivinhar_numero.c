#include <stdio.h>
#include <time.h>
main(){
  int n, r, x, c;
  r = 0;
  c = 0;
  srand(time(NULL));
  x = rand()/100;
  while (r == 0){
    printf("\nDigite um numero: ");
    scanf("%d",&n);
    c++;
    if (n == x){
      printf("\nAcertou!");
      r = 1;
    }
      else
        if (n < x)
          printf("\nDigite um numero maior!");
          else
            printf("\nDigite um numero menor!");
  }
  printf("\nVoce precisou de %d tentativas para advinhar o numero", c);
}
