/*
18.	O n�mero 3025 possui a seguinte caracter�stica:
30 + 25 = 55
55^2 = 3025
Fazer um programa para imprimir todos os n�meros de quatro d�gitos que apresentam tal caracter�stica.

Alterar o programa para que ele mostre quais s�o os n�meros no intervalo entre 1000 e 9999,
que s�o compostos pela soma de dois n�meros primos. Por exemplo:

11 + 03 = 1103 --> 11 e 03 s�o n�meros primos

ALTERA A SOLU��O 01 PARA QUE O PROGRAMA TRABALHE COM N�MEROS DE SEIS D�GITOS
*/
#include <stdio.h>
#include <math.h>
main(){
  int n, n1, n2, p, linhas = 0;
  float N, N1, N2;
  for(n = 100000; n <= 999999; n++){
    n1 = n / 1000;
    n2 = n % 1000;
    N1 = n1;
    N2 = n2;
    N = pow(N1+N2,2.0);
    if (linhas == 50
        ){
        printf("\n");
        system("pause");
        linhas = 0;
    }
    if (N == n){
       printf("\n------------------------------------------------");
       printf("%\n%03d + %03d = %03d --> %03d^2 = %0.f", n1, n2, n1+n2,n1+n2, N);
       printf("\n------------------------------------------------");
       linhas++;
    }
    /*
    for(p = n1 - 1;p > 1; p--)
      if (n1 % p == 0)
        p = 0;
    if (p != -1)
      for(p = n2 - 1;p > 1; p--)
        if (n2 % p == 0)
           p = 0;
    if ((p != -1) && (n1 != 1) && (n2 != 1)){
      printf("\n\t%03d + %03d = %03d --> %03d e %03d sao primos", n1, n2, n, n1, n2);
      linhas++;
    }*/
  }
}
