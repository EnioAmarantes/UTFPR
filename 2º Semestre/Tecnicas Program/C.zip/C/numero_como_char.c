#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main(){
  char num = 111;

  printf("\n%d",num);
  printf("\n%c",num);

}

