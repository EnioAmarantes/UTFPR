#include <stdio.h>
int digitos(int,int);
main(){
  int  x, y, d, p;
  printf("Digite o primeiro n�mero: ");
  scanf("%d",&x);
  printf("Digite o segundo n�mero: ");
  scanf("%d",&y);
  p = 0;
  for(d = 1; d <= 9; d++)
    if ((digitos(x, d)) != (digitos(y,d)))
      p = 1;
  if (p == 0)
    printf("%d eh permutacao de %d", x, y);
    else
      printf("%d nao eh permutacao de %d", x, y);
}
int digitos(int n, int d){
  int soma = 0, r = 0;
  while (n != 0) {
    r = n % 10;
    n = n / 10;
    if (r == d)
       soma++;
  }
  return soma;
}
