#include <stdio.h>
main(){
  int op;
  float valor, cotacao;
  printf("Informe o valor que sera convertido: ");
  scanf("%f",&valor);
  printf("\nInforme: \n1 - para valores em Reais \n2 - para valores em dolares \n");
  scanf("%d",&op);
  if (op == 1){
    printf("\ninforme a cotacao do dolar para conversao do valor de Reais para Dolares: ");
    scanf("%f",&cotacao);
    printf("\n%f Reais --> %.2f Dolares", valor, valor/cotacao);
  }
    else
      if (op == 2){
        printf("\ninforme a cotacao do dolar para conversao do valor de Dolares para Reais: ");
        scanf("%f",&cotacao);
        printf("\n%f Dolares --> %.2f Reais", valor, valor*cotacao);
      }
      else
        printf("\nopcao invalida");
}
