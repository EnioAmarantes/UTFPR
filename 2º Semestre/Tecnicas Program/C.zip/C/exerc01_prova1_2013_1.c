/*
Considere a seguinte situa��o:
Em uma determinada disciplina um aluno estar� aprovado se obtiver nota final maior ou igual a sete
e tendo seu total de faltas menor ou igual a vinte e cinco por cento das aulas ministradas durante o semestre.

Este mesmo aluno estar� reprovado caso sua m�dia seja inferior a quatro
ou se o total de suas faltas for maior do que vinte e cinco por cento das aulas ministradas durante o semestre.

H� ainda a possibilidade do aluno realizar recupera��o, caso tenha nota final maior ou igual a quatro e menor do que 7
e se o total de faltas for menor ou igual a vinte e cinco por cento das aulas ministradas durante o semestre.

Caso o aluno tenha que realizar a recupera��o o mesmo estar� aprovado se a m�dia entre a sua nota final
e a nota da recupera��o for maior ou igual a cinco, e reprovado caso contr�rio.

Escreva um programa em C que receba as notas de duas provas realizadas durante o semestre,
o total de faltas do aluno e a quantidade de aulas dadas de uma disciplina.

Caso seja necess�rio o programa tamb�m dever� obter a nota da recupera��o.
O programa deve informar:
1) se o aluno est� aprovado, ou
2) se o aluno est� reprovado, ou
3) se o aluno dever� realizar recupera��o e, neste caso
4) se est� aprovado ou
5) reprovado.
*/
#include <stdio.h>
main(){
  float n1, n2, media, rec, mr;
  int f, ta;
  printf("Informe a nota da primeira prova: ");
  scanf("%f", &n1);
  printf("Informe a nota da segunda prova: ");
  scanf("%f", &n2);
  printf("Informe o total de faltas: ");
  scanf("%d", &f);
  printf("Informe o total de aulas ministradas: ");
  scanf("%d", &ta);
  if ((((n1+n2)/2) < 4) || (f > ta * 0.25))
    printf("\nReprovado");
    else
    if (((n1+n2)/2) < 7){
      printf("\nRecuperacao");
      printf("Informe a nota da recuperacao: ");
      scanf("%f", &rec);
      if ((((n1+n2)/2) + rec)/2 >= 5)
          printf("\nAprovado");
          else
             printf("\nReprovado");
    }
    else
        printf("\nAprovado");
}
