#include <stdio.h>
main(){
  float F = 50;
  while(F <= 150){
    printf("Fahrenheit -> %3.2f   |  Celsius -> %3.2f\n",F, 5.0/9.0*(F-32));
    F++;
  }
}
