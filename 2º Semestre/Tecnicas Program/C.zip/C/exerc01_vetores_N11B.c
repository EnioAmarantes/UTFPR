//1. Elaborar um programa que l� um conjunto de 30 valores e
//os coloca em 2 vetores conforme estes valores forem pares
//ou �mpares. O tamanho do vetor � de 5 posi��es.
//Se algum vetor estiver cheio, escrev�-lo. Terminada a leitura
//escrever o conte�do dos dois vetores.
//Cada vetor pode ser preenchido tantas vezes quantas for necess�rio.
#include <stdio.h>
int main(){
  int par[5], impar[5], ipar, iimpar, n, i, x;
  n = 1;
  ipar = 0;
  iimpar = 0;
  while (n <= 30){
    printf("Digite o %d valor de um total de 30 n�meros: ",n);
    scanf("%d",&x);
//para n�meros pares
    if ((x % 2 == 0) && (ipar < 5)){
      par[ipar] = x;
      ipar = ipar + 1;
      if (ipar == 5){
        for(i = 0;i < 5;i = i + 1)
          printf("%d ",par[i]);
        printf("\n");
        ipar = 0;
      }
    }
//para n�meros impares
    if ((x % 2 != 0) && (iimpar < 5)){
      impar[iimpar] = x;
      iimpar = iimpar + 1;
      if (iimpar == 5){
        for(i = 0;i < 5;i = i + 1)
          printf("%d ",impar[i]);
        printf("\n");
        iimpar = 0;
      }
    }
    n = n + 1;
  }
//escreve o conte�do do vetor par
  printf("\n");
  for(i = 0;i < ipar;i = i + 1)
    printf("%d ",par[i]);
//escreve o conte�do do vetor impar
  printf("\n");
  for(i = 0;i < iimpar;i = i + 1)
    printf("%d ",impar[i]);
}
