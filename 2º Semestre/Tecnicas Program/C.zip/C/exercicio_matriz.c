/*
1� Quest�o (3,5): Fa�a um algoritmo que utilize uma matriz 5x5 que aceite somente 
tr�s tipos de valores: m�ltiplos de 5, m�ltiplos de 11 e m�ltiplos de 13. 
Devem ser lidos apenas valores maiores que 0(zero). 
Os n�meros devem ser distribu�dos da seguinte forma:
1 - Os m�ltiplos de 5 devem ocupar a diagonal principal;
2 - Os m�ltiplos de 11 devem ficar acima da diagonal principal;
3 - Os m�ltiplos de 13 devem ficar abaixo da diagonal principal.
Como alguns n�meros podem ser m�ltiplos de 5, de 11 e tamb�m de 13 (por exemplo,
55 � m�ltiplo de 5 e de 11; 65 � m�ltiplo de 5 e de 13), deve-se, primeiro,
verificar se o n�mero digitado � m�ltiplo de 5. Caso n�o seja, deve-se verificar
se � m�ltiplo de 11. Caso n�o seja, deve-se verificar se � m�ltiplo de 13. 
Caso n�o seja, mostrar a mensagem N�mero inv�lido (por exemplo, o n�mero 
55 dever� ser considerado m�ltiplo de 5, pois essa ;e a compara��o que 
ser� feita primeiro).
A seguir pode ser observado um exemplo:

 5	 44	 11	 33	143
26	 15	 77	 99	 88
39	 13	 10	121	 22
52	 78	 65	 40	132
91	117	104	182	 25

Esse algoritmo deve observar as seguintes situa��es:
1 - Quando o usu�rio digitar um m�ltiplo de 5 e n�o houver mais espa�o na 
diagonal principal, mostre a mensagem Diagonal principal preenchida;
2 - Quando o usu�rio digitar um m�ltiplo de 11 e n�o houver mais espa�o na 
diagonal principal, mostre a mensagem N�o existe mais espa�o acima da diagonal principal;
3 - Quando o usu�rio digitar um m�ltiplo de 5 e n�o houver mais espa�o na 
diagonal principal, mostre a mensagem N�o existe mais espa�o abaixo da diagonal principal;
4 - Quando a matriz estiver totalmente preenchida, mostre todos os elementos 
da matriz, juntamente com suas posi��es (linha e coluna).
*/
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define D 5
int procura(int [D][D], int);
void recebe(int [D][D],int);
void exibir(int [D][D]); 
void preenche(int [D][D]);
int main(){	
  int matriz[D][D];
  setlocale(LC_ALL, "Portuguese");
  preenche(matriz);
  recebe(matriz,1);
  printf("\n\nMatriz: \n");
  exibir(matriz);
  return 0;
}
void recebe(int m[D][D], int valor){
 int aux, x, quantidade, q1, l1, c1, q2, l2, c2, r;
 srand(time(NULL));
 quantidade = 0;
 x = 0;
 q1 = 0;
 l1 = 0;
 c1 = l1 + 1;
 q2 = 0;
 l2 = 1;
 c2 = 0;
 while(quantidade < D*D){
  
   do{
     aux = rand() /     quantidade++;valor + 1;
   }while ((aux % 5 != 0) || (aux % 11 != 0) || (aux % 13 != 0));   
   r = procura(m,aux);
   if (!r){
     //printf("%d - %d - %d\n",quantidade,aux,r);  
     //system("pause");
     if (x == D)
   	   printf("\nDiagonal Principal preenchida\n");
       else if (aux % 5 == 0){
     	  m[x][x] = aux;
          x++;
          quantidade++;
       }
     if (q1 == ((D * D - D) / 2))
     	 printf("\nAcima da Diagonal Principal preenchida\n");
       else if (aux % 11 == 0){
          m[l1][c1] = aux;
     	  c1++;
     	  q1++; 
          quantidade++;   	
     	  if (c1 == D){
		    l1++;
		    c1 = l1 + 1;
		  }
	   }
     if (q2 == ((D * D - D) / 2))
   	   printf("\nAbaixo da Diagonal Principal preenchida\n");
       else if (aux % 13 == 0){
       	  m[l2][c2] = aux;
     	  c2++;
          q2++;
          quantidade++;
 	      if (c2 == l2){
		    l2++;
		    c2 = 0;
		  }
	   } 
   }
 }
}
void exibir(int m[D][D]){
  int linha, coluna;
  for(linha = 0 ; linha < D ; linha++){
    for(coluna = 0 ; coluna < D ; coluna++)
      printf("%6d ", m[linha][coluna]);
    printf("\n");
  }
}

int procura(int m[D][D], int valor){
 int r, i2, j2;
 r = 0;
 for(i2 = 0; i2 < D; i2++)
   for(j2 = 0; j2 < D; j2++)
      if (m[i2][j2] == valor)
         r = 1;
 return r; 
}

void preenche(int mat[D][D]){ 
  int l, c;
  for(l = 0;l < D;l++)
  	for(c = 0;c < D;c++)
  		mat[l][c] = 0;	
}
