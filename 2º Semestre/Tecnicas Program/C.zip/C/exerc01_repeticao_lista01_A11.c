#include <stdio.h>
#include <stdlib.h>
int main(){
   char nome[50];
   int idade, q;
   q = 1;
   while (q <= 3)
      {
         printf("\nInforme seu nome: ");
         fflush(stdin);
         gets(nome);
         printf("\nInforme sua idade: ");
         scanf("%d",&idade);
         printf("\n%s sua idade e %d",nome, idade);
         q = q + 1;
      }
  return 0;
}
