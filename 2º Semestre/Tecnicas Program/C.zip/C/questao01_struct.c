#include <stdio.h>

struct x {
  char nome[50];
  char depto;
  float salario;
}typedef funcionario;

int main(){
  char c;
  int n;
  float x;
  double y;

  printf("\ntipo de dados funcionario --> %d",sizeof(funcionario));
  printf("\ntipo de dados char ---------> %d",sizeof(c));
  printf("\ntipo de dados int ----------> %d",sizeof(n));
  printf("\ntipo de dados float --------> %d",sizeof(x));
  printf("\ntipo de dados double -------> %d",sizeof(y));

  return 0;
}
