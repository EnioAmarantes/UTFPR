/*
13. Escreva um programa que leia um vetor G de 20 elementos do
tipo caracter que representa o gabarito de uma prova. A seguir,
para cada um dos 50 alunos da turma, leia o vetor de respostas
(R) do aluno e conte o n�mero de acertos. Mostre o n� de acertos
do aluno e uma mensagem APROVADO, se a nota for maior ou igual a 6;
 e mostre uma mensagem de REPROVADO, caso contr�rio.
*/
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
#include <windows.h>
#define TAM 20
int main(){
  setlocale(LC_ALL,"Portuguese");
  char G[20]; //gabarito com respostas para 20 quest�es (a,b,c,d,e)
  char R[20]; //respostas para a prova (a,b,c,d,e)
  float nota; //cada quest�o vale 0.5
  int i, x, q;
  srand(time(NULL));
//gera o gabarito randomicamente
  for(i = 0;i < 20;i = i + 1){
    do{
      x = rand()/100;
    }while ((x < 97) || (x > 101));
    switch (x){
      case 97:
        G[i] = 'a';
        break;
      case 98:
        G[i] = 'b';
        break;
      case 99:
        G[i] = 'c';
        break;
      case 100:
        G[i] = 'd';
        break;
      case 101:
        G[i] = 'e';
        break;
    }
  }
//imprime o gabarito
  printf("\nGABARITO\n");
  for(i = 0;i < 20;i = i + 1)
    printf("%c ",G[i]);
  printf("\n");
//gera as respostas para cada um de 50 alunos randomicamente
  q = 1;
  while (q <= 50){
    for(i = 0;i < 20;i = i + 1){
      do{
        x = rand()/100;
      }while ((x < 97) || (x > 101));
      switch (x){
        case 97:
          R[i] = 'a';
          break;
        case 98:
          R[i] = 'b';
          break;
        case 99:
          R[i] = 'c';
          break;
        case 100:
          R[i] = 'd';
          break;
        case 101:
          R[i] = 'e';
          break;
      }
    }
    //imprime as respostas do aluno atual
    printf("\nRespostas do aluno %d\n",q);
    for(i = 0;i < 20;i = i + 1)
      printf("%c ",R[i]);
    //conta os acertos do aluno atual
    for(i = 0,nota = 0;i < 20;i = i + 1){
      if (G[i] == R[i])
         nota = nota + 0.5;
    }
    if (nota >= 6)
      printf("\n\tAPROVADO - nota %2.1f\n",nota);
      else
        printf("\n\tREPROVADO - nota %2.1f\n",nota);
    q = q + 1;
    Sleep(500);
  }
  return 0;
}
