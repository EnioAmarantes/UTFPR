/*
HEXADECIMAL PARA DECIMAL:
-------------------------
Adivinha! Mesma coisa que a anterior, s� que agora utilizando 16, mas lembre-se:
� necess�rio substituir as letras A, B, C, D, E e F por 10, 11, 12, 13, 14 e 15. 
Vamos converter o n�mero B12 para a base decimal seguindo os mesmos passos 
da convers�o anterior.

Primeiro invertermos o n�mero para fazermos a somat�ria da direita para a 
esquerda do n�mero original.
B12 -> 21B
Agora vamos somar cada n�mero, multiplicando por 16 elevado a um n�mero 
sequencial iniciado em 0.
2*16^0 + 1*16^1 + B*16^2
Substituimos B por 11, ficamos com �
2*16^0 + 1*16^1 + 11*16^2
2 * 1 + 1 * 16 + 11 * 256
2 + 16 + 2816
Resultado: 2834
*/	
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
int main(){
  int i, j, R, num;
  char valor[1], hex[100];
  
  printf("Digite um valor hexadecimal: ");
  fflush(stdin);
  gets(hex);    
  R = 0;
  for(j = strlen(hex) - 1, i = 0;i < strlen(hex);i++,j--){
     switch(hex[i]){
		 case 'A': case 'a':
	       R = R + 10 * pow(16,j);		 	 
		   break;
		 case 'B': case 'b':
	       R = R + 11 * pow(16,j);		 	
		   break;
		 case 'C': case 'c':
	       R = R + 12 * pow(16,j);		 	
		   break;
		 case 'D': case 'd':
	       R = R + 13 * pow(16,j);		 	
		   break;
		 case 'E': case 'e':
	       R = R + 14 * pow(16,j);		 	
		   break;
		 case 'F': case 'f':
	       R = R + 15 * pow(16,j);		 	
		   break;
	     default:
           valor[0] = hex[i];
           num = atoi(valor);
  	       R = R + num * pow(16,j);
		   break;	   
	 }
  }
  printf("\nValor hexadecimal %s \nValor decimal %d",hex,R);
  return 0;
}