//3. Apresentar os n�meros inteiros entre 20 e 35.
#include <stdio.h>
int main(){
  int n;

//------WHILE------
  n = 20;
  while (n <= 35)
  {
    printf("%d ",n);
    n = n + 1;
  }

  printf("\n\n");
//------FOR------
  for(n = 20;n <= 35;n = n + 1)
  {
    printf("%d ",n);
  }

  printf("\n\n");
//------DO...WHILE------
  n = 20;
  do
  {
    printf("%d ",n);
    n = n + 1;
  }while (n <= 35);

  return 0;
}
