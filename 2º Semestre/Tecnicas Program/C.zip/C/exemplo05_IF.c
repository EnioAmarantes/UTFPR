//09 - Refazer o exerc�cio n� 01, obtendo o sexo do usu�rio (masculino ou 
//feminino), e alterar a mensagem para:
//Hello! Sr. Fulano, voc� ainda n�o atingiu a maioridade!
//ou
//Hello! Sra. Ciclana, voc� ainda n�o atingiu a maioridade!
//entradas de dados: nome, idade, sexo
//sa�da de dados: Hello! Sr. Fulano, voc� ainda n�o atingiu a maioridade!
//                ou
//                Hello! Sra. Ciclana, voc� ainda n�o atingiu a maioridade!
//processamento: sexo = masculino e idade < 18
//               sexo = feminino e idade < 18
#include <locale.h> 
#include <stdio.h> 
#include <stdlib.h>//para permitir o uso de fflush(stdin)
int main(){ 
  setlocale(LC_ALL,"Portuguese");
  //nome[50] � uma string, uma composi��o de mais de um caracter (char)
  char nome[50];//[50] determina a quantidade de caracteres da vari�vel
  int idade, sexo;
  
  printf("Digite o nome da pessoa: ");
  fflush(stdin);//limpa o buffer de teclado para permitir a leitura de uma string 
  gets(nome);//executa a entrada de dados de uma string - char nome[50]
  printf("Digite 1 para masculino ou 2 para feminino: ");
  fflush(stdin);
  scanf("%d",&sexo);
  printf("Digite a idade: ");
  scanf("%d",&idade);
//&& - e l�gico  
  if ((idade < 18) && (sexo == 1))
  	printf("Hello! Sr. %s, voc� ainda n�o atingiu a maioridade!",nome);
  if ((idade < 18) && (sexo == 2))
  	printf("Hello! Sra. %s, voc� ainda n�o atingiu a maioridade!",nome);
  
  return 0;
}