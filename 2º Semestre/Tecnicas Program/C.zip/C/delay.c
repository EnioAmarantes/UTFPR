//https://stackoverflow.com/questions/27447195/how-to-use-delay-function-in-c-using-codeblocks-13-12mingw
//17 de outubro de 2017
#include<stdio.h>
#include<time.h>
void delay(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}
int main()
{
    int i;
    for(i=0;i<10;i++)
    {
      delay(100);
      printf("This is delay function\n");
    }
    return 0;
}
