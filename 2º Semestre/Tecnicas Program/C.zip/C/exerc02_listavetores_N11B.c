/*
2. Fa�a um programa que leia um vetor N[20]. A seguir, encontre o menor elemento do vetor N e a sua
posi��o dentro do vetor, mostrando: �O menor elemento de N �, M, �e sua posi��o dentro do vetor
�:�,P.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  srand(time(NULL));

  int v[20], menor, pos, i;
//preenche o vetor com n�meros rand�micos
  for(i = 0;i < 20;i = i + 1)
    v[i] = rand()/1000;
//mostra o vetor na tela
  printf("\n");
  for(i = 0;i < 20;i = i + 1)
    printf("%3d",v[i]);
//encontra o menor valor e sua posi��o no vetor
  printf("\n");
  menor = v[0];
  for(i = 1;i < 20;i = i + 1){
    if (v[i] < menor){
      menor = v[i];
      pos = i;
    }
  }
  printf("\nO menor elemento no vetor � %d \ne sua posi��o dentro do vetor � %d\n",menor,pos);
  system("pause");
  return 0;
}
