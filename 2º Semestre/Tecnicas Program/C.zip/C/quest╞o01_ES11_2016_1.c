/*
Um n�mero natural � chamado de ascendente se cada um dos seus algarismos �
estritamente maior do que qualquer um dos algarismos colocados � sua esquerda. 
Por exemplo, o n�mero 3589.
Escreva um programa que mostre todos os n�meros ascendentes em um intervalo
fechado [n1, n2] informado pelo usu�rio
*/
#include <stdio.h>
#include <locale.h>
main(){
  long int na1, na2, n1, n2, p1, p2, ok;
  setlocale(LC_ALL, "Portuguese"); 
  printf("Informe o primeiro valor do intervalo: ");
  scanf("%ld",&n1);
  printf("Informe o segundo valor do intervalo: ");
  scanf("%ld",&n2);
  while(n1 <= n2){
	na1 = n1;
	ok = 0;
	while (na1 > 0){
	  p1 = na1 % 10;
	  na1 = na1 / 10;
	  na2 = na1;
	  while (na2 > 0){
	    p2 = na2 % 10;
	    na2 = na2 / 10;
	    if (p1 <= p2)
	      ok = 1;
	  }
	}  
    if (ok == 0)
	  printf("\nO n�mero %ld � ascendente",n1);
	n1 = n1 + 1;
  }
}