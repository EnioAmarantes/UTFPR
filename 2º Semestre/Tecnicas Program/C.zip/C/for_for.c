#include <stdio.h>
main(){
  int a, b;
  for(a = 1;a <= 6;a++)
    for(b = 1;b <= 6;b++)
      printf("\n%d %d", a, b);
}
