//2.	Fazer um algoritmo que calcule e escreva a seguinte soma:
//          2      2      2     2            2
//  S = - ---- + ---- + ---- + ---- + ... + ----
//         50     49     48     47           1 
//
//Entradas: nenhuma
//Sa�da: valor de S
//Processamento: podemos considerar que S � a soma consecutiva
//               da divis�o de 2, por Y, sendo que Y come�a em 50
//               e � decrementado de 1 em 1 at� 1.
//               O primeiro termo da soma � negativo.
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float y, s;
	s = -(2.0/50.0);
	y = 49;
	while (y >= 1){
		s = s + 2.0 / y;
		y = y - 1;
	}
    printf("\nO valor de S � %f",s);
    return 0;
}