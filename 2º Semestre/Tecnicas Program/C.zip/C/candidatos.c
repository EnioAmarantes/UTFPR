/*
5.Em uma elei��o presidencial, existem quatro candidatos.
  Os votos s�o informados atrav�s de c�digo.
  Os dados utilizados para a escrutinagem obedecem � seguinte
  codifica��o:
-1,2,3,4 = voto para os respectivos candidatos;
-5 = voto nulo;
-6 = voto em branco;
Elabore um algoritmo que calcule e escreva:
-total de votos para cada candidato;
-total de votos nulos;
-total de votos em branco;
-percentual dos votos em branco e nulos sobre o total;
-situa��o do candidato vencedor sobre os outros dois, no caso,
 se ele obteve ou n�o mais votos que os outros dois somados;
-Como finalizador do conjunto de votos, tem-se o valor 0.
*/
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  float tv1 = 0, tv2 = 0, tv3 = 0, tv4 = 0, tvnulos = 0, tvbrancos = 0, voto;
  do{
    printf("Informe o codigo do voto:\n");
    printf("1 - Candidato 1\n2 - Candidato 2\n3 - Candidato 3\n4 - Candidato 4\n5 - Voto Nulo\n6 - Voto em Branco\n0 - Encerra\n");
    scanf("%f",&voto);
    if (voto == 1) tv1 = tv1 + 1;
      else if (voto == 2) tv2 = tv2 + 1;
        else if (voto == 3) tv3 = tv3 + 1;
          else if (voto == 4) tv4 = tv4 + 1;
            else if (voto == 5) tvnulos = tvnulos + 1;
              else if (voto == 6) tvbrancos = tvbrancos + 1;
    system("cls");
  } while (voto != 0);
  printf("\nO candidato 1 teve %.0f votos", tv1);
  printf("\nO candidato 2 teve %.0f votos", tv2);
  printf("\nO candidato 3 teve %.0f votos", tv3);
  printf("\nO candidato 4 teve %.0f votos", tv4);
  printf("\nHouve %.0f votos nulos", tvnulos);
  printf("\nHouve %.0f votos em branco", tvbrancos);
  printf("\nO percentual de votos nulos sobre o total foi de %.2f", tvnulos/(tv1+tv2+tv3+tv4+tvnulos+tvbrancos)*100);
  printf("\nO percentual de votos em branco sobre o total foi de %.2f", tvbrancos/(tv1+tv2+tv3+tv4+tvnulos+tvbrancos)*100);
  if ((tv1 > tv2) && (tv1 > tv3) && (tv1 > tv4)){
    printf("\nO candidato 1 foi o vencedor");
    if ((tv1 > tv2 + tv3 + tv4))
      printf("\ne obteve mais votos que os outros tres somados");
      else
        printf("\ne nao obteve mais votos que os outros tres somados");
  }
  if ((tv2 > tv1) && (tv2 > tv3) && (tv2 > tv4)){
    printf("\nO candidato 2 foi o vencedor");
    if ((tv2 > tv1 + tv3 + tv4))
      printf("\ne obteve mais votos que os outros tres somados");
      else
        printf("\ne nao obteve mais votos que os outros tres somados");
  }
  if ((tv3 > tv1) && (tv3 > tv2) && (tv3 > tv4)){
    printf("\nO candidato 3 foi o vencedor");
    if ((tv3 > tv1 + tv2 + tv4))
      printf("\ne obteve mais votos que os outros tres somados");
      else
        printf("\ne nao obteve mais votos que os outros tres somados");
  }
  if ((tv4 > tv1) && (tv4 > tv2) && (tv4 > tv3)){
    printf("\nO candidato 4 foi o vencedor");
    if ((tv4 > tv1 + tv2 + tv3))
      printf("\ne obteve mais votos que os outros tres somados");
      else
        printf("\ne nao obteve mais votos que os outros tres somados");
  }
  return 0;
}
