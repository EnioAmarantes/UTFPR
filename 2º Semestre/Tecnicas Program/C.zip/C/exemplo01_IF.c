//10 - Para 2 n�meros quaisquer, informar:
//a) o maior
//b) o menor
//c) se s�o iguais
//entrada de dados: dois n�meros A e B
//sa�da de dados: o maior
//                o menor
//                se s�o iguais
//processamento: a > b - a � o maior
//               a < b - b � o maior
//               a = b - s�o iguais
#include <locale.h> //include para acentua��o em l�ngua portuguesa
#include <stdio.h> /*insere no c�digo fonte os comandos 
                     de entrada e sa�da*/
int main(){ //cabe�alho da fun��o main(), com tipo inteiro
  setlocale(LC_ALL,"Portuguese");//comando para acentua��o em l�ngua portuguesa
  float a, b; //declara��o de vari�veis, ambas do tipo float(real)
  
  printf("Digite o primeiro n�mero: ");//printf - comando de sa�da
  scanf("%f",&a);/*scanf - comando de entrada composto de 
                     	    "%f" - tipo de dado da vari�vel lida
                     	    &a - endere�o de mem�ria da vari�vel lida
                 l� um valor float e armazena no endere�o de mem�ria da vari�vel*/
  printf("Digite o segundo n�mero: ");
  scanf("%f",&b);
  
  if (a > b)   //comando if(se) avalia a express�o l�gica (a > b)
  	printf("\n%f � maior do que %f",a,b);/*o comando printf ser� executado se
                                           a express�o l�gica for verdadeira
             \n - quebra uma linha                                 
  		      %f ...... %f - insere em cada local o valor da vari�vel
				             correspondente ao final da lista*/
    else /*sen�o - agrupa os comandos que ser�o executados se a express�o 
		           l�gica do if correspondente (linha 25) for falsa*/ 
	  if (a < b)						 
	  	printf("\n%f � maior do que %f",b,a);
	    else
           printf("\n%f e %f s�o iguais",a,b);	
	
	return 0;//retorno da fun��o main, que possui tipo inteiro
}
                     
                     
                     