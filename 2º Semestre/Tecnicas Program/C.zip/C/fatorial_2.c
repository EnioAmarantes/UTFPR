#include<stdio.h>
main(){
  int a, b, n, x;
  printf("digite o primeiro valor do intervalo para calcular o fatorial: ");
  scanf("%d",&a);
  printf("digite o segundo valor do intervalo para calcular o fatorial: ");
  scanf("%d",&b);
  while (a <= b){
    n = a;
    x = n - 1;
    while (x > 1){
      n = n * x;
      x--;
    }
    printf("\no fatorial de %d eh %d", a,n);
    a++;
  }
}
