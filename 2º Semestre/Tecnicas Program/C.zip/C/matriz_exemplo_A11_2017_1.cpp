#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <time.h>
#define L 5
#define C 5
int main(){
	setlocale(LC_ALL,"Portuguese");
	
	int m[L][C], i, j, maior, menor;
	
	srand(time(NULL));
	
	for(i =0;i < L;i++)
	  for(j = 0;j < C;j++)	
        m[i][j] = rand()/100;
			
	for(i = 0;i < L;i = i + 1){
		for(j = 0;j < C;j = j + 1)
		   printf("%4d ",m[i][j]);
		printf("\n");
   }
	
	maior = m[0][0];
	menor = m[0][0];
	
	for(i = 0;i < L;i = i + 1)
		for(j = 0;j < C;j = j + 1){
		  if (m[i][j] > maior)
			maior = m[i][j];
		  if (m[i][j] < menor)
			menor = m[i][j];
       }
	
	printf("\nMaior %4d \nMenor %4d",maior,menor);
	
	return 0;
}