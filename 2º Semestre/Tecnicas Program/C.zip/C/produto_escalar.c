/*
a) Fun��o para preencher um vetor somente com n�meros positivos (deve receber o vetor por refer�ncia);
b) Fun��o para mostrar o conte�do de um vetor (deve receber o vetor por refer�ncia);
c) Fun��o que receba dois vetores e retorne o produto escalar desses vetores (dever receber os vetores por refer�ncia; o retorno da fun��o deve ser real);
O produto escalar entre dois vetores pode ser escrito da seguinte forma:
A * B = a1*b1 + a2*b2 + a3*b3 + .... + an*bn
*/
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T 10
void preenche(int [],int t, int valor);
void mostra(int [],int tm);
float produto(int [],int [], int t);
int main(){	
  int a[T], b[T];
  setlocale(LC_ALL, "Portuguese");
  printf("\nVetor A: ");
  preenche(a,T,33);
  mostra(a,T); 
  printf("\nVetor B: ");
  preenche(b,T,13);
  mostra(b,T);
  printf("\nO produto escalar � %f",produto(a,b,T));
  printf("\n");
  return 0;
}
void preenche(int v[],int t, int valor){
  int i;
  srand(time(NULL));
  for(i = 0;i < t;i++)
  	v[i] = rand()/valor+1;
}
void mostra(int v[],int t){
  int i;
  for(i = 0;i < t;i++)
  	printf("%d ",v[i]);
}
float produto(int va[],int vb[],int t){
  int i;
  float soma = 0;
  for(i = 0;i < t;i++)
  	soma = soma + va[i] * vb[i];
  return soma;
}
