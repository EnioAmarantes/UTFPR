#include <stdio.h>
#include <setjmp.h>

#define try jmp_buf jmp; switch(setjmp(jmp)){case 0:
#define throw(e) longjmp(jmp,e)
#define catch(e) break;case e:

/* exce��es */
#define DIV_BY_ZERO 1 /* divis�o por zero */
#define NO_ARG_SPEC 2 /* nenhum argumento especificado */

int main(int argc, char** argv) {
  try {
    if(argc>1) {
      int i = atoi(argv[1]);
      if(i==0)
        throw(DIV_BY_ZERO);
      int x = 10 / i;
      printf("Resultado: %d\n",x);
    }
    else
      throw(NO_ARG_SPEC);
  }
  catch(DIV_BY_ZERO) {
    printf("Argumento invalido... divisao por zero!\n");
  }
  catch(NO_ARG_SPEC) {
    printf("Argumento nao especificado!\n");
  }
}
return 0;
}
