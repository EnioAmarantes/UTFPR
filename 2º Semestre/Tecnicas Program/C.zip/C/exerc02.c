#include <stdio.h>
main(){
  int a, b, c, m, n;
  scanf("%d", &n);
  a = 1;
  b = 2;
  c = 3;
  do{
    m = a * b * c;
    a = a + 1;
    b = b + 1;
    c = c + 1;
  }while (m < n);
  if (m == n) printf("\no numero %d e triangular ", n);
}
