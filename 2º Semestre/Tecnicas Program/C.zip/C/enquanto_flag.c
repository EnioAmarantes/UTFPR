/*
ENQUANTO - Executa um grupo de comandos enquanto a condi��o
           l�gica da estrutura for verdadeira
           � executado 0 ou N vezes, uma vez que a condi��o
           primeiro � verificada e depois os comandos s�o
           executados
           
SINTAXE:

while <condi��o>
{
	<comando(s)>
}

<condi��o> - � uma express�o l�gica cujo resultado sempre ser�
             VERDADEIRO ou FALSO
*/

//calcular a m�dia aritm�tica para um grupo de N valores reais fornecidos
//pelo usu�rio
//entradas de dados: 
//                  cada um dos valores que o usu�rio ir� fornecer
//sa�das de dados:
//                m�dia dos valores fornecidos pelo usu�rio
//processamento:
//              para cada valor que o usu�rio fornecer, som�-lo ao valor
//              anterior j� armazenado em uma vari�vel e contar mais um
//              � quantidade de n�meros informados
//              quando o usu�rio informar que n�o deseja mais fornecer
//              nenhum n�mero, calcular a m�dia, dividindo a soma de todos os
//              n�meros pela quantidade de n�meros fornecidos
#include <stdio.h>
int main(){ 
  float soma, numero;
  int quantidade, fim;
  fim = 1; // inicializa��o da vari�vel de controle do la�o de repeti��o
  soma = 0;
  quantidade = 0;
//a estrutura de repeti��o a seguir depende da interven��o do usu�rio
//para ser finalizada, neste caso dizemos que a vari�vel de controle
//da mesma � um FLAG, que � uma vari�vel que ter� seu valor alterado
//e consequentemente interromper� a estutura de repeti��o.
//Utilizamos um FLAG quando n�o sabemos de antem�o quantas vezes
//uma estutura de repeti��o ser� executada  
  while (fim == 1){  //condi��o de controle do la�o de repeti��o
	 printf("Digite um numero: ");
	 scanf("%f",&numero);
	 soma = soma + numero;
	 quantidade = quantidade + 1;
	 do{
	   printf("\nDeseja continuar? 1 para sim ou 0 para nao :");
	   scanf("%d",&fim); //altera��o do valor da vari�vel de controle
	 }while ((fim != 1) && (fim != 0));
   }
  printf("\nA media e: %f",soma/quantidade);  	
  return 0;	
}