//9.Escreva um programa que leia um vetor de 100 posi��es 
//e mostre-o ordenado 
//em ordem crescente.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define TAM 15
int main(){
	int k[TAM], i, j, x, n, aux;
	
	srand(time(NULL));
		
    i = 0;
    while (i < TAM){
    x = rand()/1000;
    n = 0;
    for(j = 0; j < i; j++)
      if (k[j] == x){
        n = 1;
        j = i + 1;
      }
     if (n == 0) {
      k[i] = x;
      i++;
    }
  }
  
    printf("\n");
	for(i = 0;i < TAM;i = i + 1)
	  printf("%3d",k[i]);    

    for(i = 0;i < TAM;i++){
       for(j = 0;j < TAM - 1;j++){
         if (k[j] > k[j+1]){
	       aux = k[j];
	       k[j] = k[j+1];
	       k[j + 1] = aux;
         } // fim do if
       } //fim do for interno
    } //fim do for externo
    
    printf("\n");
	for(i = 0;i < TAM;i = i + 1)
	  printf("%3d",k[i]);  
  
   return 0;
  
} 