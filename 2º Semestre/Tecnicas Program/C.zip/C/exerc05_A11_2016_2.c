//05 - Ler um n�mero inteiro representando a quantidade de alunos de uma turma 
//e informe a quantidade de grupos de 4 alunos que podem ser formados, e 
//quantos alunos ficam de fora, sem formar um grupo completo
//Entrada: n�mero de alunos de uma turma - n
//Sa�das: quantidade de grupos de 4 alunos - qg
//        quantidade de alunos sem grupo - qs 
//Processamento: qg = n / 4
//               qs = n % 4
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
  int n;
  setlocale(LC_ALL,"Portuguese");
  printf("Digite a quantidade de alunos na turma: ");
  scanf("%d",&n);
  printf("\nHaver� %d grupos com 4 alunos na turma",n/4);
  printf("\n%d alunos n�o far�o parte de nenhum grupo",n%4);

  printf("\n\n%f\n\n",M_PI);  
}