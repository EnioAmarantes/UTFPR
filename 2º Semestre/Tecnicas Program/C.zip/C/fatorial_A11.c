#include <stdio.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 
  double n, x, y;
  printf("digite um n�mero: ");
  scanf("%lf",&n);
//in�cio do while
  x = n - 1;
  y = n;
  while (x > 1){
	 printf("\n%lf * %lf = %lf",y,x,y*x);
	 y = y * x;
	 x = x - 1;	  
  } 
//fim do while
/*
//------------------
//in�cio do FOR
  for(x = n - 1,y = n;x > 1;x = x - 1){
	 printf("\n%9.2f * %4.2f = %9.2f",y,x,y*x);
     y = y * x;
  }
//fim do FOR
//-----------------
//inicio do DO
  x = n - 1;
  y = n;
  do{
 	 printf("\n%9.2f * %4.2f = %9.2f",y,x,y*x);
	 y = y * x;
	 x = x - 1;	  
  }while (x > 1);
//fim do DO
*/   
  printf("\nO fatorial de %lf � %lf",n,y);
}   