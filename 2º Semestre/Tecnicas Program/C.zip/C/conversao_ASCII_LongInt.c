#include <locale.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int main(){
	setlocale(LC_ALL,"Portuguese");
	char ra[8];
	long int RA;
	
	do{
		printf("Digite seu RA: ");
		fflush(stdin);
		gets(ra);
	}while (strlen(ra) < 7);
	
	RA = atol(ra);
    printf("\nString = %s\n", ra);
    printf("\nConvertida em long int = %07ld\n", RA );
	
	return 0;
	
}