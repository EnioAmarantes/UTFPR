#include <stdio.h>
#include <stdlib.h>
int main(){
  int *bin, num, i;
  printf("Digite um numero inteiro: ");
  scanf("%d",&num);

  bin = malloc(1 * sizeof(int));

  for(i = 0;num > 0;i = i + 1){
    bin[i] = num % 2;
    num = num / 2;
    bin = (int *) realloc(bin, 1 * sizeof(int));
  }

  for(i = i - 1;i >= 0;i = i - 1){
    printf("%d",bin[i]);
  }

  return 0;
}
