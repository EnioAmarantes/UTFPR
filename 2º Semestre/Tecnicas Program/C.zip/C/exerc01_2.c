//Obter o nome e a idade de um usu�rio e escrever na tela a seguinte mensagem:
//Hello! FULANO, voc� tem XX anos, para um grupo de 10 pessoas.
#include <stdio.h>

main(){
  int idade, m;
  char nome[50];
  m = 0;
  while (m < 10){
    printf("\nDigite seu nome: ");
    scanf("%s",&nome); //gets(nome);
    printf("\nDigite sua idade: ");
    scanf("%d",&idade);
    printf("\nHello! %s, voce tem %d anos",nome,idade);
    m = m + 1;
  }
}
