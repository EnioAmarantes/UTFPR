/*
14.Fazer um algoritmo que calcule e escreva a soma dos
   50 primeiros termos da s�rie:

 X     1!     2!     3!     4!     5!
     ---- - ---- + ---- - ---- + ---- - ...
 Y     1      3      7      15     31
*/
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  float soma = 0, x = 1, y = 1, fat, aux;
  int cont = 0, sinal = 1;
//**********************************************
//*****COM A VARI�VEL sinal MULTIPLICANDO A SOMA
//**********************************************
  while (cont < 15){
      //in�cio do c�lculo do fatorial do valor atual de x
    fat = x;
    aux = fat - 1;
    while (aux > 1){
      fat = fat * aux;
      aux = aux - 1;
    } //fim do c�lculo do fatorial do valor atual de x
    soma = soma + (fat / y) * sinal;
    sinal = sinal * -1;
    x = x + 1;
    y = y * 2 + 1;
    cont = cont + 1;
  }
  printf("\nsoma --> %f",soma);

//**********************************************
//*****COM A VARI�VEL sinal ALTERNANDO SOMA E SUBTRA��O COM if
//**********************************************
  while (cont < 15){
      //in�cio do c�lculo do fatorial do valor atual de x
    fat = x;
    aux = fat - 1;
    while (aux > 1){
      fat = fat * aux;
      aux = aux - 1;
    } //fim do c�lculo do fatorial do valor atual de x
    if (sinal == 1) //alterna entre soma e subtra��o a partir
      {             //da avalia��o do valor da vari�vel soma
        soma = soma + (fat / y);
        sinal = 2;
      }
      else
        {
        soma = soma - (fat / y);
        sinal = 1;
        }
    x = x + 1;
    y = y * 2 + 1;
    cont = cont + 1;
  }
  printf("\nsoma --> %f",soma);


  return 0;
}
