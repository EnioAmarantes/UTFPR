/*18)2� Quest�o (2,0): Obtenha valores inteiros para uma matriz quadrada de
dimens�o n�o menor que 4x4 e:
�Substitua cada n�mero par na matriz pela soma dos dois n�meros que sejam
sequenciais �mpares a cada um destes n�meros pares. (Utilizar apenas uma
matriz).*/
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define D 4
void recebe(int [D][D],int); //preenche matriz
            //matriz,dimens�o,valor para divis�o RAND()
void exibir(int [D][D]); //mostra o conte�do da matriz
            //matriz,dimens�o  
void troca(int [D][D]); //realiza a troca dos valores na matriz
            //matriz,dimens�o
int main(){	
  int matriz[D][D];
  setlocale(LC_ALL, "Portuguese");
  recebe(matriz,1000);
  printf("\n\nMatriz original: \n");
  exibir(matriz);
  troca(matriz);
  printf("\n\nMatriz resultante : \n");
  exibir(matriz);
  return 0;
}
void recebe(int m[D][D], int valor){
//preenche a matriz com n�meros rand�micos n�o repetidos
 int i, j, aux, r, i2, j2;
 srand(time(NULL));
  i = 0;
  while (i < D){
    j = 0;
    while (j < D){
      aux = rand() / valor + 1;
      r = 0;
      for(i2 = 0; i2 <= i; i2++)
        for(j2 = 0; j2 <= j; j2++)
          if (m[i2][j2] == aux)
             r = 1;
      if (r == 0){
        m[i][j] = aux;
        j++;
      }
    }
    i++;
  }
}
void exibir(int m[D][D]){
  int linha, coluna;
  for(linha = 0 ; linha < D ; linha++){
    for(coluna = 0 ; coluna < D ; coluna++)
      printf("%4d ", m[linha][coluna]);
    printf("\n");
  }
}
void troca(int m[D][D]){
  int linha, coluna, p, s, l2, c2,col;
  for(linha = 0 ; linha < D ; linha++){
    for(coluna = 0 ; coluna < D ; coluna++){
      if (m[linha][coluna] % 2 == 0){
        p = -1; s = -1; col = coluna;
        for(l2 = linha ; l2 < D ; l2++){
          for(c2 = col ; c2 < D ; c2++){
		    if (m[l2][c2] % 2 != 0){
			  if (p == -1)
			    p = m[l2][c2];
			  else
			    if (s == -1){
				  s = m[l2][c2];
                  printf("\nlinha %2d coluna %2d = %4d trocado por %4d e por %4d",linha,coluna,m[linha][coluna],p,s);
				  l2 = D + 1;
				  c2 = D + 1;
				  m[linha][coluna] = p + s;
				}
			}
		  }
		  col = 0;
		}
	  }
	}
  }
}