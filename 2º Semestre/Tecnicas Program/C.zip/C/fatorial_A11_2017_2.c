#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, aux, x;
  printf("\nDigite um n�mero: ");
  scanf("%d",&n);
  aux = n;
  x = n - 1;
  while (x > 1){
    printf("\n aux(%d) * x(%d) = %d",aux,x,aux * x);
    aux = aux * x;
    x = x - 1;
  }
  printf("\nO fatorial de %d � %d",n,aux);
  return 0;
}
