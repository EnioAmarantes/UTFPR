#include <stdio.h>
main(){
  FILE *fptr;
  char ch;
  fptr = fopen("arqtext.txt","w");
  while ((ch = getche()) != '\r')
    putc(ch,fptr);
  fclose(fptr);
}
