/* Quest�o 01 - Implemente um programa que implemente uma matriz 4x4 de n�meros
interiros. Verifique se esta matriz forma um quadrado m�gico, um quadrado m�gico
� formado quando a soma dos elementos de casa linha � igual a soma dos elementos
de cada coluna e � igual a soma dos elementos da diagonal principal e �igual a soma
da diagonal secundaria.*/

#include<stdio.h>

main() {

  int A[4][4],i,j,soma1=0, soma2=0, soma3=0,soma4=0,soma5=0, achou=0;

  srand(time(NULL));

while(!achou){
  soma1=0;
  soma2=0;
  soma3=0;
  soma4=0;
  soma5=0;
  for(i=0;i<4;i=i+1)
    for(j=0;j<4;j=j+1){
     // printf("Digite um valor para a linha %d e coluna %d: ", i,j);
     // scanf("%d", &A[i][j]);
     A[i][j] = rand()/1000;
    }

  printf("\n Matriz \n");

  for(i=0; i<4; i=i+1){
    for(j=0; j<4; j=j+1)
      printf("%3d ", A[i][j]);
    printf("\n");
  }

   //soma a primeira linha da matriz
  for(i=0, j=0; j<4; j++){
    soma1 = soma1 + A[i][j];
  }
  printf("\nsoma1 --> %d",soma1);

   //soma toda a matriz
  i=0;
  while( i < 4){
    for(j=0; j<4; j++){
      soma2 = soma2 + A[i][j];
    }
    i++;
  }
  printf("\nsoma2 --> %d",soma2);

   //soma toda a matriz
  j = 0;
  while( j < 4){
    for(i=0; i<4; i++){
      soma3 = soma3 + A[i][j];
    }
    j++;
  }
  printf("\nsoma3 --> %d",soma3);

  //soma a diagonal principal da matriz
  for( j=0,i=0 ; j<4,i<4 ; j++,i++){
     soma4 = soma4 + A[i][j];
  }
  printf("\nsoma4 --> %d",soma4);

   //soma a digonal secund�ria da matriz
  for( j=3,i=0 ; j>=0,i<4 ; j--,i++){
    soma5 = soma5 + A[i][j];
  }
  printf("\nsoma5 --> %d",soma5);

  if(soma1 == soma4){
    if(soma2 == soma3){
      if(soma4 == soma5){
         printf("\n\n A matriz � um quadrado magico pois as somas sao %d \n", soma1);
         achou = 1;
         }
      }
   }
   else{
     printf(" NAO E QUADRADO MAGICO \n");
   }
}
}
