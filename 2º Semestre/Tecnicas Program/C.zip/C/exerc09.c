/*
Fa�a um programa que leia um n�mero inteiro representando a quantidade de alunos de uma turma e informe
a quantidade de grupos de 4 alunos que podem ser formados, e quantos alunos ficam de fora, sem formar um grupo completo.
*/

#include <stdio.h>
#include <conio.h>

main()
{
  int n;

  printf("Digite a quantidade de alunos da turma ");
  scanf("%d",&n);
  printf("\n A quantidade de grupos com 4 alunos eh %d", n / 4);
  printf("\n Resta(m) %d alunos", n % 4);
  getch();
}
