#include <C:\Users\Gabriel\Documents\_material_para_aulas\_algoritmos\C\potencia.h>

float potencia(float x, float y){
  for(;y > 0;y--)
    x *= x;
  return x;
}
