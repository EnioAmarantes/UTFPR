/*
10. Escreva um programa que leia um vetor de 20 posi��es e mostre- o.
Em seguida, troque o primeiro elemento com o �ltimo, o segundo com o
pen�ltimo, o terceiro com o antepen�ltimo, e assim sucessivamente.
Mostre o novo vetor depois da troca.
*/
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
#define TAM 20
int main(){
  setlocale(LC_ALL,"Portuguese");
  int v[TAM], i, j, aux;
  srand(time(NULL));
//preenche o vetor com n�meros rand�micos
  for(i = 0;i < TAM;i = i + 1)
    v[i] = rand()/1000;
//imprime o vetor original
  printf("\nVetor original\n");
  for(i = 0;i < TAM;i = i + 1)
    printf("%3d",v[i]);
/*
//troca os valores no vetor utilizando um �ndice
  for(i = 0;i < TAM / 2 - 1;i = i + 1){
    aux = v[i];
    v[i] = v[TAM - i - 1];
    v[TAM - i - 1] = aux;
  }
*/
//troca os valores no vetor utilizando dois �ndices
  for(i = 0, j = 19;i < j;i = i + 1, j = j - 1){
    aux = v[i];
    v[i] = v[j];
    v[j] = aux;
  }
//mostra o vetor resultante
  printf("\nVetor resultante\n");
  for(i = 0;i < TAM;i = i + 1)
    printf("%3d",v[i]);

  return 0;
  }
