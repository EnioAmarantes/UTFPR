#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main(){
  setlocale(LC_ALL,"Portuguese");
  int opcao;
//----------------
//DO...WHILE
//----------------
  do
    {
      system("cls");
      printf("\n.Escolha uma das op��es a seguir: ");
      printf("\n1 - M�dia entre os n�meros digitados");
      printf("\n2 - Diferen�a do maior pelo menor");
      printf("\n3 - Produto entre os n�meros digitados");
      printf("\n4 - Divis�o do primeiro pelo segundo\n");
      scanf("%d",&opcao);
    }while ((opcao < 1) || (opcao > 4));
//----------------
//WHILE
//----------------
  opcao = 0;
  while ((opcao < 1) || (opcao > 4))
    {
      system("cls");
      printf("\n..Escolha uma das op��es a seguir: ");
      printf("\n1 - M�dia entre os n�meros digitados");
      printf("\n2 - Diferen�a do maior pelo menor");
      printf("\n3 - Produto entre os n�meros digitados");
      printf("\n4 - Divis�o do primeiro pelo segundo\n");
      scanf("%d",&opcao);
    }
//----------------
//FOR
//----------------
  for(opcao = 0;((opcao < 1) || (opcao > 4));)
    {
      system("cls");
      printf("\n...Escolha uma das op��es a seguir: ");
      printf("\n1 - M�dia entre os n�meros digitados");
      printf("\n2 - Diferen�a do maior pelo menor");
      printf("\n3 - Produto entre os n�meros digitados");
      printf("\n4 - Divis�o do primeiro pelo segundo\n");
      scanf("%d",&opcao);
    }
  return 0;
}
