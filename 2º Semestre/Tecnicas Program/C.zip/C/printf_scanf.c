#include <stdio.h>
#include <locale.h>
main(){
  setlocale(LC_ALL, "Portuguese");

  char nome[50], x;

  printf("Digite seu nome: ");
  gets(nome);
//  scanf("%[^\n]s",&nome);
  printf("Nome: %s",nome);

  printf("\nDigite um caracter: ");
  x = getchar();
//  scanf("%c",&x);
  printf("Um caracter: %c",x);

}
