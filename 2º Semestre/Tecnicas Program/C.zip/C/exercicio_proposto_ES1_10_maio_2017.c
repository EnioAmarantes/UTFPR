/*
Crie um programa que receba do usu�rio o n�mero (inteiro) de uma conta-corrente 
(por ex: 2319) e que informe seu d�gito verificador. Os passos s�o:

(a) Somar n�mero da conta com o seu n�mero invertido. Exemplo 
    Conta 2319
    Invertido 9132
    2319 + 9132 = 11451

(b) Multiplicar cada d�gito obtido do passo (a) pela sua ordem de posicionamento,
 e somar esses resultados. 
    1  1  4  5  1
    5� 4� 3� 2� 1� (ordem da posi��o dos d�gitos)
    Ficaria algo assim: 5*1 + 4*1 + 3*4 + 2*5 + 1*1 = 32

(c) O �ltimo d�gito obtido do passo (b) � o d�gito verificador
    Resultado: 32 , 2 � o d�gito verificador e a conta ficaria: 2319-2
*/
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int n, inv, aux, R, tam, dig;
	printf("\nInforme o n�mero da conta: ");
	scanf("%d",&n);
    tam = 1;
    aux = n;
    while (aux > 0){
		aux = aux / 10;
		tam = tam * 10;
	}
	tam = tam / 10;
    aux = n;
    inv = 0;
	while (aux > 0){
		inv = inv + ((aux % 10) * tam);
		aux = aux / 10;
		tam = tam / 10;
	}
	R = n + inv;
	aux = R;
	tam = 1;
	dig = 0;
	while (aux > 0){
		dig = dig + ((aux % 10) * tam);
	    aux = aux / 10;
	    tam = tam + 1;
	}
	printf("\nConta %d\nInverso %d\nConta + Inverso %d\nDigitos %d\nConta Final %d-%d\n",n,inv,n+inv,dig,n,dig%10);
	return 0;
}