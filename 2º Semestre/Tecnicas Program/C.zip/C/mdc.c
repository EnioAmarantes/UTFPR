/*
O QUE � ALGORITMO DE EUCLIDES?
� um algoritmo criado por Euclides de Alexandria (360 a.C. a 295 a.C)
para o calculo do Max�mo Divisor Comum (mdc).
O QUE � M�XIMO DIVISOR COMUM?
� o maior numero inteiro positivo z, capaz de dividir simultaneamente os inteiros x e y.
mdc(x,y) = z
mdc(6,4) = 2
mdc(18,12) = 6
mdc(110, 90) = 10

*/
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#define T 50
void preenche(long [],long t, long valor);
void mostra(long [],long t);
long mdc(long,long);

int main(){	
  long a[T],i;
  setlocale(LC_ALL, "Portuguese");
  printf("\nVetor A: ");
  preenche(a,T,10);
  mostra(a,T); 
  for(i = 0;i < T - 1;i++)
  	 printf("\nMDC de \t%d \te \t%d \t� \t%d",a[i],a[i+1],mdc(a[i],a[i+1]));
  return 0;  
}
long mdc(long x, long y){
  long r;
  r = x % y;
  while (r != 0){
    x = y;
    y = r;
    r = x % y;
  }  
  return y;
}
void preenche(long v[],long t, long valor){
  long i, x, n, j;
  srand(time(NULL));
  i = 0;
  while (i < t){
   	x = time(NULL) / rand() / valor;
    n = 0;
    for(j = 0; j < i; j++)
      if (v[j] == x){
        n = 1;
        j = i + 1;
      }
    if (n == 0){
      v[i] = x;
      i++;
    }
  }  
}
void mostra(long v[],long t){
  long i;
  for(i = 0;i < t;i++)
  	printf("%d ",v[i]);
}
