/*
7. Escreva um programa que leia dois vetores de 10 posi��es
e fa�a a multiplica��o dos elementos de
mesmo �ndice, colocando o resultado em um terceiro vetor.
Mostre o vetor resultante.
*/
#include <stdio.h>
int main(){
  int a[10], b[10], c[10], i;

  printf("\nprimeiro vetor\n");
  for(i = 0;i < 10;i = i + 1){
    printf("Digite o %d valor para o primeiro vetor: ",i+1);
    scanf("%d",&a[i]);
  }

  printf("\nsegundo vetor\n");
  for(i = 0;i < 10;i = i + 1){
    printf("Digite o %d valor para o segundo vetor: ",i+1);
    scanf("%d",&b[i]);
  }

  for(i = 0;i < 10;i = i + 1)
    c[i] = a[i] * b[i];

  printf("\nvetor resultante\n");
  for(i = 0;i < 10;i = i + 1){
    printf("%d ",c[i]);
  }

  return 0;
}
