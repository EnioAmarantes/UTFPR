//4. Apresentar os n�meros inteiros m�ltiplos de 5, entre 5 e 50.
#include <stdio.h>
int main(){
  int n;

//------WHILE------
  n = 5;
  while (n <= 50)
  {
    printf("%d ",n);
    n = n + 5;
  }

  printf("\n\n");
//------FOR------
  for(n = 5;n <= 50;n = n + 5)
  {
    printf("%d ",n);
  }

  printf("\n\n");
//------DO...WHILE------
  n = 5;
  do
  {
    printf("%d ",n);
    n = n + 5;
  }while (n <= 50);

  return 0;
}
