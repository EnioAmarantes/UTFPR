#include <stdio.h>
main(){
  int tempo, q;
  float massa;
  q = 0;
  tempo = 0;
  printf("informe o valor da massa do material: ");
  scanf("%f",&massa);
  while (massa >= 0.05){
    printf("massa --> %f\n", massa);
    massa = massa / 2;
    tempo = tempo + 73;
    q = q + 1;
  }
  printf("tempo em minutos ---------> %f\n", tempo/60.0);
  printf("massa final --------------> %f\n", massa);
  printf("quantidade de execucoes --> %d\n", q);

}
