//09 - Refazer o exerc�cio n� 01, obtendo o sexo do usu�rio (masculino ou 
//feminino), e alterar a mensagem para:
//Hello! Sr. Fulano, voc� ainda n�o atingiu a maioridade!
//ou
//Hello! Sra. Ciclana, voc� ainda n�o atingiu a maioridade!
//entradas de dados: nome, idade, sexo
//sa�da de dados: Hello! Sr. Fulano, voc� ainda n�o atingiu a maioridade!
//                ou
//                Hello! Sra. Ciclana, voc� ainda n�o atingiu a maioridade!
//processamento: sexo = masculino e idade < 18
//               sexo = feminino e idade < 18
#include <locale.h> 
#include <stdio.h> 
#include <string.h>//para permitir o das fun��es de manipula��o de strings
#include <stdlib.h>//para permitir o uso de fflush(stdin)
int main(){ 
  setlocale(LC_ALL,"Portuguese");
  char nome[50], sexo[15];//[50] determina a quantidade de caracteres da vari�vel
  int idade;
  
  printf("Digite o nome da pessoa: ");
  fflush(stdin);//limpa o buffer de teclado para permitir a leitura de uma string 
  gets(nome);//executa a entrada de dados de uma string - char nome[50]
  printf("Digite MASCULINO ou FEMININO: ");
  fflush(stdin);
  gets(sexo);
  printf("Digite a idade: ");
  scanf("%d",&idade);
/*strcmp(valor1,valor2) - compara se as string constantes em valor1
                          e valor2 s�o iguais. Caso positivo o resultado
                          da compara��o � igual a 0 (zero)
  strupr(valor) - transforma o conte�do de valor para mai�sculo*/  
 
  if ((idade < 18) && (strcmp(strupr(sexo),"MASCULINO") == 0))
  	printf("Hello! Sr. %s, voc� ainda n�o atingiu a maioridade!",nome);
  if ((idade < 18) && (strcmp(strupr(sexo),"FEMININO") == 0))
  	printf("Hello! Sra. %s, voc� ainda n�o atingiu a maioridade!",nome);
/*  
  if (idade < 18)
  	if (strcmp(strupr(sexo),"FEMININO") == 0)
  	  printf("Hello! Sra. %s, voc� ainda n�o atingiu a maioridade!",nome);
    else
      printf("Hello! Sr. %s, voc� ainda n�o atingiu a maioridade!",nome);
  else  
  	if (strcmp(strupr(sexo),"FEMININO") == 0)
  	  printf("Hello! Sra. %s, voc� j� atingiu a maioridade!",nome);
    else
      printf("Hello! Sr. %s, voc� j� atingiu a maioridade!",nome);
*/


   
  return 0;
}