#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define X 3
#define Y 3
void preenche(int [X][Y]);
void imprime(int [X][Y]);
int primo(int);
void primo_c(int, char []);
void primo_p(int [X][Y]);
int main(){	
  int m[X][Y], l, c;
  char resultado[15];
  setlocale(LC_ALL, "Portuguese");
  preenche(m);
  imprime(m);
  printf(" 1--------------------------------\n");
  for(l = 0;l < X;l++)
  	for(c = 0;c < Y;c++){
      	if (primo(m[l][c]))
  		  printf("\nmat[%d][%d]\t%4d\t%s",l,c,m[l][c],"� primo" );
  	      else
		    printf("\nmat[%d][%d]\t%4d\t%s",l,c,m[l][c],"N�o � primo");
	  }
  printf("\n\n 2--------------------------------\n");
  for(l = 0;l < X;l++)
  	for(c = 0;c < Y;c++)
         printf("\nmat[%d][%d]\t%4d\t%s",l,c,m[l][c],primo(m[l][c])? "� primo": "N�o � primo" );	  
// operador tern�rio <condi��o> ? <resultado se condi��o verdadeira> : <resultado se condi��o falsa>     
//                  primo(m[l][c][p])? "� primo": "N�o � primo"
  printf("\n\n 3--------------------------------\n");
  for(l = 0;l < X;l++)
  	for(c = 0;c < Y;c++){
      	primo_c(m[l][c],resultado);
  		printf("\nmat[%d][%d]\t%4d\t%s",l,c,m[l][c],resultado);
	  }
   printf("\n\n 4--------------------------------\n");
   primo_p(m);
   return 0;
}
void preenche(int mat[X][Y]){ 
  int l, c;
  srand(time(NULL));
  for(l = 0;l < X;l++)
  	for(c = 0;c < Y;c++)
  		mat[l][c] = rand()/100;	
}
void imprime(int mat[X][Y]){ 
  int l, c;
  for(l = 0;l < X;l++){
  	for(c = 0;c < Y;c++)
  		printf("mat[%d][%d] %4d ",l,c,mat[l][c]);	
    printf("\n");
  }
}
int primo(int valor){ 
  int m, n, s;
  n = valor;	
  m = n;
  s = 0;
  while(m > 0){
    if (n % m == 0)
   	  s++;	
    m--;	
  }
  if (s == 2)
    return 1;
      else
  	    return 0;
}
void primo_c(int valor, char r[]){ 
  int m, n, s;
  n = valor;	
  m = n;
  s = 0;
  while(m > 0){
    if (n % m == 0)
   	  s++;	
    m--;	
  }
  if (s == 2)
    strcpy(r,"� primo");
      else
  	    strcpy(r,"N�o � primo");
}
void primo_p(int mat[X][Y]){ 
  int m, n, s, l, c;
  for(l = 0;l < X;l++)
  	for(c = 0;c < Y;c++){
      	n = mat[l][c];	
        m = n;
        s = 0;
        while(m > 0){
          if (n % m == 0)
   	        s++;	
          m--;	
        }
        if (s == 2)
          printf("\nmat[%d][%d]\t%4d\t%s",l,c,mat[l][c],"� primo");
          else
  	        printf("\nmat[%d][%d]\t%4d\t%s",l,c,mat[l][c],"N�o � primo"); 		
	  }
}