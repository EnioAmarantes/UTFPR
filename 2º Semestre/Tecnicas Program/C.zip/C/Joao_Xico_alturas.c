//Joao tem 1.50mts e cresce 2cm por ano
//Xico tem 1.30mts e cresce 3cm por ano
//Quantos anos serao necessarios para que 
//Xico seja mais alto do que Joao??

#include <stdio.h>
int main(){
	float Joao, Xico;
	int tempo;

	tempo = 0;  
	for(Joao=1.40,Xico=1.30;Xico <= Joao;Joao=Joao+0.02,Xico=Xico+0.03)
		tempo = tempo + 1;
	printf("\nTempo em anos = %d",tempo);
	
    tempo = 0;
    Joao=1.40;
    Xico=1.30;
    while (Xico <= Joao){
		Joao = Joao + 0.02;
		Xico = Xico + 0.03;
		tempo = tempo + 1;
	}
	printf("\nTempo em anos = %d",tempo);


	return 0;
}
    