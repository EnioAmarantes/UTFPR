//01 - Calcular o pre�o de venda de um carro.
//O pre�o de venda � formado pelo pre�o da montadora, mais 15% de lucro,
//mais 11% de IPI, mais 17% de ICM.
//As porcentagens s�o sobre o pre�o da montadora, que � lido.
//Informe o pre�o final e o valor dos impostos.
//Entradas: pre�o da montadora
//Sa�das: pre�o de venda, valor dos impostos
//Processamento:
//  obter o pre�o da montadora
//  calcular o lucro = pre�o da montadora * 15%
//  calcular o ipi = pre�o da montadora * 11%
//  calcular o icm = pre�o da montadora * 17%
//  mostrar o pre�o final = pm + lucro + ipi + icm
//  mostrar o valor dos impostos = ipi + icm
#include <stdio.h>
#include <locale.h>
int main(){
//configura a sa�da de dados para a l�ngua portuguesa
  setlocale(LC_ALL,"Portuguese");
// declarar vari�veis
  float pm, lucro, ipi, icm, pf, vi;
// ENTRADAS DE DADOS
// printf - comando de sa�da
  printf("Calcula o pre�o final de um carro\n");
  printf("Informe o pre�o da montadora: ");
// scanf - comando de entrada
  scanf("%f",&pm);
// o scanf l� um valor de um tipo - %f � float
// e armazena no endere�o de mem�ria de uma vari�vel
// &pm
//PROCESSAMENTO
  lucro = pm * 0.15;
  ipi = pm * 0.11;
  icm = pm * 0.17;
  pf = pm + lucro + ipi + icm;
  vi = ipi + icm;
//SA�DAS
  printf("\nO valor final � %0.2f",pf);
  printf("\nO valor do impostos � %0.2f",vi);
 return 0;
}
