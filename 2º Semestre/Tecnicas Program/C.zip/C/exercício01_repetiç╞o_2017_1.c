//Pit�goras descobriu que existe outra forma de calcula pot�ncia de grau 2: 
//atrav�s da soma de n�meros �mpares.
//Ele descobriu que n^2 igual a soma dos n primeiros n�meros naturais �mpares.
//Exemplo: 5^2 = 1 + 3 + 5 + 7 + 9 = 25
//Escreva um programa que utilize o m�todo descrito anteriormente para mostrar 
//a pot�ncia de grau 2 de todos os n�meros em um intervalo fechado [n1, n2] 
//informado pelo usu�rio.
#include <stdio.h>
int main(){
	int n1, n2, c, s, x;
	printf("Digite o inicio do intervalo: ");
	scanf("%d",&n1);
	printf("Digite o final do intervalo: ");
	scanf("%d",&n2);
	while(n1 <= n2){
	   x = 1;
	   s = 0;
	   c = 1;
	   printf("%02d^2 = %02d",n1,x);
	   while (c <= n1){
	  	  s = s + x;
		  x = x + 2;
		  c = c + 1;
		  printf(" + %02d",x);
	   }
	   printf(" = %02d\n",s);
	   n1 = n1 + 1;
	}
	return 0;
}
