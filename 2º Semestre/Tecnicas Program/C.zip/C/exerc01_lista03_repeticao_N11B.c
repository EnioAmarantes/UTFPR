/*
Construa um algoritmo que, dado um conjunto de valores inteiros
e positivos, determine qual o menor valor do conjunto.
O final do conjunto de valores � conhecido atrav�s do valor zero,
que n�o deve ser considerado.
entradas de dados: conjunto de valores inteiros e positivos
sa�das de dados: o menor e o maior valores do conjunto
processamento: para cada valor digitado, se for maior do que zero
   ent�o eu devo verificar se o mesmo � menor do que o menor valor
   j� armazenado, caso positivo eu armazeno o novo valor na vari�vel
   menor; depois verifico se o valor digitado � maior do que
   o maior valor armazenado, caso positivo eu armazeno o novo valor
   na vari�vel maior.
   Se o n�mero digitado for igual a zero, ent�o o programa deve ser
   encerrado ao mostrar a sa�da de dados
*/
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, maior, menor;
  maior = -1;
  menor = -1;
  do{
     printf("Digite um n�mero inteiro maior do que zero\n");
     printf("Digite 0 (zero) para finalizar\n");
     scanf("%d",&n);
     if ((maior == -1) && (n >0))
       maior = n;
     if ((menor == -1) && (n >0))
       menor = n;
     if ((n > maior) && (n > 0))
       maior = n;
     if ((n < menor) && (n > 0))
       menor = n;
  }while (n != 0);
  printf("\nO maior n�mero � %d", maior);
  printf("\nO menor n�mero � %d", menor);
  return 0;
}
