#include <stdio.h>

main(){
  float s, c, fat, y;
  int f;
  s = 0;
  c = 1;
  f = 1;
  while(c <= 50){

    fat = c;
    y = fat - 1;
    while(y > 1){
      fat = fat * y;
      y = y - 1;
    }

    if (f == 1){
      printf("\ns = s - ((c * 2 - 1) / fat)) \n");
      printf("%.1f = %.1f - ((%.1f * 2 - 1) / %.1f)",s, s, c, fat);
      printf("   f --> %d\n", f);
      s = s - ((c*2-1)/fat);
      f = 2;
    }
    else
      if (f == 2){
        printf("\ns = s * ((c * 2 - 1) / fat)) \n");
        printf("%.1f = %.1f * ((%.1f * 2 - 1) / %.1f)",s, s, c, fat);
        printf("   f --> %d\n", f);
        s = s * ((c*2-1)/fat);
        f = 3;
      }
      else
        if (f == 3){
          printf("\ns = s + ((c * 2 - 1) / fat)) \n");
          printf("%.1f = %.1f + ((%.1f * 2 - 1) / %.1f)",s, s, c, fat);
          printf("   f --> %d\n", f);
          s = s + ((c*2-1)/fat);
          f = 4;
        }
        else{
          printf("\ns = s / ((c * 2 - 1) / fat)) \n");
          printf("%.1f = %.1f / ((%.1f * 2 - 1) / %.1f)",s, s, c, fat);
          printf("   f --> %d\n", f);
          s = s / ((c*2-1)/fat);
          f = 1;
        }
     c = c + 1;
  }
  printf("%f",s);
}
