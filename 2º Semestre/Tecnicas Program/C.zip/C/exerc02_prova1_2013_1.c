/*
Escreva um programa em C que dever� receber um n�mero inteiro qualquer digitado pelo usu�rio.
Depois de receber o n�mero o programa deve utilizar somente n�meros entre 1000 e 9999, inclusive, e mostrar:

N�mero lido -> : 1245
Unidade -----> : 5
Dezena ------> : 40
Centena -----> : 200
Milhar ------> : 1000

Se o n�mero informado n�o estiver entre 1000 e 9999, inclusive, o programa dever� mostar:

O n�mero lido est� fora da faixa de valores v�lidos
*/
#include <stdio.h>
main(){
  int n;
  printf("Digite um numero inteiro: ");
  scanf("%d", &n);
  if ((n >= 1000) && (n <= 9999)){
    printf("\nnumero lido -> %d", n);
    printf("\nunidade -----> %d", n % 10);
    printf("\ndezena ------> %d", n % 100 - n % 10);
    printf("\ncentena -----> %d", n % 1000 - n % 100);
    printf("\nmilhar ------> %d", n % 10000 - n % 1000);
  }
  else
    printf("\nO numero esta fora da faixa de valores validos");
}
