/*
BIN�RIO PARA DECIMAL:
---------------------
A convers�o de n�meros bin�rios para n�meros decimais � realizada atrav�s de
uma somat�ria dos algarismos bin�rios da direita pra a esquerda onde cada termo
da somat�ria � multiplicado por 2 elevado a um n�mero sequencial iniciado em 0.

Vamos converter o n�mero 1000102 para a base decimal.

Primeiro invertermos o n�mero para fazermos a somat�ria da direita para a
esquerda do n�mero original.
100010 -> 010001
Agora vamos somar cada n�mero, multiplicando por 2 elevado a um n�mero
sequencial iniciado em 0.
0*2^0 + 1*2^1 + 0*2^2 + 0*2^3 + 0*2^4 + 1*2^5
0 + 1*2^1 + 0 + 0 + 0 + 1*2^5
1*2^1 + 1*2^5
2 + 32
Resultado: 34
*/
#include <stdio.h>
#include <locale.h>]
#include <math.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int bin, num, i, tam;
  printf("Digite um n�mero inteiro base 10: ");
  scanf("%d",&bin);
  i = 0;
  num = 0;
  while(bin > 0){
    num = num + ((bin % 10) * pow(2,i));
    bin = bin / 10;
    i = i + 1;
  }
  printf("\n%d\n",num);
  return 0;
}
