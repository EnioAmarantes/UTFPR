/*
Preencher dois vetores A e B com n�meros inteiros e
mostrar na tela a uni�o de A e B (todos os n�meros de A
e todos os n�meros de B, sem repeti��es)
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
	srand(time(NULL));
	int A[20], B[20], C[40], i, j, achou;
	for(i = 0;i < 20;i++){
	  A[i] = rand()/1000;
      C[i] = A[i];
	  B[i] = rand()/1000;
	  C[i+20] = B[i];
	}
	printf("\nVetor A\n");
	for(i = 0;i < 20;i++){
		printf("%d ",A[i]);
	}	
    printf("\nVetor B\n");
	for(i = 0;i < 20;i++){
		printf("%d ",B[i]);
	}
    printf("\nVetor C\n");
	for(i = 0;i < 40;i++){
		printf("%d ",C[i]);
	}
    printf("\n\n");
	for(i = 0;i < 40;i++){
		achou = 0; //achou recebe 0(zero) que � FALSO
		for(j = 0;j < i;j++){
			if (C[i] == C[j]){
				achou = 1; //se encontrado n�mero repetido
				break;     //achou recebe 1 que � VERDADEIRO
			}
		}
		if (!achou) //!achou ==> � a nega��o do valor l�gico da
			printf("%d ",C[i]);	//vari�vel achou. Se um n�mero repetido
	}                         //n�o for encontrado, N�O achou (!achou)  
                              //ser� verdadeiro e o n�mero ser� mostrado
    return 0;
}