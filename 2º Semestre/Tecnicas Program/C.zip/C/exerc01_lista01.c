//1.	Fazer um algoritmo que calcule e escreva o valor de S:
//      1     3     5     7           99
// S = --- + --- + --- + --- + ... + ----
//      1     2     3     4           50
#include <stdio.h>
main(){
  float x, y, s;
  for(s = 0, x = 1, y = 1;y <= 50;x = x + 2, y = y + 1)
    s = s + x / y;
  printf("O valor de S e %f", s);
}
