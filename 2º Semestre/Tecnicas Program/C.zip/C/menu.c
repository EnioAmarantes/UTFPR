#include <stdio.h>
main(){
  char op;
  do{
    printf("\na - opcao 1\nb - opcao 2\nc - opcao 3\nd - sair\n");
    fflush(stdin);
    scanf("%c", &op);
  }while ((op < 97) || (op > 100));
  switch (op){
    case 97:
        printf("\nopcao 1");
        break;
    case 98:
        printf("\nopcao 2");
        break;
    case 99:
        printf("\nopcao 3");
        break;
    case 100:
        printf("\nsair");
        break;
  }
}
