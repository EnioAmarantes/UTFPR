#include <stdio.h>
#include <stdlib.h>
struct aluno{
  int codigo;
  char nome[50];
} typedef A;

void preenche(A v[], int t){
  int i;
  for(i = 0;i < t;i++){
    printf("Digite o codigo do aluno %d: ",i);
    scanf("%d",&v[i].codigo);
    printf("Digite o nome do aluno %d: ",i);
    fflush(stdin);
    scanf("%[^\n]s",&v[i].nome);
  }
}

void imprime_total(A v[], int t){
  int i;
  for(i = 0; i < t; i++)
    printf("Codigo --> %d \n",v[i].codigo);
    printf("Nome ----> %s \n",v[i].nome);
}

void imprime_valor(A v[], int p){
    printf("Codigo --> %d \n",v[p].codigo);
    printf("Nome ----> %s \n",v[p].nome);
}

main(){
  A vetor[3], i;
  preenche(vetor,3);
  imprime_total(vetor,3);
  printf("\n");
  imprime_valor(vetor,1);
}
