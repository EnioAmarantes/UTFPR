//1 - Apresentar os n�meros inteiros pares entre 0 e 100.
#include <stdio.h>
int main(){
  int n;

//------WHILE------
  n = 0;
  while (n <= 100)
  {
    printf("%d ",n);
    n = n + 2;
  }

  printf("\n\n");
//------FOR------
  for(n = 0;n <= 100;n = n + 2)
  {
    printf("%d ",n);
  }

  printf("\n\n");
//------DO...WHILE------
  n = 0;
  do
  {
    printf("%d ",n);
    n = n + 2;
  }while (n <= 100);

  return 0;
}
