#include <stdio.h>
void soma(int, int, int *);
int subtrai(int,int);
int main(){
  int a, b, r;
  a = 13;
  b = 27;
  soma(a,b,&r);
  printf("\nsoma -------> %d",r);
  printf("\nsubtracao --> %d",subtrai(a,b));
  return 0;
}
void soma(int x, int y, int *z){
  *z = x + y;
}
int subtrai(int x, int y){
  return x - y;
}
