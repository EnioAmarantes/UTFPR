/*
01 � Obter o nome e a idade de um usu�rio e escrever na tela
a seguinte mensagem:

Hello! FULANO, voc� tem XX anos,

para um grupo de 10 pessoas.

entradas de dados:
  nome e idade para um grupo de 10 pessoas
sa�das de dados:
  mensagem  --> Hello! FULANO, voc� tem XX anos
    para um grupo de 10 pessoas
processamento:
  utilizar uma vari�vel para contar a quantidade
  de vezes que os dados de entrada s�o obtidos e a
  mensagem de sa�da � realizada
  a vari�vel de controle (utilizada para contar)
  deve ser inicializada em 1 e incrementada de 1 em 1
  a cada vez que um conjunto de entrada/sa�da � realizado
  quando o valor da vari�vel de controle for maior do que 10
  a estrututra de repeti��o deve ser encerrada
*/
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#define Q 2
int main(){
  setlocale(LC_ALL,"Portuguese");
  char nome[50];// vari�vel do tipo STRING
  int idade, cont;
  cont = 1;
  while (cont <= Q)
   {
     printf("\nDigite o %d� nome: ",cont);
     fflush(stdin);
     gets(nome);
     printf("\nDigite a %d� idade: ",cont);
     scanf("%d",&idade);
     printf("\nHello! %s voc� tem %d anos",nome,idade);
     cont = cont + 1;
   }
  return 0;
}
