#include <stdio.h>

enum letras {a = 1, b, c, d, e, f, g, h, i, j} valores;
int main(){
  char m[3][3] = {0,1,a,b,c,d,e,f,g};
  int i, j;;

  for(i = 0;i < 3;i = i + 1)
   for(j = 0;j < 3;j = j + 1)
     printf("m[%d][%d] (%d) * %d = %d\n",i,j,m[i][j],i+1,m[i][j]*(i+1));

  return 0;
}
