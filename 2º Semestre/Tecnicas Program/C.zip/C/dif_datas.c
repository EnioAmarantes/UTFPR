#include <stdio.h>
#include <locale.h>
int main(){
  int  a1, m1, d1, a2, m2, d2, a3, m3, d3, dif, ok;
  setlocale(LC_ALL,"Portuguese");
  ok = 0;
  printf("digite o ano da primeira data: ");
  scanf("%d",&a1);
  printf("digite o m�s da primeira data: ");
  scanf("%d",&m1);
  printf("digite o dia da primeira data: ");
  scanf("%d",&d1);
  if (a1 <= 0) {
    printf("Data inv�lida");
    ok = 1;
    }
    else
      if ((d1 < 1) || (d1 > 31)) {
        printf("Data inv�lida");
        ok = 1;
	  }
        else
          if ((m1 < 1) || (m1 > 12)) {
            printf("Data inv�lida");
            ok = 1;
		  }
            else
              if (((m1 == 4) || (m1 == 6) || (m1 == 9) || (m1 == 11)) && (d1 == 31)) {
                printf("Data inv�lida");
                ok = 1;
			  }
                else
                  if ((m1 == 2) && (d1 > 29)) {
                    printf("Data inv�lida");
                    ok = 1;
				  }
                    else
                      if ((m1 == 2) && (d1 == 29) && (a1 % 4 != 0)) {
                        printf("Data inv�lida");
                        ok = 1;
					  }

  if (ok == 0) {
    printf("digite o ano da segunda data: ");
    scanf("%d",&a2);
    printf("digite o m�s da segunda data: ");
    scanf("%d",&m2);
    printf("digite o dia da segunda data: ");
    scanf("%d",&d2);
    if (a2 <= 0) {
      printf("Data inv�lida");
      ok = 1;
	}
      else
        if ((d2 < 1) || (d2 > 31)) {
          printf("Data inv�lida");
          ok = 1;
		}
          else
            if ((m2 < 1) || (m2 > 12)) {
              printf("Data inv�lida");
              ok = 1;
			}
              else
                if (((m2 == 4) || (m2 == 6) || (m2 == 9) || (m2 == 11)) && (d2 == 31)){ 
                  printf("Data inv�lida");
                  ok = 1;
				}
                  else
                    if ((m2 == 2) && (d2 > 29)){ 
                      printf("Data inv�lida");
                      ok = 1;
					}
                      else
                        if ((m2 == 2) && (d2 == 29) && (a2 % 4 != 0)){ 
                          printf("Data inv�lida");
                          ok = 1;
						}
  }

  if (ok == 0){ 
    dif = (a2 * 365 + m2 * 30 + d2) - (a1 * 365 + m1 * 30 + d1);
    if (dif < 0)
	   dif = dif * -1;
    a3 = dif / 365;
    m3 = dif % 365 / 30;
    d3 = dif % 365 % 30;
    printf("%d anos, %d meses e %d dias",a3,m3,d3);
  }
  return 0;
}