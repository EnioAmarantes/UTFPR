#include <stdio.h>
void dec_binario(int n){
  if((n/2)!=0)
    dec_binario(n/2);
  printf("%d",n%2);
}
int bin_decimal(int n){
   int exp=0,res=0;
   while(n>0){
      res=res+(n%10)*(pow(2,exp++));
      n=n/10;
   }
   return res;
}
main(){
  int x,b;
  printf("\nDigite um numero base 10 para converte-lo para binario: ");
  scanf("%d",&x);
  dec_binario(x);
  printf("\n\nDigite um numero binario para converte-lo para base 10: ");
  scanf("%d", &b);
  printf("\n%d",bin_decimal(b));
}
