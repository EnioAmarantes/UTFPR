//05 - Ler um n�mero inteiro representando a quantidade de alunos de
//uma turma e informe a quantidade de grupos de 4 alunos que podem
//ser formados, e quantos alunos ficam de fora, sem formar um grupo
//completo
//entradas de dados: quantidade de alunos da turma
//sa�das de dados: n�mero de grupos com 4 alunos e
//                 quantidade de alunos fora de grupos
//processamento:
//    obter a quantidade de alunos
//    obter o quociente da divis�o inteira da quantidade por 4 - n�mero de grupos
//    obter o resto da divis�o inteira da quantidade por 4 - alunos fora de grupos
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int alunos, grupos, fora;

  printf("Informe o n�mero de alunos da turma: ");
  scanf("%d",&alunos);

  grupos = alunos / 4; // a barra (/) neste caso � DIV - quociente
                       // da divis�o inteira, pois os dois operandos
                       // s�o inteiros
  fora = alunos % 4; // o percentual (%) � MOD - resto da divis�o inteira
                     // os dois operandos s�o inteiros

  printf("\nH� %d grupos de 4 alunos na turma",grupos);
  printf("\nH� %d alunos fora de grupos na turma", fora);

  return 0;
}
