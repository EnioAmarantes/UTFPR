//07 - Calcular a quantidade de latas de tinta necess�rias, e
//tamb�m o custo, para pintar um tanque cil�ndrico de combust�vel,
//em que s�o fornecidos a altura e o raio do mesmo, al�m do pre�o
//da lata de tinta.
//Sabe-se que:
//a)cada lata cont�m 5 litros de tinta;
//b)cada litro de tinta pinta 3 metros quadrados;
//entradas de dados:
//    altura, raio, pre�o
//sa�das de dados:
//    quantidade, custo
//processamento:
//    obter a altura do cilindro
//    obter o raio do cilindro
//    obter o pre�o da lata de tinta
//    calcular a �rea do cilindro:
//       area = 2*(3.14 * raio^2) + altura * raio * 2 * 3.14
//    calcular a quantidade de latas:
//       quantidade = area / 5 / 3
//    calcular o custo:
//       custo = quantidade * pre�o
#include <stdio.h>
#include <math.h>
#include <locale.h>
int main(){
   setlocale(LC_ALL,"Portuguese");
   float raio, altura, preco, quantidade, area, custo;
   printf("Informe a altura do cilindro: ");
   scanf("%f",&altura);
   printf("Informe o raio do cilindro: ");
   scanf("%f",&raio);
   printf("Informe o pre�o da lata de tinta: ");
   scanf("%f",&preco);
   area = 2 *(M_PI * pow(raio,2.0)) + altura * raio * 2 * M_PI;
   quantidade = area / 5 / 3;
   custo = quantidade * preco;
   printf("\nSer�o necess�rias %2.2f latas de tinta",quantidade);
   printf("\nO custo ser� de %2.2f",custo);
  return 0;
}
