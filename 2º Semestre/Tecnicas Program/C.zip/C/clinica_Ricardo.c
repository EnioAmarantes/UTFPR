#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct{
    char codigoPaciente [10];
    char nome [10];
    char telefone [11];
    int idade;
    char sexo;
} Paciente;


typedef struct{
    char codigoMedico [10];
    char nome [10];
    char especialidade [10];
    float valorConsulta;
} Medico;

typedef struct{
    char codigoPaciente [10];
    char codigoMedico [10];
    char dataConsulta [8];
    char diaDaSemana [15];
} Consulta;

void clean_stdin(void){
    int c;
    do{
        c = getchar();
    }while (c != '\n' && c != EOF);
}

int inserirPaciente (int numPaciente, Paciente paciente[], int *cap);
void exibePaciente (int numPaciente, Paciente paciente[]);
int inserirMedico (int numMedico, Medico medico[], int *capMedico);
void exibeMedico (int numMedico, Medico medico[]);
int inserirConsulta (int numConsulta, Consulta consulta[], int *capConsulta, Medico medico[], Paciente paciente[], int numMedico, int numPaciente);
void exibeConsulta (int numConsulta, Consulta consulta[]);

void main(){
    Paciente *paciente; Medico *medico; Consulta *consulta;
    int numPaciente; int numMedico; int numConsulta;
    int *cap; int *capMedico; int *capConsulta;

    paciente = (Paciente *) malloc (sizeof(Paciente));
    medico = (Medico *) malloc (sizeof(Medico));
    consulta = (Consulta *) malloc (sizeof(Consulta));

    if(paciente ==  NULL){
        printf ("** Erro: Memoria Insuficiente **");
        exit(1);
    }

    if(medico == NULL){
        printf ("** Erro: Memoria Insuficiente **");
        exit(1);
    }

    if(consulta == NULL){
        printf ("** Erro: Memoria Insuficiente **");
        exit(1);
    }

    FILE *pacienteArq; FILE *medicoArq; FILE *consultaArq;
    pacienteArq = fopen("paciente.dat", "r");
    medicoArq = fopen("paciente.dat", "r");
    consultaArq = fopen("paciente.dat", "r");

    if (pacienteArq == NULL){
        numPaciente = 0;
        paciente = (Paciente*) malloc((sizeof(Paciente)) * 10);
    }
    else{
        fread(&numPaciente, sizeof(int), 1, pacienteArq);
        *cap = numPaciente * 2;
        paciente = (Paciente *) malloc(sizeof(Paciente) * numPaciente);
        fread(pacienteArq, sizeof(Paciente), numPaciente, pacienteArq);
        fclose(pacienteArq);
    }

    if (medicoArq == NULL){
        numMedico = 0;
        medico = (Medico*) malloc((sizeof(Medico)) * 10);
    }
    else{
        fread(&numMedico, sizeof(int), 1, medicoArq);
        *capMedico = numMedico * 2;
        medico = (Medico *) malloc(sizeof(Medico) * numMedico);
        fread(medicoArq, sizeof(Medico), numMedico, medicoArq);
        fclose(medicoArq);
    }

    if (consultaArq == NULL){
        numConsulta = 0;
        consulta = (Consulta*) malloc((sizeof(Consulta)) * 10);
    }
    else{
        fread(&numPaciente, sizeof(int), 1, consultaArq);
        *capConsulta = numConsulta * 2;
        consulta = (Consulta *) malloc(sizeof(Consulta) * numConsulta);
        fread(consultaArq, sizeof(Consulta), numConsulta, consultaArq);
        fclose(consultaArq);
    }

    int menu = 0;
    while (menu != -1){
        printf("\nCLINICA\n");
        printf("-----------------------\n");
        printf("\n1. Adicionar paciente\n");
        printf("2. Adicionar medicos\n");
        printf("3. Marcar consulta\n");
        printf("4. Ver pacientes\n");
        printf("5. Ver medicos\n");
        printf("6. Ver consultas\n");
        printf("7. Sair\n");
        printf(">: ");
        scanf("%d", &menu);

        switch (menu){
            case 1:
                numPaciente = inserirPaciente (numPaciente, paciente, cap);
                break;
            case 2:
                numMedico = inserirMedico(numMedico, medico, capMedico);
                break;
            case 3:
                numConsulta = inserirConsulta(numConsulta, consulta, capConsulta, medico, paciente, numMedico, numPaciente);
                break;
            case 4:
                exibePaciente(numPaciente, paciente);
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                menu = -1;
                break;
        }

    }
    free(paciente);
}

void sair(int numPaciente, Paciente paciente[], int numMedicos, Medico medico[], int numConsulta, Consulta consulta[]){
    FILE *pacFile; FILE *medFile; FILE *consFile;
    pacFile = fopen("paciente.dat", "w");
    fwrite(&numPaciente, sizeof(int), 1, pacFile);
    fwrite(paciente, sizeof(Paciente), numPaciente, pacFile);
    fclose(pacFile);

    medFile = fopen("medico.dat", "w");
    fwrite(&numMedicos, sizeof(int), 1, medFile);
    fwrite(medico, sizeof(Medico), numMedicos, medFile);
    fclose(medFile);

    consFile = fopen("consulta.dat", "w");
    fwrite(&numConsulta, sizeof(int), 1, consFile);
    fwrite(consulta, sizeof(Consulta), numConsulta, consFile);
    fclose(consFile);
}

int inserirPaciente (int numPaciente, Paciente paciente[], int *cap){
    printf("\nNum de pac->>> %d\n   ", numPaciente);
    char codigoPaciente [10]; int i = 0; int flag = 0;
    if (numPaciente == *cap){
        int cap_ = *cap;
        cap_ = cap_ * 2;
        *cap = cap_;
        paciente= realloc(paciente, sizeof(Paciente) * cap_);
    }

    clean_stdin();
    do{
        printf("Informe o c�digo do paciente: ");
        scanf("%s", codigoPaciente);
        clean_stdin();

        for (i = 0; i < numPaciente; i++){
            if (strcmp(paciente[i].codigoPaciente, codigoPaciente)){
                flag++;
            }
        }

    }while (flag != numPaciente);
    strcpy(paciente[numPaciente].codigoPaciente, codigoPaciente);

    printf("Informe o nome do paciente: ");
    scanf("%[^\n]s", paciente[numPaciente].nome);
    clean_stdin();

    printf("Informe a idade de %s: ", paciente[numPaciente].nome);
    scanf("%d", &paciente[numPaciente].idade);
    clean_stdin();

    printf("Informe o telefone de %s: ", paciente[numPaciente].nome);
    scanf("%s", paciente[numPaciente].telefone);
    clean_stdin();

    printf("Informe o sexo de %s (f/m): ", paciente[numPaciente].nome);
    scanf("%c", &paciente[numPaciente].sexo);
    clean_stdin();

    numPaciente++;

    return numPaciente;
}

int inserirConsulta(int numConsulta, Consulta consulta[], int *capConsulta, Medico medico[], Paciente paciente[], int numMedico, int numPaciente){
    char codigoPaciente [10]; char codigoMedico [10]; int i = 0; int flag = 0;

    if (numConsulta == *capConsulta){
        int cap_ = *capConsulta;
        cap_ *= 2;
        *capConsulta = cap_;
        consulta = realloc(consulta, sizeof(Consulta) * cap_);
    }

    clean_stdin();
    do{
        printf("Informe o c�digo do medico: ");
        scanf("%s", codigoMedico);
        clean_stdin();

        for (i = 0; i < numMedico; i++){
            if (strcmp(medico[i].codigoMedico, codigoMedico)){
                flag++;
            }
        }

    }while (flag == 0);
    strcpy(consulta[numConsulta].codigoMedico, codigoMedico);

    clean_stdin();
    do{
        printf("Informe o c�digo do paciente: ");
        scanf("%s", codigoPaciente);
        clean_stdin();

        for (i = 0; i < numPaciente; i++){
            if (strcmp(paciente[i].codigoPaciente, codigoMedico)){
                flag++;
            }
        }

    }while (flag == 0);
    strcpy(consulta[numConsulta].codigoPaciente, codigoMedico);

    printf("Informe a data da consulta: ");
    scanf("%s", consulta[numConsulta].dataConsulta);
    clean_stdin();

    printf("Informe o dia da semana da consulta: ");
    scanf("%s", consulta[numConsulta].diaDaSemana);
    clean_stdin();

    numPaciente++;

    return numPaciente;
}

int inserirMedico(int numMedico, Medico medico[], int *capMedico){
    int i = 0; int flag = 0;
    if (numMedico == *capMedico){
        int cap_ = *capMedico;
        cap_ = cap_ * 2;
        *capMedico = cap_;
        medico = realloc(medico, sizeof(Medico) * cap_);
    }
    clean_stdin();
    do{
        printf("Informe o c�digo do medico: ");
        scanf("%s", &medico[numMedico].codigoMedico);
        for (i = 0; i < numMedico; i++){
            if (strcmp(medico[i].codigoMedico, medico[numMedico].codigoMedico)){
                flag++;
            }
        }

    }while (flag != 0);

    clean_stdin();
    printf("Informe o nome do medico: ");
    scanf("%s", &medico[numMedico].nome);

    clean_stdin();
    printf("Informe a especialidade %s: ", medico[numMedico].nome);
    scanf("%s", &medico[numMedico].especialidade);

    clean_stdin();
    printf("Informe o valor da consulta de %6.2f: ", medico[numMedico].valorConsulta);
    scanf("%f", &medico[numMedico].valorConsulta);


    numMedico++;

    return numMedico;
}

void exibePaciente(int numPaciente, Paciente paciente[]){
    int i = 0;

    char cod [] = "Codigo";
    char nome[] = "Nome";
    char idade[] = "Idade";
    char sexo[] = "Sexo";
    char telefone[] = "Telefone";
    printf("\n------------------------Paciente-------------------------------------------\n");
    printf("\n---------------------------------------------------------------------------\n");
    printf("| %10s | %10s | %10s | %10s | %11s |", cod, nome, idade, sexo, telefone);
    printf("\n---------------------------------------------------------------------------\n");
    for(i = 0; i < numPaciente; i++){
        printf("%6s\t", paciente[i].codigoPaciente);
        printf("%6s\t", paciente[i].nome);
        printf("%6d\t", paciente[i].idade);
        printf("%6c\t", paciente[i].sexo);
        printf("%11s\t\n", paciente[i].telefone);
    }

}

void exibeMedico(int numMedico, Medico medico[]){
    int i = 0;

    char cod [] = "Codigo";
    char nome[] = "Nome";
    char especialidade[] = "Especialidade";
    char vc[] = "Valor Consulta";
    printf("\n------------------------Medico---------------------------------------------\n");
    printf("\n---------------------------------------------------------------------------\n");
    printf("| %10s | %10s | %10s | %10s |", cod, nome, especialidade, vc);
    printf("\n---------------------------------------------------------------------------\n");
    for(i = 0; i < numMedico; i++){
        printf("%6s\t", medico[i].codigoMedico);
        printf("%6s\t", medico[i].nome);
        printf("%6s\t", medico[i].especialidade);
        printf("%6.2f\t\n", medico[i].valorConsulta);
    }

}

void exibeConsulta(int numConsulta, Consulta consulta[]){
    int i = 0;

    char codPac [] = "Cod pac";
    char codMed [] = "Cod med";
    char dataConsulta[] = "Data cons";
    char diaSemana[] = "Dia semana";

    printf("\n------------------------Consulta-------------------------------------------\n");
    printf("\n---------------------------------------------------------------------------\n");
    printf("| %10s | %10s | %10s | %10s |", codPac, codMed, dataConsulta, diaSemana);
    printf("\n---------------------------------------------------------------------------\n");
    for(i = 0; i < numConsulta; i++){
        printf("%6s\t", consulta[i].codigoPaciente);
        printf("%6s\t", consulta[i].codigoMedico);
        printf("%6s\t", consulta[i].dataConsulta);
        printf("%6s\t", consulta[i].diaDaSemana);
    }
}
