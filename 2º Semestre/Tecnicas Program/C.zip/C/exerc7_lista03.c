//7.Construa um algoritmo que leia um conjunto de dados contendo altura e sexo
// (masculino e feminino) de 50 pessoas e depois calcule e escreva:
//- o a maior e a menor altura do grupo;
//- e a m�dia de altura das mulheres;
//- e o n�mero de homens e a diferen�a percentual entre estes e as mulheres.
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#define Q 2
int main(){
	setlocale(LC_ALL,"Portuguese");
	int sexo, qt, altura, maior, menor, qh;
	float media;
	media = 0;
	maior = -1; 
	menor = 300;
	qt = 0;
	qh = 0;
	while (qt < Q){
		printf("Digite a altura da %d� pessoa em centimetros: ",qt+1);
		scanf("%d",&altura);
		do{
		  printf("Digite 1 para FEMININO ou 2 para MASCULINO: ");
		  scanf("%d",&sexo);
		}while ((sexo != 1) && (sexo != 2));
		if (altura > maior)
			maior = altura;
		if (altura < menor)
			menor = altura;
		if (sexo == 1)
			media = media + altura;
		    else
			   qh = qh + 1;
		qt = qt + 1;
		system("cls");
	}
	system("cls");
	printf("\nA maior altura e %d", maior);
	printf("\nA menor altura e %d", menor);
	printf("\nA media de altura das mulheres e %f", media/(Q-qh));
	printf("\nO numero de homens e %d", qh);
	printf("\nA diferenca percentual entre homens e mulheres e %d", (qh-(Q-qh))/Q*100);
	printf("\n\n");
	system("pause");
	return 0;
}

