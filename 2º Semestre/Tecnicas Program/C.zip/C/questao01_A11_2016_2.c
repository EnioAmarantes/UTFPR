//Quest�o 01 (1,5): 
//Dizemos que um n�mero natural � triangular se ele � produto de tr�s 
//n�meros naturais consecutivos.
//Exemplo: 120 � triangular, pois 4 * 5 * 6 = 120.
//Escrever um programa que mostre todos os n�meros triangulares entre n1 e n2.
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
    int n1, n2, a;   
    printf("Digite o primeiro valor do intervalo: ");
    scanf("%d",&n1);
    printf("Digite o segundo valor do intervalo: ");
    scanf("%d",&n2);   
    while (n1 <= n2){
    	 a = 1;
    	 while ((a * (a + 1) * (a + 2)) <= n1){
             if (a * (a + 1) * (a + 2) == n1){
                 printf("%6d � triangular pois %3d  * %3d  * %3d = %6d\n", n1, a, a + 1, a + 2,n1);
                 a = n1 + 1;
			 }
             a = a + 1;
		 }
		 n1 = n1 + 1;
	}
	return 0;
}
