#include <stdio.h>
#include <locale.h>
//  Jo�o tem 1,20 mts e cresce 3 cent�metros por ano
//  Carlos tem 1,30 mts e cresce 2 cent�metros por ano
//  Em quantos anos Jo�o ser� mais alto do que Carlos?
//
//WHILE com acumulador para controlar a parada da condi��o
//
int main(){
  setlocale(LC_ALL,"Portuguese");
  float Joao, Carlos;
  int tempo;
//------------------
//WHILE
//------------------
  Joao = 1.20;
  Carlos = 1.30;
  tempo = 0;

  while (Joao <= Carlos)
   {
     Joao = Joao + 0.03;
     Carlos = Carlos + 0.02;
     tempo = tempo + 1;
   }
  printf("\nSer�o necess�rios %d anos",tempo);

//------------------
//DO...WHILE
//------------------
  Joao = 1.20;
  Carlos = 1.30;
  tempo = 0;

  do
   {
     Joao = Joao + 0.03;
     Carlos = Carlos + 0.02;
     tempo = tempo + 1;
   }while (Joao <= Carlos);
  printf("\nSer�o necess�rios %d anos",tempo);

//------------------
//FOR
//------------------

  for(Joao = 1.20, Carlos = 1.30, tempo = 0;;)
  {
     Joao = Joao + 0.03;
     Carlos = Carlos + 0.02;
     tempo = tempo + 1;
  }
  printf("\nSer�o necess�rios %d anos",tempo);

  return 0;
}
