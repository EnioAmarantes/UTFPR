#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL, "Portuguese");
  int m[5][5] = {0,15,396,90,15,15,0,411,75,30,396,411,0,486,411,90,75,486,0,105,15,30,411,105,0};
  int iti[15] = {0,4,3,2,1,0,3,2,4,1,0,2,1,4,1};
  char cid[5][10] = {"Londrina", "Cambe","Curitiba","Maringa","Ibipora"};
  int j, i, s, s2, soma;
/*
Fa�a um algoritmo que receba o itiner�rio de uma viagem entre estas cidades (considere qualquer itiner�rio e tamb�m a
repeti��o de trechos entre as cidades com um m�ximo de 15 trechos percorridos), armazenados em um vetor da seguinte
forma (este vetor deve receber os dados do itiner�rio e o algoritmo deve permitir somente a digita��o dos c�digos que
existem no vetor de cidades).
*/
//preenche o vetor com os nomes das cidades
//  for(i = 0; i < 5; i++){
//    printf("Digite o nome da cidade cujo c�digo ser� %d ",i);
//    gets(cid[i]);
//  }
//preenche a digonal principal com zeros
//  for(i = 0;i <= 4; i++)
//    m[i][i] = 0;
//preenche a matriz com a dist�ncia entre as cidades
//  for(i = 0; i <= 4; i++)
//    for(j = 0; j < i; j++){
//      printf("Digite a dist�ncia entre %s e %s: ",cid[i],cid[j]);
//      scanf("%d",&m[i][j]);
//      m[j][i] = m[i][j];
//   }
//mostra a matriz com a dist�ncia entre as cidades
//  printf("\nMatriz de dist�ncia entre cidades:\n");
//  for(i = 0;i <= 4; i++){
//    for(j = 0;j <= 4; j++)
//      printf("%4d",m[i][j]);
//    printf("\n");
//  }
//preenche o vetor com o itiner�rio
//  for(i = 0; i <= 14; i++){
//    do{
//      printf("Digite o codigo da %d cidade do itinerario: ", i+1);
//      for(j = 0; j <= 4; j++){
//         printf("\n%d - %s ",j,cid[j]);
//      }
////      printf("\n0 - Londrina\n1 - Cambe\n2 - Curitiba\n3 - Maringa\n4 - Ibipora\n");
//      scanf("\n%d", &iti[i]);
//      system("cls");
//    }while ((iti[i] <0) || (iti[i] > 4));
//  }
/*Calcule e mostre um relat�rio da seguinte forma:
Cidade	        quilometragem percorrida
Londrina
Ibipor�	                 15
Maring�	                105
Curitiba	            486
*/
  for(i = 0; i < 15; i++)
    printf("%d  ", iti[i]);

  printf("\n\ncidade\tkm percorrida\t km acumulada\n\n");
//********** SOLU��O 01 - in�cio **********//
//  s = 0;
//  soma = 0;
//  for(i = 0; i <= 14; i++){
//    s2 = s;
//    s = iti[i];
//    if (i == 0)
//      printf("%s\n", cid[s]);
//      else{
//        soma = soma + m[s][s2];
//        printf("%s   \t%5d\t\t%5d\n", cid[s],m[s][s2],soma);
//      }
//  }
//********** SOLU��O 01 - fim **********//
//printf("\n\n");
//********** SOLU��O 02 - in�cio **********//
  printf("%s\n", cid[iti[0]]);
  for(i = 1, soma = 0; i <= 14; i++){
    soma = soma + m[iti[i-1]][iti[i]];
    printf("%s   \t%4d\t%5d\n", cid[iti[i]],m[iti[i-1]][iti[i]],soma);
  }
//********** SOLU��O 02 - fim **********//
  printf("\n\nKm total \t%5d\n\n", soma);
  return 0;
}
