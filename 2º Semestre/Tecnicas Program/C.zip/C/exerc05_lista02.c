/*
5. Dados tr�s n�meros inteiros distintos, exiba-os em ordem crescente.
 entradas de dados:
      a, b, c
sa�das de dados:
      a, b, c em ordem crescente
processamento:
   1� m�todo:
      se a < b e b < c entao escreva a b c
      se a < c e c < b entao escreva a c b
      se b < a e a < c entao escreva b a c
      se b < c e c < a entao escreva b c a
      se c < a e a < b entao escreva c a b
      se c < b e b < a entao escreva c b a
   2� m�todo
      se a > b  entao
         aux = a
         a = b
         b = aux
      se b > c entao
         aux = b
         b = c
         c = aux
      se a > b  entao
         aux = a
         a = b
         b = aux
      escreva a b c
*/
#include <stdio.h>
#include <locale.h>
 int main(){
   setlocale(LC_ALL,"Portuguese");
   int a, b, c, aux;
   printf("Digite tr�s n�meros inteiros separados por / \n");
   scanf("%d/%d/%d",&a,&b,&c);
//1� m�todo com IFs simples
   if ((a < b) && (b < c))
      printf("\n%d %d %d",a,b,c);
   if ((a < c) && (c < b))
      printf("\n%d %d %d",a,c,b);
   if ((b < a) && (a < c))
      printf("\n%d %d %d",b,a,c);
   if ((b < c) && (c < a))
      printf("\n%d %d %d",b,c,a);
   if ((c < a) && (a < b))
      printf("\n%d %d %d",c,a,b);
   if ((c < b) && (b < a))
      printf("\n%d %d %d",c,b,a);
//1� m�todo com IFs encadeados
   if ((a != b) && (b != c) && (a != c))
     if ((a < b) && (b < c))
       printf("\n%d %d %d",a,b,c);
       else
         if ((a < c) && (c < b))
           printf("\n%d %d %d",a,c,b);
           else
             if ((b < a) && (a < c))
               printf("\n%d %d %d",b,a,c);
               else
                 if ((b < c) && (c < a))
                   printf("\n%d %d %d",b,c,a);
                   else
                     if ((c < a) && (a < b))
                       printf("\n%d %d %d",c,a,b);
                       else
                         printf("\n%d %d %d",c,b,a);
//2� m�todo IFs simples
   if ((a != b) && (b != c) && (a != c))
   {
     if (a > b)
     {
        aux = a;
        a = b;
        b = aux;
     }
     if (b > c)
     {
        aux = b;
        b = c;
        c = aux;
     }
     if (a > b)
     {
        aux = a;
        a = b;
        b = aux;
     }
     printf("\n%d %d %d",a,b,c);
   }
   return 0;
 }
