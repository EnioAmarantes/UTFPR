#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T 88
main(){
  float soma, media, notas[T];
  int i, j, k;

  srand(time(NULL));
  	 
  for(i = 0;i < T;i++)
  	notas[i] = 0;

  j = 1;
  k = 1;
  for(i = 0;i < T;i++){
//	 printf("Digite a %d nota do %d aluno: ",j, k);
//	 scanf("%f",&notas[i]);
     notas[i] = rand()/1000.0;
	 j = j + 1;
	 if (j > 4){
	 	j = 1;
	 	k = k + 1;
	 } 
  }

  soma = 0;
  media = 0; 
  j = 1;
  k = 1;
  printf("\nNotas do aluno %d",k);
    for(i = 0;i < T;i++){
     printf("\n\t%d - %f",j,notas[i]); 	
	 soma = soma + notas[i];
	 j = j + 1;
	 if (j > 4){
	   printf("\nA media do %d aluno e %f",k,soma/4);
       printf("\n--------------------------");
	   k = k + 1;
	   if (k <= T / k)
	     printf("\nNotas do aluno %d",k);
   	   j = 1;
	   media = media + soma;	 
       soma = 0;	 
	 } 
  }
  printf("\nA media da turma e %f",media/T);     
}