#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  float x1, x2, y1, y2, d;
  printf("Informe o valor de x1 e de y1: ");
  scanf("%f %f",&x1,&y1);
  printf("Informe o valor de x2: ");
  scanf("%f",&x2);
  printf("Informe o valor de y2: ");
  scanf("%f",&y2);
//  raiz((X2 - X1)^2 + (Y2 - Y1)^2)
  d = pow(pow(x2-x1,2.0) + pow(y2-y1,2.0),0.5);
  printf("A dit�ncia entre os pontos � %f",d);
  return 0;
}
