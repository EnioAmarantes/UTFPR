#include <stdio.h>
main (){
	int m[6][6];
	int *p;
	int count;
	p=m[0];
    srand(time(NULL));
	for (count=0;count<36;count++){
         	*p=rand()/100;
        	p++;
    }
    p=m[0];
	for (count=1;count<=36;count++){
        	printf("%d \t ", *p);
        	p++;
        	if ((count % 6 == 0) && (count > 0))
        	  printf("\n");
    }
}
