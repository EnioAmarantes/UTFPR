#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, x, aux;
  printf("\ndigite um n�mero inteiro: ");
  scanf("%d",&n);
  aux = n;
  x = n - 1;
  while(x > 1)
  {
//     printf("\n\t%d X %d = %d",n,x,n*x);
     n = n * x;
     x = x - 1;
  }
  printf("\nO fatorial de %d � %d",aux,n);
  return 0;
}
