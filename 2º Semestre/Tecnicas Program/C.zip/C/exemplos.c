#include <stdio.h>
main()
{
  float x = 10.45;
  printf("%f", x - (int)x);

}
