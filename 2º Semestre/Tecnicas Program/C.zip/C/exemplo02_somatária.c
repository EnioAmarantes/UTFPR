#include <stdio.h>

main(){
  float S, d, n;
  int sinal;

  S = 0;
  d = 1;
  n = 1000;
  sinal = 1;

/*  while (d <= 50){
    S = (S + n / d) * sinal;
    sinal = sinal * -1;
    n = n - 3;
    d++;
  }
*/
  while (d <= 50){
    if (sinal = 1){
      S = S + n / d;
      sinal = 0;
    }
    else{
      S = S - n / d;
      sinal = 1;
    }
    n = n - 3;
    d++;
  }

  printf("%f",S);
}
