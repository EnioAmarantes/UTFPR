#include <locale.h> 
#include <stdio.h> 
int main(){ 
  setlocale(LC_ALL,"Portuguese");
  
  float a, b;
  
  printf("Digite o primeiro n�mero: ");
  scanf("%f",&a);
  printf("Digite o segundo n�mero: ");
  scanf("%f",&b);
  
  if (a > b)  
  	printf("\n%f � maior do que %f",a,b);
    else  
	  if (a < b)						 
	  	printf("\n%f � maior do que %f",b,a);
	    else
           printf("\n%f e %f s�o iguais",a,b);	
       
  if (a > b)  
  	printf("\n%f � maior do que %f",a,b);
  if (a < b)						 
  	printf("\n%f � maior do que %f",b,a);
  if (a == b)
  	printf("\n%f e %f s�o iguais",a,b);       
	
	return 0;
}
            