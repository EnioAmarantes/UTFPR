/*
1�  Quest�o:  Um  programador  est�  preocupado  em  rela��o  a  seu  desempenho  num  curso  de
computa��o. Em seu primeiro programa ele cometeu 1 erro; em seu segundo programa dois erros; no
terceiro, quatro erros, e assim por diante. Ele est� cometendo, por programa, duas vezes o n�mero de
erros que cometeu no programa anterior. O curso dura treze semanas, com dois programas por semana.
Preparar um algoritmo para calcular o n�mero de erros que este programador espera cometer em seu
programa final.
*/
#include <stdio.h>
main(){
   int erros, i;
   for(i = 1, erros = 1; i < 26; i++)
     erros = erros * 2;
   printf("O total de erros eh %d", erros);
  // printf("O total de erros eh %.0f", pow(2.0,25.0));
}
