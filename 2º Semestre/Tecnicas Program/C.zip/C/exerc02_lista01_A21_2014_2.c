/*02 - Calcular o sal�rio final de um trabalhador, recebendo a quantidade de horas trabalhadas, a quantidade de horas extras,
quantidade de horas ausentes e o valor do sal�rio m�nimo, sabendo que:
a)as horas trabalhadas e ausentes valem 4% do sal�rio m�nimo;
b)as horas extras valem 50% a mais do que as horas trabalhadas;
c)o sal�rio final � igual a soma das horas trabalhadas com as hora extras, descontadas as horas ausentes e 11% de INSS.
*/
#include <stdio.h>
main(){
  float sf, qht, qhe, qha, vsm;
  printf("Digite o valor do sal�rio minimo: ");
  scanf("%f", &vsm);
  printf("Informe a quantidade de horas trabalhadas: ");
  scanf("%f", &qht);
  printf("Informe a quantidade de horas extras: ");
  scanf("%f", &qhe);
  printf("Informe a quantidade de horas ausentes: ");
  scanf("%f", &qha);
  sf = (vsm*0.04*qht + vsm*0.06*qhe - vsm*0.04*qha) * 0.89;
  printf("O salario final e %2.2f", sf);
}
