//function double fmod(double x, double y) returns the remainder of x divided by y.
//
//function double modf(double x, double *integer) returns the fraction component 
//(part after the decimal), and sets integer to the integer component.
//

#include <stdio.h>
#include <math.h>

int main ()
{
   float a, b;
   int c;
   
   a = 9.2;
   b = 13.0;
   c = 2.0;
   
   printf("Resto de %f / %d eh %lf\n", a, c, fmod(a,c));
   printf("Resto de %f / %f eh %lf\n", a, b, fmod(a,b));
   
//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
   
   double x, fractpart, intpart;

   x = 8.123456;
   fractpart = modf(x, &intpart);

   printf("\nParte inteira de      = %lf\n", intpart);
   printf("Parte fracionaria de  = %lf \n", fractpart);

//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
   
   int m, n;
   
   m = 13;
   n = 4;
   
   printf("\nQuociente de %d / %d eh %d\n", m, n, m / n);
   printf("Resto de %d / %d eh %d\n", m, n, m % n);   
      
   return(0);   
   
}