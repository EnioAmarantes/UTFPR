#include <stdio.h>
void troca(int *a, int *b){
  int aux;
  aux = *a;
  *a = *b;
  *b = aux;
}
int main(){
  int a, b, c;
  printf("Digite o primeiro valor: ");
  scanf("%d",&a);
  printf("Digite o segundo valor: ");
  scanf("%d",&b);
  printf("Digite o terceiro valor: ");
  scanf("%d",&c);
  printf("\n");
  if (a > b)
    troca(&a,&b);
  if (b > c)
    troca(&b,&c);
  if (a > b)
    troca(&a,&b);
  printf("\n%d %d %d",a,b,c);
  return 0;
}
