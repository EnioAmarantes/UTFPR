#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
    int n1, n2, resto, aux, n1b, n2b, fim;
    fim = 1;
    printf("Este programa calcula o MDC e o MMC de dois n�meros\n");
    while (fim){
	  printf("Digite o primero n�mero: ");
      scanf("%d", &n1);
      printf("Digite o segundo n�mero: ");
      scanf("%d", &n2);
      if ((n1 != 0) && (n2 != 0)){
        if (n1 < n2){
    	  aux = n1;
    	  n1 = n2;
    	  n2 = aux;
	    }
	    n1b = n1;
	    n2b = n2;           
        resto = n1 % n2;
        while(resto != 0){
          n1 = n2;
          n2 = resto;
          resto = n1 % n2;         
        }		    
        printf("\nMDC = %d\nMMC = %d ", n2, n1b * n2b / n2); 
	  }
	  do{
          printf("\n\nDeseja fazer outro c�lculo? 1 para SIM ou 0 para N�O: ");
          scanf("%d",&fim);
	    }while ((fim != 1) && (fim != 0));
	}
	printf("\n\n");
	system("pause");
    return 0;          
}