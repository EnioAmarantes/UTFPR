#include <stdio.h>
#include <stdlib.h>
main ()
{
  float vect[6];// = { 1.3, 4.5, 2.7, 4.1, 0.0, 100.1 };

  int m[3][3];// = {1,22,331,4,5,16,7,8,9};
  
  int c, l;

  for(c=0;c<6;c++){ 
    printf("Digite o %d� valor para o vetor: ",c+1);
    scanf("%f",&vect[c]);  
  }
  for(c=0;c<6;c++)
    printf("%.2f ",vect[c]); 

  for(l=0;l<3;l++)
    for(c=0;c<3;c++)
       m[l][c] = 0;


  printf("\n");
  for(l=0;l<3;l++){
    for(c=0;c<3;c++)
       printf("%4d",m[l][c]);
    printf("\n");
  }
}