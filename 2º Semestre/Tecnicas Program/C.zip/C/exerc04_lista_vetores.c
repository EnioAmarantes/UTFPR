//4. Fa�a um programa que leia um vetor K[30]. Troque a seguir,
// todos os elementos de ordem �mpar do vetor com os elementos 
// de ordem par imediatamente posteriores.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
	int k[30], i, aux;
	
	srand(time(NULL));
	
	for(i = 0;i < 30;i = i + 1)
	  k[i] = rand()/1000;
	
    printf("\n");
	for(i = 0;i < 30;i = i + 1)
	  printf("%3d",k[i]);    
	
	for(i = 1;i < 28;i = i + 2){
      aux = k[i];
	  k[i] = k[i + 1];
	  k[i + 1] = aux;		
	}
  
    printf("\n");
	for(i = 0;i < 30;i = i + 1)
	  printf("%3d",k[i]);
 	
	  return 0;
}