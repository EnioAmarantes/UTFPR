int main()
  {
    printf("\033[41m"); /* fundo vermelho */
    printf("\033[37m"); /* primeiro plano branco */
    printf("Exibindo o fundo em vermelho e o primeiro plano em branco.\n");
    return(0);
  }
