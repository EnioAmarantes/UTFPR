#include <stdio.h>
main(){
   int n1, n2, maior, menor, x;
   char f;
   f = 's';
   x = 0;
   while (f == 's'){
     printf("\nInforme o primeiro numero: ");
     scanf("%d", &n1);
     printf("Informe o segundo numero: ");
     scanf("%d", &n2);
     if (n1 > n2){
        printf("\nMaior --> %d", n1);
        printf("\nMenor --> %d", n2);
     }
        else
          if (n2 > n1){
            printf("\nMaior --> %d", n2);
            printf("\nMenor --> %d", n1);
          }
          else
            printf("\nIguais");

     if (x == 0){
       maior = n1;
       menor = n1;
       x = 1;
     }
     else{
       if (n1 > maior)
          maior = n1;
       if (n2 > maior)
          maior = n2;
       if (n1 < menor)
          menor = n1;
       if (n2 < menor)
          menor = n2;
     }

     printf("\nDeseja informar outros numeros? (s/n)");
     fflush(stdin);
     scanf("%c", &f);
   }
  printf("\nMaior numero do conjunto --> %d", maior);
  printf("\nMenor numero do conjunto --> %d", menor);
}
