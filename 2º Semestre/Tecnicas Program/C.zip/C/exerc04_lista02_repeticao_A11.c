//4.	Fazer um algoritmo que calcule e escreva a seguinte soma:
//       1     2     3     4     5     6           -10
//  S = --- - --- + --- - --- + --- - --- +  ... + ----
//       1     4     9     16    25    36           100 
//
//Entradas: nenhuma
//Sa�da: valor de S
//Processamento: podemos considerar que S � a soma consecutiva
//               da divis�o de X pelo quadrado de X, sendo que X
//               come�a em 1 e �  incrementado de 1 em 1 at� 10.
//               O �ltimo valor de X � negativo
//               Cada termo deve ter seu sinal alterando, come�ando
//               positivo
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float x, s;
	int sinal;
/*	s = 0;
	sinal = 1;
	x = 1;
	while (x <= 9){
		s = s + (x / pow(x,2.0)) * sinal;
		sinal = sinal * -1;
		x = x + 1;
	}
	s = s + (-x / pow(x,2.0));
	printf("O valor de S � %f",s);
//
//OU
//
*/	
	s = 0;
	sinal = 1;
	x = 1;
	while (x <= 9){
		if( sinal == 1){
		  s = s + (x / pow(x,2.0));
		  sinal = 2;
		}
		else
		{
		  s = s - (x / pow(x,2.0));
		  sinal = 1;
		}
		x = x + 1;
	}
	s = s + (-x / pow(x,2.0));
	printf("O valor de S � %f",s);		
	return 0;
}
