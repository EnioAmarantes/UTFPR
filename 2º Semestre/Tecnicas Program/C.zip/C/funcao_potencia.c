#include <stdio.h>

float potencia(float a, float b)
{
  float R;
  R = 1;
  while (b > 0){
    R = R * a;
    b--;
  }
  return R;
}

main(){
  float x, y;
  int b;
  printf("\nDigite um valor para x: ");
  scanf("%f",&x);
  printf("\nDigite um valor para y: ");
  scanf("%f",&y);
  printf("%.2f elevado a %.2f --> %.2f", x, y, potencia(x,y));
}
