/*
Quest�o 04:
Escrever um algoritmo para ler 15 elementos de uma matriz A 3x5.
Construir uma matriz B 3x5 de mesmo tipo, observando a seguinte lei de forma��o:
�Todo elemento de B dever� ser o fatorial do elemento de A correspondente�.
*/
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int a[3][5], b[3][5], l, c, fat, aux;
  srand(time(NULL));
//preenche a matriz com n�meros rand�micos
  for(l = 0;l < 3;l = l + 1)
    for(c = 0;c < 5;c = c + 1)
      a[l][c] = rand() /10000+2;
//imprime a matriz a
  printf("\nMatriz A\n");
  for(l = 0;l < 3;l = l + 1){
    for(c = 0;c < 5;c = c + 1)
      printf("%5d",a[l][c]);
    printf("\n");
  }
//calcula o fatorial de cada elemento da matriz a
//e o armazena na posi��o correspondente na matriz b
  for(l = 0;l < 3;l = l + 1)
    for(c = 0;c < 5;c = c + 1){
      fat = a[l][c]; //linhas 30 a 35 - c�lculo do fatorial do elemento atual da matriz a
      aux = fat - 1;
      while (aux > 1){
         fat = fat * aux;
         aux = aux - 1;
      }
      b[l][c] = fat;
    }
//imprime a matriz b
  printf("\nMatriz B\n");
  for(l = 0;l < 3;l = l + 1){
    for(c = 0;c < 5;c = c + 1)
      printf("%4d",b[l][c]);
    printf("\n");
  }
  return 0;
}
