//2 - Apresentar os n�meros inteiros �mpares entre 0 e 100.
#include <stdio.h>
int main(){
  int n;

//------WHILE------
  n = 1;
  while (n <= 100)
  {
    printf("%d ",n);
    n = n + 2;
  }

  printf("\n\n");
//------FOR------
  for(n = 1;n <= 100;n = n + 2)
  {
    printf("%d ",n);
  }

  printf("\n\n");
//------DO...WHILE------
  n = 1;
  do
  {
    printf("%d ",n);
    n = n + 2;
  }while (n <= 100);

  return 0;
}
