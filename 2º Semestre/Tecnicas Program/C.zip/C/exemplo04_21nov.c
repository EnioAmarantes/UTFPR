#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	char frase[255],palavra[15];
	int i, j, achou, count;
	printf("frase: ");
	fflush(stdin);
	gets(frase);
	printf("palavra: ");
	fflush(stdin);
	gets(palavra);
	count = 0;
	for(i = 0;i < strlen(frase);i++){
		achou = 0;
		if (frase[i] == palavra[0]){
			for(j = 1;j < strlen(palavra);j++){
				if (frase[i+j] != palavra[j]){
					achou = 1;
				}
			}
			if (achou == 0){
			  count++;	
			}
		}
	}
	printf("\n%d\n",count);
  return 0;
}	