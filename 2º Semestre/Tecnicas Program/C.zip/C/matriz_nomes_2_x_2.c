#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
int main(){

  char nomes[2][2][50]={"Luiz XVI", "Maria Antonieta","Francisco","Jo�o"};
  int lin, col, p;
    
  setlocale(LC_ALL, "Portuguese");
  
  printf("\n");

  for(lin = 0;lin < 2;lin++){
   for(col = 0;col < 2;col++)
     printf("%s\t",nomes[lin][col]);
   printf("\n");
  }
  
  printf("\n");
 
   for(lin = 0;lin < 2;lin++){
	for(col = 0;col < 2;col++)
	   for(p = 0;p < 50;p++)
   	  	  putchar(nomes[lin][col][p]);
	  printf("\n");
  }
  
  printf("\n");  
  for(lin = 0;lin < 2;lin++){
	for(col = 0;col < 2;col++)
	   for(p = 0;nomes[lin][col][p] != '\0';p++)
   	  	  putchar(nomes[lin][col][p]);
	  printf("\n");
  } 
  return 0;
}