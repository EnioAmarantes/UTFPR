#include "C:\Users\gcanh\OneDrive\Documentos\_material_para_aulas\_algoritmos\C\lib\minhasbibliotecas.h"
#include <conio.h>
#include <windows.h>
void gotoxy(int x, int y){
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x-1,y-1});
}

int main ()
{
//in�cio
   gotoxy(50,4);
   printf("   O  \n");
   gotoxy(50,5);
   printf("  \\|/ \n");
   gotoxy(50,6);
   printf("   |  \n");
   gotoxy(50,7);
   printf("  / \\ \n");
//1� erro
   Sleep(2000);
   gotoxy(50,4);
   printf("   O  \n");
   gotoxy(50,5);
   printf("  \\|/ \n");
   gotoxy(50,6);
   printf("   |  \n");
   gotoxy(50,7);
   printf("  /   \n");
//2� erro
   Sleep(2000);
   gotoxy(50,4);
   printf("   O  \n");
   gotoxy(50,5);
   printf("  \\|/ \n");
   gotoxy(50,6);
   printf("   |  \n");
   gotoxy(50,7);
   printf("      \n");
	return 0;
}
