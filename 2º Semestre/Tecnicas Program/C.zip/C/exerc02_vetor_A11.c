/*
2. Fa�a um programa que leia um vetor N[20]. A seguir,
encontre o menor elemento do vetor N e a sua posi��o
dentro do vetor, mostrando: �O menor elemento de N �, M,
�e sua posi��o dentro do vetor �:�,P
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  srand(time(NULL));

  int n[20], i, menor, p1, maior, p2;
//preenche o vetor com n�meros rand�micos
  for(i = 0;i < 20;i = i + 1)
    n[i] = rand()/1000;
//mostra o conte�do do vetor na tela
  printf("\n");
  for(i = 0;i < 20;i = i + 1)
    printf("%d ",n[i]);
  printf("\n");
//encontra o menor elementos do vetor e sua posi��o
  p1 = 0;       //armazena a posi��o do menor valor
  menor = n[0];//inicializo a vari�vel menor
  p2 = 0;
  maior = n[0];
  for(i = 1;i < 20;i = i + 1){
    if (n[i] < menor){
      menor = n[i];
      p1 = i;
    }
    if (n[i] > maior){
      maior = n[i];
      p2 = i;
    }

  }
//mostra na tela o menor elemento e sua posi��o
  printf("\nO menor elemento do vetor � %d e sua posi��o � %d",menor, p1);
  printf("\nO maior elemento do vetor � %d e sua posi��o � %d",maior, p2);

  return 0;
}
