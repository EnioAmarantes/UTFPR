/*03 - Escreva um algoritmo que diga se uma capital brasileira � da regi�o Nordeste
       ou Sudeste, de acordo com a op��o digitada pelo usu�rio.
       Em caso do usu�rio digitar o nome de uma capital
       que n�o esteja entre as op��es, escreva que a capital � de outra regi�o.
*/
#include <stdio.h>

main(){
  int op;
  printf("Escolha:\n");
  printf("\n1 - Maceio\n2 - Salvador\n3 - Fortaleza\n4 - Sao Luiz\n5 - Joao Pessao");
  printf("\n6 - Recife\n7 - Terezina\n8 - Natal\n9 - Aracaju");
  printf("\n10 - Vitoria\n11 - Sao Paulo\n12 - Rio de Janeiro\n13 - Belo Horizonte");
  scanf("%d",&op);
  if ((op >= 1) && (op <= 9))
    printf("\nNordeste");
    else
      if ((op >= 10) && (op <= 13))
         printf("\nSudeste");
         else
            printf("\nERRO");
}
