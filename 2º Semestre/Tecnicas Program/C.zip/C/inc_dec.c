#include <stdio.h>

main() {
  int x;

  x = 1;

  printf("%d | %d  | %d  | %d", x, ++x, x++, x);

  getch();
}
