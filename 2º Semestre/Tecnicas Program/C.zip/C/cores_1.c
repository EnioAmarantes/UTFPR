#include <conio2.h>
#include <stdio.h>

int main(){
  textcolor(RED);
  cprintf("\n\n\n\n\t\tHello World\n");
  textcolor(GREEN);
  cprintf("\n\n\n\n\t\t\tHello World\n");
  textcolor(BLUE);
  cprintf("\n\n\n\n\t\t\t\tHello World\n");
  return 0;
}
