#include <math.h>
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  printf("\ncalcular 2^3 (dois elevado a terceira pot�ncia)");
  printf("\nPOW(2.0,3.0) ----> %f",pow(2.0,3.0));
  printf("\nEXP(3 * LOG(2)) -> %f",exp(3 *log(2)));

  printf("\ncalcular a raiz cubica de 2");
  printf("\nPOW(2.0,1.0/3.0) ----> %f",pow(2.0,1.0/3.0));
  printf("\nEXP(1.0/3.0 * LOG(2)) -> %f",exp(1.0/3.0 *log(2)));
  return 0;
}
