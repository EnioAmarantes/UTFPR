#include <stdio.h>
#include <math.h>
#include <locale.h>

 main()
 {
     int x;
     setlocale(LC_ALL, "Portuguese");

     printf("\nx � igual a %d", x);
 }
