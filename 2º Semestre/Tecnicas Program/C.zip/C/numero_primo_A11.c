#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 
  int n, y, s, linha;
  printf("digite um n�mero: ");
  scanf("%d",&n);
//in�cio do while
  y = n;
  s = 0;
  linha = 0;
  while (y >= 1){
	 printf("\n%d mod %d = %d",n,y,n % y);
	 linha = linha + 1;
	 if (linha == 23){
		printf("\n");
		system("pause");
		linha = 0;	 
	 }
	 if (n % y == 0){
       s = s + 1;
	 }
	 if ((s == 2) && (y >= 2)){
		 s = s + 1;
		 break;
	 }
	 y = y - 1;	  
  }
  if (s ==2){
	  printf("\n%d � primo",n);
  } 
  else{
	  printf("\n%d n�o � primo",n);
  }
//fim do while
/*
//------------------
//in�cio do FOR

//fim do FOR
//-----------------
//inicio do DO

//fim do DO
*/   
}   