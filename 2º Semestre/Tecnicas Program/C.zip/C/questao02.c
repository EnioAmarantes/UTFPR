/*
Quest�o 02 (5,0):
Escrever um algoritmo que receba a hora inicial (horas, minutos e segundos)
e a hora final (horas, minutos e segundos) da realiza��o de uma prova,
al�m do n�mero de quest�es corretas.
A partir dos dados de entrada o algoritmo deve calcular e mostrar a nota final
da prova, levando em considera��o os seguintes crit�rios:
a)O tempo ideal para a resolu��o da prova � de 1h02min30seg;
b)Para a resolu��o da prova no tempo ideal atribui-se 1 ponto para cada
  quest�o correta;
c)Para a resolu��o da prova acima do tempo ideal, retira-se 0.1 ponto de cada
  quest�o correta para cada 1min30seg acima do tempo, at� o limite de nota 0(zero);
  (considerar somente o tempo "cheio", e seus m�ltiplos, para o desconto da nota.
  Por exemplo: 1min29seg n�o desconta nenhuma nota; 3min12seg descontam 0.2 ponto);
d)Para a resolu��o da prova abaixo do tempo ideal, acrescenta-se 0.1 ponto a
  cada quest�o correta para cada 1min40seg abaixo do tempo, at� o limite de nota 10(dez);
  (considerar somente o tempo "cheio", e seus m�ltiplos, para o acr�scimo da nota.
  Por exemplo: 1min35seg n�o acrescenta nenhuma nota; 3min40seg acrescentam 0.2 ponto).
*/
main(){
  int questoes, h1, m1, s1, h2, m2, s2, tempo;
  float nota;

  printf("Informe a hora inicial da prova (hh): ");
  scanf("%d", &h1);
  printf("Informe os minutos da hora inicial da prova (mm): ");
  scanf("%d", &m1);
  printf("Informe os segundos dos minutos da hora inicial da prova (ss): ");
  scanf("%d", &s1);
  printf("Informe a hora final da prova (hh): ");
  scanf("%d", &h2);
  printf("Informe os minutos da hora final da prova (mm): ");
  scanf("%d", &m2);
  printf("Informe os segundos dos minutos da hora final da prova (ss): ");
  scanf("%d", &s2);
  printf("Informe a quantidade de quest�es corretas: ");
  scanf("%d", &questoes);

  tempo = (h2 * 3600 +  m2 * 60 + s2) - (h1 * 3600 +  m1 * 60 + s1);

  if (tempo  == 3750)
    nota = questoes * 1.0;

  if (tempo > 3750)
    nota = questoes * 1 - (((tempo - 3750) / 90) * 0.1 * questoes);

  if (tempo < 3750)
    nota = questoes * 1 + (((tempo - 3750) * -1 / 100) * 0.1 * questoes);

  if (nota > 10)
    nota <- 10;

  if (nota < 0)
    nota <- 0;

  printf("Nota final:  %.1f", nota);
}
