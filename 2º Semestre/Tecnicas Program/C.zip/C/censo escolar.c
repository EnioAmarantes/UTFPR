/*1� Quest�o (3,0): A Secretaria de Educa��o de um estado do sul do pa�s precisa realizar um censo escolar.
Para realizar este censo foram obtidos os seguintes dados de n estabelecimentos educacionais do estado:
a)	Tipo do estabelecimento (prim�rio/gin�sio, ensino m�dio, superior)
b)	Quantidade de salas de aula
c)	Quantidade de professores
d)	Quantidade de alunos
Seu programa deve:
a)	Relacionar os maiores e os menores estabelecimentos (com base no n�mero de alunos) por tipo
b)	Mostrar a quantidade de professores por tipo de estabelecimento
c)	Mostrar a quantidade de salas de aula existentes por tipo de estabelecimento
d)	Mostrar a rela��o aluno X sala de aula por tipo de estabelecimento
e)	Mostrar a rela��o professor X aluno por tipo de estabelecimento e geral
*/
#include <stdio.h>

main() {
  //tipo 1 = prim�rio/gin�sio 2 = ensino m�dio 3 = superior
  int op, tipo, qs, qp, qa,
     maT1=0, maT2=0, maT3=0, meT1=4000, meT2=4000, meT3=4000, qpT1=0, qpT2=0, qpT3=0, qsT1=0, qsT2=0, qsT3=0, qaT1=0, qaT2=0, qaT3=0;
  op = 1;
  while (op == 1){
    do{
      printf("Informe o tipo do estabelecimento: \n1 - fundamental\n2 - ensino medio\n3 - superior");
      scanf("%d",&tipo);
    }while ((tipo != 1) && (tipo != 2) && (tipo != 3));
    printf("\nInforme a quantidade de salas de aula: ");
    scanf("%d", &qs);
    printf("\nInforme a quantidade de professores: ");
    scanf("%d", &qp);
    printf("\nInforme a quantidade de alunos: ");
    scanf("%d", &qa);
    if (tipo == 1){
      qpT1 = qpT1 + qp;
      qsT1 = qsT1 + qs;
      qaT1 = qaT1 + qa;
      if (qa > maT1) maT1 = qa;
      if (qa < meT1) meT1 = qa;
    }
      else if (tipo == 2){
        qpT2 = qpT2 + qp;
        qsT2 = qsT2 + qs;
        qaT2 = qaT2 + qa;
        if (qa > maT2) maT2 = qa;
        if (qa < meT2) meT2 = qa;
      }
        else if (tipo == 3){
          qpT3 = qpT3 + qp;
          qsT3 = qsT3 + qs;
          qaT3 = qaT3 + qa;
          if (qa > maT3) maT3 = qa;
          if (qa < meT3) meT3 = qa;
        }
    printf("\nDeseja continuar?\n Digite 1 para sim ou 2 para nao\n");
    scanf("%d",&op);
  }
  printf("\nA maior escola de ensino fundamental possui %d alunos", maT1);
  printf("\nA maior escola de ensino medio possui %d alunos", maT2);
  printf("\nA maior escola de ensino superior possui %d alunos", maT3);
  printf("\nA menor escola de ensino fundamental possui %d alunos", meT1);
  printf("\nA menor escola de ensino medio possui %d alunos", meT2);
  printf("\nA menor escola de ensino superior possui %d alunos", meT3);
  printf("\nEscolas de ensino fundamental possuem %d professores", qpT1);
  printf("\nEscolas de ensino medio possuem %d professores", qpT2);
  printf("\nEscolas de ensino superior possuem %d professores", qpT3);
  printf("\nEscolas de ensino fundamental possuem %d salas de aula", qsT1);
  printf("\nEscolas de ensino medio possuem %d salas de aula", qsT2);
  printf("\nEscolas de ensino superior possuem %d salas de aula", qsT3);
  printf("\nA razao de aluno X sala de aula em escolas de ensino fundamental eh %d", qaT1/qsT1);
  printf("\nA razao de aluno X sala de aula em escolas de ensino medio eh %d", qaT2/qsT2);
  printf("\nA razao de aluno X sala de aula em escolas de ensino superior eh %d", qaT2/qsT2);
  printf("\nA razao de professor X aluno em escolas de ensino fundamental eh %d", qpT1/qaT1);
  printf("\nA razao de professor X aluno em escolas de ensino medio eh %d", qpT2/qaT2);
  printf("\nA razao de professor X aluno em escolas de ensino superior eh %d", qpT3/qaT3);
  printf("\nA razao de professor X aluno geral eh %d", (qpT1+qpT2+qpT3)/(qaT1+qaT2qaT3));
}

