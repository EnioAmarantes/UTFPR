#include <stdio.h>
main(){
  int dia, mes, ano;
  printf("Informe uma data no formato DD/MM/AAAA\n");
  scanf("%d/%d/%d",&dia,&mes,&ano);

  printf("%d %d %d", dia, mes, ano);


}
