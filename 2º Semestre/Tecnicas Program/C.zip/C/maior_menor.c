#include <stdio.h>
main(){
  int v[20], maior, menor, i;
  for(i = 0;i < 20; i++){
    printf("digite o %d valor para o vetor: ", i + 1);
    scanf("%d", &v[i]);
  }
  maior = v[0];
  menor = v[0];
  for(i = 0;i < 20; i++){
    if(maior < v[i])
      maior = v[i];
    if(menor > v[i])
      menor = v[i];
  }
  printf("\nmaior --> %d", maior);
  printf("\nmenor --> %d", menor);
  printf("\n\nvetor original\n");
  for(i = 0;i < 20; i++){
    printf("%d ", v[i]);
  }

  for(i = 1;i < 19; i++){
    if(v[i] % 2 == 0)
      v[i] = v[0];
      else
        v[i] = v[19];
  }

  printf("\n\nvetor modificado\n");
  for(i = 0;i < 20; i++){
    printf("%d ", v[i]);
  }


}
