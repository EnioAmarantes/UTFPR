//Tendo como dados de entrada dois pontos
//quaisquer de um plano cartesiano P(X1,Y1)e Q(X2,Y2)
//calcule e mostre a dist�ncia entre eles.
//A dist�ncia � dada pela f�rmula:
//raiz((X2 - X1)^2 + (Y2 - Y1)^2)
#include <stdio.h>
#include <math.h>
main(){
  float x1, y1, x2, y2, d;

  printf("Digite o valor de X1: ");
  scanf("%f",&x1);
  printf("Digite o valor de Y1: ");
  scanf("%f",&y1);
  printf("Digite o valor de X2: ");
  scanf("%f",&x2);
  printf("Digite o valor de Y2: ");
  scanf("%f",&y2);
  d = sqrt(pow(x2-x1,2.0)+pow(y2-y1,2.0));
  printf("A distancia e: %.2f", d);
}


















