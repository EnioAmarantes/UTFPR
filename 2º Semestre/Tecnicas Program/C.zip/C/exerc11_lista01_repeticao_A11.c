//11 - Obter um valor qualquer e perguntar ao usu�rio se este valor � em d�lares 
//ou em reais. Caso sejam d�lares, convert�-los para reais. Se forem reais, 
//convert�-los para d�lares. Repetir a opera��o at� que a soma dos valores 
//informados seja maior do que 10.000,00.
//Entradas: valor, tipo da moeda, cota��o do d�lar
//Sa�da: valor convertido
//Processamento: SE tipo for igual a D�LAR ent�o 
//                  valor convertido = valor * cota��o
//                  SEN�O
//                     valor convertido = valor / cota��o
//Executar o processamento enquanto a soma do VALOR for menor ou igual a 10.000
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float valor, cotacao, soma;
	int  tipo;
//valor - � o valor informado pelo usu�rio
//cotacao - � o valor da cota��o do d�lar para a convers�o
//soma - acumula todo o conte�do informado para a vari�vel valor, at�
//       o limite de 10.000
//tipo - recebe o tipo da moeda - 1 para D�LAR ou 2 para REAL
	soma = 0;
	while (soma <= 10000){
		printf("Informe o valor que ser� convertido: ");
		scanf("%f",&valor);
		soma = soma + valor;
		printf("Informe a cota��o do d�lar: ");
		scanf("%f",&cotacao);
		printf("O valor informado � em D�LARES(1) ou REAIS(2)? ");
		scanf("%d",&tipo);
		if (tipo == 1)
		 	printf("\nValor convertido para REAIS %f \n",valor * cotacao);
		    else
		       printf("\nValor convertido para D�LARES %f\n",valor / cotacao);
	}
    return 0;
}