#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	char r[4];
	printf("Responda sempre SIM ou NAO para as perguntas");
	printf("\nO animal e mamifero? ");
	fflush(stdin);
	gets(r); 
	if (strcmp(strupr(r),"SIM") == 0){
		printf("\nO animal e quadrupede? ");
	    fflush(stdin);
	    gets(r);
	    if (strcmp(strupr(r),"SIM") == 0){
			printf("\nO animal e carnivoro? ");
			fflush(stdin);
			gets(r);
			if (strcmp(strupr(r),"SIM") == 0)
				printf("\nO animal e um LEAO");
			    else
				   printf("\nO animal e um CAVALO");
		}
		else{
		  printf("\nO animal e bipede? ");
	      fflush(stdin);
	      gets(r);
	      if (strcmp(strupr(r),"SIM") == 0){
	      	 printf("\nO animal e onivoro? ");
	         fflush(stdin);
	         gets(r);
	         if (strcmp(strupr(r),"SIM") == 0)
	         	printf("\nO animal e um HOMEM");
	            else
	    	       printf("\nO animal e um macaco");
		  }
	      else{
			  printf("\nO animal e voador? ");
			  fflush(stdin);
			  gets(r);
			  if (strcmp(strupr(r),"SIM") == 0)
			  	 printf("\nO animal e um morcego");
			     else
			        printf("\nO animal e uma baleia");
  		  }	   
		}  
   	}
   	else{
   		printf("\nO animal e uma ave? ");
   		fflush(stdin);
   		gets(r);
   		if (strcmp(strupr(r),"SIM") == 0){
		   printf("\nO animal e nao-voador? ");
		   fflush(stdin);
		   gets(r);
		   if (strcmp(strupr(r),"SIM") == 0){
		   	  printf("\nO aninal e tropical? ");	   
		      fflush(stdin);
			  gets(r);
			  if (strcmp(strupr(r),"SIM") == 0)
			  	printf("\nO animal e um avestruz");
			    else
				   printf("\nO animal e um pinguim");
		   }
		   else{
			   printf("\nO animal e nadador? ");
			   fflush(stdin);
			   gets(r);
			   if (strcmp(strupr(r),"SIM") == 0)
			   	  printf("\nO animal e um pato");
                  else 
			         printf("\nO animal e uma aguia");
		   }	   
        }
        else{
			printf("\nO animal e reptil? ");
			fflush(stdin);
			gets(r);
			if (strcmp(strupr(r),"SIM") == 0){
				printf("\nPossui casco? ");
			    fflush(stdin);
			    gets(r);
			    if (strcmp(strupr(r),"SIM") == 0)
			    	printf("\nO animal e uma tartaruga");
			    else{
					printf("\nO animal e carnivoro? ");
					fflush(stdin);
					gets(r);
					if (strcmp(strupr(r),"SIM") == 0)
						printf("\nO animal e um crocodilo");
					    else
				           printf("\nO animal e um cobra");
               }
			}
		}
   }
   return 0;
}