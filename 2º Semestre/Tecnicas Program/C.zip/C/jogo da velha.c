#include <string.h>
#include <time.h>

main()

{

  int i, j;

  srand(time(NULL));

  //X --> decimal 88
  //0 --> decimal 48
  j = 1;
  while (j <= 100){
    i = rand()/100;
    if ((i == 88) || (i == 48)){
      printf("%c ", i);
      j++;
    }
  }
}
