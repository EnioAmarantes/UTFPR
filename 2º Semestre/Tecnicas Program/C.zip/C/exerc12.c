#include <stdio.h>
main(){
  int op;
  printf("\nInforme:");
  printf("\n1 para calcular a area de um triangulo");
  printf("\n2 para calcular a area de um circulo");
  printf("\n3 para calcular a area de um cubo");
  printf("\n4 para calcular a area de um cilindro\n");
  scanf("%d",&op);
  switch (op)
  {
   case 1:
       printf("triangulo");
       break;
  case 2:
       printf("circulo");
       break;
   case 3:
       printf("cubo");
       break;
   case 4:
       printf("cilindro");
       break;
   default:
       printf("voce deve selecionar uma das opcoes validas!");
  }
}
