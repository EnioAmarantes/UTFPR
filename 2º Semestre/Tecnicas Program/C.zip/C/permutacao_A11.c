/*
Quest�o 01:
Um n�mero A � dito permuta��o de um n�mero B se os d�gitos de A formam uma
permuta��o dos d�gitos de B.
Exemplo: 5412434 � uma permuta��o de 4321445, mas n�o � uma permuta��o de
 4312455.
*/
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int x, y, qx, qy, d, aux;
  printf("Verifica se X eh permutacao de Y\n");
  printf("Digite um valor inteiro para X: ");
  scanf("%d", &x);
  printf("Digite um valor inteiro para Y: ");
  scanf("%d", &y);
  if ((int)(log10(x)+1) == (int)(log10(y)+1)){
    for(d = 0;d <= 9;d = d + 1){
      qx = 0;   //linhas 21 a 27 - conta quantas vezes o d�gito d aparece na vari�vel x
      aux = x;
      while (aux > 0){
         if (aux % 10 == d)
           qx = qx + 1;
         aux = aux / 10;
      }
      qy = 0;   //linhas 28 a 34 - conta quantas vezes o d�gito d aparece na vari�vel y
      aux = y;
      while (aux > 0){
         if (aux % 10 == d)
           qy = qy + 1;
         aux = aux / 10;
      }
      if (qx != qy){
         printf("\n.Os n�meros n�o formam uma permuta��o\n");
         exit(1);
      }
    }
  }
  else{
    printf("\n..Os n�meros n�o formam uma permuta��o\n");
    exit(1);
  }
  printf("\n...Os n�meros formam uma permuta��o\n");
  return 0;
}
