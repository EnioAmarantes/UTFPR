/*
Escreva um programa em linguagem C chamado exercicio3.c que
contenha a declara��o de duas vari�veis do tipo int chamadas
a e b. Pe�a ent�o para a pessoa informar por meio do teclado
um valor para estas vari�veis. Se o valor de a for igual ao
valor de b exiba a seguinte mensagem �O valor da vari�vel a �
igual ao valor da vari�vel b.�; caso contr�rio exiba a mensagem
�O valor da vari�vel a n�o � igual ao valor da vari�vel b�.
*/
#include <stdio.h>
#include <locale.h>
 int main(){
   setlocale(LC_ALL,"Portuguese");
   int a, b;
   float r;

   printf("Digite dois n�meros inteiros separdos por espa�o: ");
   scanf("%d %d",&a,&b);

   printf("\nO primeiro n�mero � %d e o segundo � %d\n",a,b);

   printf("\na / b = %f\n",(float)a/b);

   r = a / b;

   printf("\nO valor de r � %f\n",r);

   return 0;
 }
