/*
DECIMAL PARA BIN�RIO:

Por exemplo, o n�mero 397:
397 div 2 = 198(resto 1)
198 div 2 = 99 (resto 0)
99 div 2 = 49 (resto 1)
49 div 2 = 24 (resto 1)
24 div 2 = 12 (resto 0)
12 div 2 = 6 (resto 0)
6 div 2 = 3 (resto 0)
3 div 2 = 1 (resto 1)
1 div 2 = 0 (resto 1)
*/
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int bin[100], num, i;
  printf("Digite um n�mero inteiro base 10: ");
  scanf("%d",&num);
  i = 0;
  while (num > 0){
    bin[i] = num % 2;
    num = num / 2;
    i = i + 1;
  }
  for(i = i - 1;i >= 0;i = i - 1){
    printf("%d",bin[i]);
  }
  return 0;
}
