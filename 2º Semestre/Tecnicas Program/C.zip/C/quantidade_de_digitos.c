#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int i;
  for(i = 1;i < 999999999;i = i * 10)
  {
     //printf("\nO n�mero %d digitado possui %f d�gitos",i,ceil(log10(i+1)));
     printf("\n\t(log10(%d)) = %f ",i,log10(i)+1);
  }
  return 0;
}
