#include <stdio.h>
main(){
  float s, x, y, fat, k;
  int f, qt, cont;
  s = 0;
  f = 0;
  printf("Informe a quantidade de termos para a serie: ");
  scanf("%d", &qt);
  printf("\nInforme o valor de X: ");
  scanf("%f", &x);
  printf("\nInforme o valor de Y: ");
  scanf("%f", &y);
  for(cont = 1;cont <= qt;cont++){
     if (f == 0){
        fat = x / y + cont + 1;
        for(k = fat - 1; k > 1; k--)
          fat = fat * k;
        s = s + (x + cont) / fat + s;
        f = 1;
     }
     else
       if (f == 1){
         fat = x * y + cont + 1;
         for(k = fat - 1; k > 1; k--)
           fat = fat * k;
         s = s + (x - cont) / fat - s;
         f = 2;
       }
       else
         if (f == 2){
           fat = x - y + cont + 1;
           for(k = fat - 1; k > 1; k--)
             fat = fat * k;
           s = s - (x + cont) / fat + s;
           f = 3;
         }
         else
           if (f == 3){
             fat = x + y + cont + 1;
             for(k = fat - 1; k > 1; k--)
               fat = fat * k;
             s = s + (x - cont) / fat + s;
             f = 0;
           }
  }
  printf("\nO valor da serie e %f",s);
}
