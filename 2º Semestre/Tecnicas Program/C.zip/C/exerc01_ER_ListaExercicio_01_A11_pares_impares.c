#include <stdio.h>
#include <locale.h>
#include <windows.h>
#include <stdlib.h>
#include <conio.h>

void gotoxy(int x, int y){
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x-1,y-1});
}
int main(){
  int n, lp, cp, li, ci;

  n = 0;
  lp = 2;
  cp = 1;
  li = 6;
  ci = 1;
  gotoxy(1,1);
  printf("PARES:");
  gotoxy(1,5);
  printf("IMPARES:");
  while (n <= 100)
  {
    Sleep(90);
    if (n % 2 == 0){
      gotoxy(cp,lp);
      printf("%d",n);
      cp = cp + 4;
      if (cp > 80){
         cp = 1;
         lp = lp + 1;
      }
    }
      else{
        gotoxy(ci,li);
        printf("%d",n);
        ci = ci + 4;
        if (ci > 80){
          ci = 1;
          li = li + 1;
        }
      }
    n = n + 1;
  }
  gotoxy(1,20);
  return 0;
}
