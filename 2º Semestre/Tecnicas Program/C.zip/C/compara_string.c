#include <stdio.h>
#include <string.h>

//0 (zero) � FALSO
//1 (um) � VERDADEIRO

//strupr(string) - retorna a string em MAI�SCULAS

main(){

  char OP[3];

  printf("digite SIM ou NAO: ");
  fflush(stdin);
  gets(OP);

//no exemplo abaixo a fun��o strcmp ir� comparar o valor em mai�sculas da vari�vel OP

  system("cls");

  if (strcmp(strupr(OP), "SIM")) //strcmp STRING COMPARE - retorna 0(zero) se str1 e str2 forem iguais
    printf("\n\nvoce digitou NAO\n\n");
    else
      if (strcmp(strupr(OP), "NAO"))
        printf("\n\nvoce digitou SIM\n\n");
        else
          printf("\n\nvoce deve digitar SIM ou NAO");

  printf("\n\nSIM --> %d", strcmp(OP, "SIM"));
  printf("\n\nNAO --> %d", strcmp(OP, "NAO"));

}
