/*
8. Escreva um programa que leia e mostre um vetor de 20 n�meros.
A seguir, conte quantos valores pares existem no vetor
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  srand(time(NULL));
  int n[20], i, pares;
//preenche o vetor com n�meros rand�micos
  for(i = 0;i < 20;i = i + 1)
    n[i] = rand()/1000;
//mostra o conte�do do vetor na tela
  printf("\n");
  for(i = 0;i < 20;i = i + 1)
    printf("%d ",n[i]);
  printf("\n");
//percorre o vetor e conta quantos n�meros pares h�
  for(i = 0, pares = 0;i < 20;i = i + 1){
    if (n[i] % 2 == 0)
      pares = pares + 1;
  }
//mostra quantos n�meros pares h� no vetor
  printf("\nH� %d n�meros pares no vetor\n",pares);
  return 0;
}
