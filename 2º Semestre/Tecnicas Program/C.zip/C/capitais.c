#include <stdio.h>
#include <conio.h>
#include <string.h>

main(){

  char capital[40];

  printf("digite o nome de uma capital: ");
  gets(capital);

  printf("\n\n%s", capital);

  printf("\n%s",strcmp(capital,"sao paulo"));

  if (strcmp("sao paulo","sao paulo"))
    printf("\nregi�o sudeste");
    else
      printf("\noutra regi�o");
}
