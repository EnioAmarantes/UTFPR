#include <stdio.h>
main(){
  float alt, r, p, ql, c;

  printf("Informe a alura do cilindro: ");
  scanf("%f", &alt);
  printf("Informe o raio do cilindro: ");
  scanf("%f", &r);
  printf("Informe o preco da lata de tinta: ");
  scanf("%f", &p);

  ql = (3.14*(r*r)*2 + 2*3.14*alt*r)/15;
  c = ql * p;

  printf("\nA quantidade de latas e %.2f", ql);
  printf("\nO custo e %.2f", c);
  }
