#include <stdio.h>
int main(){
  int a = 1, b = 12, c = 123, d = 1234, e = 12345;
  float m = 1.111, n = 12.111, o = 123.111, p = 1234.111, q = 12345.111;

  printf("\n%5d",a);
  printf("\n%5d",b);
  printf("\n%5d",c);
  printf("\n%5d",d);
  printf("\n%5d",e);

  printf("\n%10.2f",m);
  printf("\n%10.2f",n);
  printf("\n%10.2f",o);
  printf("\n%10.2f",p);
  printf("\n%10.2f",q);


  return 0;
}
