#include <stdio.h>
main()
{
  char re[]="Cornelio Procopio";
  char str[80], str1[50];
  int i;

  puts(re);
  puts(&re[5]);
  putchar('\n');

  printf("digite uma string: ");
  gets(str);
  //scanf("%s", &str); N�O L� ESPA�OS!!
  printf("1 --> %s\n\n",str);

  strcpy(str1,re); //strcpy (string_destino,string_origem);
  //str1 = re; ERRO!
  puts(str1);

  strcat(str1, str); //strcat (string_destino,string_origem);
  printf("\n2 --> %s\n\n",str1);

  printf("\n3 --> %s %d", str, strlen(str)); //strlen (string);

  //strcpy(str1,"jo�o");
  //strcpy(str,"joao");
//  str1 = "joao";
//  str = "joao";
  printf("\n%s",str1);
  printf("\n%s",str);
  printf("\n4 --> %d\n\n",strcmp(str1, str));  // strcmp (string1,string2);

  for(i = 0; i <= strlen(str) ; i = i + 2)
    printf("%c",str[i]);

  printf("\n\n");

  for(i = 2; i <= 3; i = i + 1)
    printf("%c",str[i]);
}
