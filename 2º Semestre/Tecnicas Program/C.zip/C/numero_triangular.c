/*
Quest�o 02:
Dizemos que um n�mero natural � triangular se ele � produto de tr�s n�meros naturais consecutivos.
Exemplo: 120 � triangular, pois 4 * 5 * 6 = 120.
1 - Escreva uma fun��o para preencher um vetor com dimens�o 20, de n�meros inteiros n�o negativos;
2 - Escreva uma fun��o que mostre se cada n�mero no vetor � triangular ou n�o.
*/
#include <stdio.h>
#define T 1000
preencheIntPositivo(int v[], int limite){
  int i, x;
  srand(time(NULL));
  i = 0;
  while(i < limite){
    x = rand();
    if (x % 2 == 0){
       v[i] = x;
       i++;
    }
  }
}
preencheIntSequencial(int v[], int limite){
  int i;
  for(i = 0;i < limite; i++)
     v[i] = i+1;;
}
verificaTriangular(int v[], int limite){
   int i, x;
   for(i = 0;i < limite; i++)
      for(x = 1;x*(x+1)*(x+2) <= v[i];x++)
         if (x*(x+1)*(x+2) == v[i])
           printf("%6d e' o produto %2d * %2d * %2d\n", v[i], x, x+1, x+2);
}
main(){
  int vetor[T];
  preencheIntPositivo(vetor, T);
  verificaTriangular(vetor,T);
  printf("\n------------------------------------\n");
  preencheIntSequencial(vetor, T);
  verificaTriangular(vetor,T);
}
