#include <stdio.h>
main(){
  int a1, m1, d1, a2, m2, d2, a3, m3, d3, dif;
  printf("\ndigite o ano da primeira data: ");
  scanf("%d", &a1);
  printf("\ndigite o m�s da primeira data: ");
  scanf("%d", &m1);
  printf("\ndigite o dia da primeira data: ");
  scanf("%d", &d1);
  printf("\ndigite o ano da primeira data: ");
  scanf("%d", &a2);
  printf("\ndigite o m�s da primeira data: ");
  scanf("%d", &m3);
  printf("\ndigite o dia da primeira data: ");
  scanf("%d", &d3);
  dif = (a2 * 365 + m2 * 30 + d2) - (a1 * 365 + m1 * 30 + d1);
  a3 = dif / 365;
  m3 = (dif % 365) / 30;
  d3 = (dif % 365) % 30;
  printf("%d anos, %d meses e %d dias", a3, m3, d3);
}
