#include <locale.h>
#include <stdio.h>
#include <time.h>
#define T 15
main(){
  float notas[T], soma, media, maiornota = -1, menornota = 11;
  int i, k, j, maiorj = 0, menorj = 0;
  setlocale(LC_ALL, "Portuguese");
  srand(time(NULL)); 
  for(i = 0, soma = 0, k = 1, j = 1, media = 0;i < T;i++){
//	  printf("Digite a %d� nota do %d� aluno: ",k, j);
//	  scanf("%f",&notas[i]);
      do{
        notas[i] = rand()/1000;
	  }while (notas[i] > 10);
      printf("\nA %d� nota do %d� aluno �: %.2f",k,j,notas[i]); 
//	  if (notas[i] > maiornota){
//		  maiornota = notas[i];
//		  maiorj = j;
//	  }
//	  if (notas[i] < menornota){
//		  menornota = notas[i];
//		  menorj = j;
//	  }
	  soma = soma + notas[i];
	  media = media + notas[i];
	  k = k + 1;
	  if (k == 5){
 	    i++;
	  	notas[i] = media/4;
		printf("\tA m�dia do %d� aluno � %.2f, i = %d",j,notas[i], i);
        printf("\n--------------------------------\n");
        k = 1;
	  	j = j + 1;
	  	media = 0;
	  }
  }
  printf("\nA m�dia da turma � %.2f\n",soma/T);
  
  for(i = 0;i < T;i++)
  	printf("%.2f ",notas[i]);
  
//  printf("\nA maior nota � %.2f do aluno %d",maiornota, maiorj);
//  printf("\nA menor nota � %.2f do aluno %d",menornota, menorj);
//  for(i = 0, j = 1, k = 1;i < T;i++){
//	 if (notas[i] == maiornota){
//	 	printf("\nO aluno %d obteve nota igual a maior nota",j);
//	 }
//	 k = k + 1;
//	 if (k == 5){
//		k = 1;
//		j++;
//	} 
//  }
//  for(i = 0, j = 1, k = 1;i < T;i++){
//	 if (notas[i] == menornota){
//	 	printf("\nO aluno %d obteve nota igual a menor nota",j);
//	 }
//	 k = k + 1;
//	 if (k == 5){
//		k = 1;
//		j++;
//	}
//  }
}  