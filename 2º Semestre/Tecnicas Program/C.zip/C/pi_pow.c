#include <stdio.h> 
#include <locale.h>
#include <stdlib.h>
#include <math.h>

int main(){	
	setlocale(LC_ALL,"Portuguese");
	float x1 = 2, y1 = 16, x2 = 1, y2 = 13, d;
	
    d =  pow(pow(x2-x1,2.0) + pow(y2-y1,2.0),0.5);
	
	printf("\ndist�ncia = %f",d);
	
	printf("\nPI = %f",M_PI);
}
	
    