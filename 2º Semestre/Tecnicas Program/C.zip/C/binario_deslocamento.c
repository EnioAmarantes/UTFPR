#include <stdio.h>
#include <stdlib.h>

int main() {
 int n, r, i;
 printf("Digite o numero: ");
 scanf("%d", &n);

 for(i = 31; i >= 0; i--) {
    r = n >> i;
    if(r & 1) {
        printf("1");
    } else {
        printf("0");
    }
 }
 printf("\n");
 system("pause");
}
