#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int dia, mes, ano, ds, f, g, delta, n;
  float fracao;
  printf("Informe uma data no formato dd/mm/aaaa : ");
  scanf("%d/%d/%d",&dia,&mes,&ano);
  if (mes <= 2)
  {
    g = ano - 1;
    f = mes + 13;
  }
    else
    {
      g = ano;
      f = mes + 1;
    }
  n = (int)(365.25 * g) + (int)(30.6 * f) - 621049 + dia;
  if (n < 36523)
    delta = 2;
    else
      if (n < 73048)
        delta = 1;
        else
          delta = 0;

  fracao = ((float)n/7) - (n / 7);
  ds = round(fracao*7) + delta + 1;
  switch (ds)
  {
     case 1:
       printf("\ndomingo\n");
       break;
     case 2:
       printf("\nsegunda\n");
       break;
     case 3:
       printf("\nter�a\n");
       break;
     case 4:
       printf("\nquarta\n");
       break;
     case 5:
       printf("\nquinta\n");
       break;
     case 6:
       printf("\nsexta\n");
       break;
     case 7:
       printf("\ns�bado\n");
       break;
     default:
       printf("\n????\n");
  }
  return 0;
}
