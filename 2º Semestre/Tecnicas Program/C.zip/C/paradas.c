#include <stdio.h>
main(){
  float kminicial, somacomb, kmp1, kmp2, comb;
  int op, p;

  printf("Informe a kilometragem inicial do veiculo: ");
  scanf("%f",&kminicial);
  kmp1 = kminicial;
  op = 1;
  p = 1;
  somacomb = 0;
  while (op == 1){
    printf("Informe a kilomatragem percorrida ate a %da parada: ",p);
    scanf("%f",&kmp2);
    printf("Informe a quantidade de combustivel abastecida na %da parada: ",p);
    scanf("%f",&comb);
    printf("\n\tA media km/lt na %da parada foi de: %2.2f",p,(kmp2-kmp1)/comb);
    somacomb = somacomb + comb;
    kmp1 = kmp2;
    p++;
    printf("\n\nHa outra parada cujos dados devem ser informados? 1 para SIM ou 2 para NAO ");
    scanf("%d",&op);
  }
  printf("\n\nA media da viagem foi de %2.2f km/lt\n\n",(kmp2 - kminicial) / somacomb);
}
