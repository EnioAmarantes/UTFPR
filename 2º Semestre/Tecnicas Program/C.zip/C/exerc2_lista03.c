//2.Elabore um algoritmo que calcule um n�mero inteiro que mais se aproxima da 
//raiz quadrada de um n�mero fornecido pelo usu�rio.
#include <stdio.h>
#include <math.h>
int main(){
	float n;
	
	printf("Digite um numero: ");
	scanf("%f",&n);
 
	printf("Raiz %f - numero inteiro %f",pow(n,0.5),round(pow(n,0.5)));
	
    if ((pow(n,0.5) - (int)pow(n,0.5)) < 0.5)
    	printf("\n%d",(int)pow(n,0.5));
        else
  	      printf("\n%d",((int)pow(n,0.5))+1);
  		 	
	return 0;
}