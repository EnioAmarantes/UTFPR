/*Um vendedor precisa de um programa que calcule o pre�o total devido por um cliente,
para uma compra realizada. Escreva um programa em C que receba o c�digo de um produto
e a quantidade comprada do mesmo, calcule e mostre o pre�o total. O programa deve ainda
mostrar uma mensagem no caso de c�digo inv�lido.
Utilize a tabela abaixo como refer�ncia.
 C�digo	Pre�o Unit�rio
 'ABCD'	5,30
 'XYPK'	6,00
 'KLMP'	3,20
*/
#include <stdio.h>
#include <string.h>
main(){
  char cod[4];
  int q;
  printf("Informe o codigo do produto conforme a tabela abaixo, e a quantidade: ");
  printf("\nC�digo	Pre�o Unit�rio");
  printf("\n'ABCD'	5,30");
  printf("\n'XYPK'	6,00");
  printf("\n'KLMP'	3,20");
  printf("\nC�digo --> ");
  gets(cod);
  printf("\nQuantidade --> ");
  scanf("%d", &q);
  if (strcmp("ABCD",strupr(cod))==0)
     printf("\nValor total %f", 5.3*q);
     else
       if (strcmp("XYPK",strupr(cod))==0)
         printf("\nValor total %f", 6.0*q);
         else
           if (strcmp("KLMP",strupr(cod))==0)
              printf("\nValor total %f", 3.2*q);
              else
                printf("\nC�digo de produto invalido");
}
