#include <stdio.h>
#include <time.h>
main(){
  int i;
  srand(5);
  for(i = 0; i <= 10; i++)
    printf("%d - ",rand()/1000+1);
}
