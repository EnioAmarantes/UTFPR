/*
4. Fa�a um programa que leia um vetor K[30]. Troque a seguir,
todos os elementos de ordem �mpar do vetor com os elementos de
ordem par imediatamente posteriores.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
#define T 20
int main(){
  setlocale(LC_ALL,"Portuguese");
  srand(time(NULL));
  int k[T], i, aux, POS;
//preenche o vetor com n�meros rand�micos
  for(i = 0;i < T;i = i + 1)
    k[i] = rand()/1000;
//mostra o vetor na tela
  printf("\n");
  for(i = 0;i < T;i = i + 1)
    printf("%d ",k[i]);
//percorre o vetor trocando os valores de ordem
//�mpar pelos de ordem par
  if (T % 2 == 0)
    POS = T - 2;
    else
      POS = T - 1;
  for(i = 1;i < POS;i = i + 2){
     aux = k[i];
     k[i] = k[i + 1];
     k[i + 1] = aux;
  }
//mostra o vetor na tela
  printf("\n");
  for(i = 0;i < T;i = i + 1)
    printf("%d ",k[i]);
  return 0;
}
