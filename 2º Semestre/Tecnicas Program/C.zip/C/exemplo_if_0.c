#include <stdio.h>

main() {
  int n;
  printf("Digite um numero inteiro ");
  scanf("%d", &n);

  if (n == 0)
    printf("zero");
    else
      if (n %2 == 0)
        printf("par");
        else
          printf("�mpar");

 getch();
}
