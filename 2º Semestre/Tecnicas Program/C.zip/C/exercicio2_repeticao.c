#include <stdio.h>

float media(float a, float b, float c, float d)
{
  return (a+b+c+d)/4;
}

main(){
  int c;
  float n1, n2, n3, n4, soma;
  soma = 0;
  c = 0;
  while (c < 2){
    printf("\ndigite a primeira nota: ");
    scanf("%f", &n1);
    printf("\ndigite a segunda nota: ");
    scanf("%f", &n2);
    printf("\ndigite a terceira nota: ");
    scanf("%f", &n3);
    printf("\ndigite a quarta nota: ");
    scanf("%f", &n4);

    soma = soma + media(n1, n2, n3, n4);

    c++;
  }
  printf("\n%f", soma/2);

}
