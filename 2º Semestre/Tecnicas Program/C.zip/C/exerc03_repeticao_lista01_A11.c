#include <stdio.h>
#include <stdlib.h>
int main(){
   float n1, n2, media, soma;
   int q, p1, p2;
   q = 1;
   soma = 0;
   while (q <= 3)
      {
         printf("\nInforme suas duas notas separadas por / \n");
         scanf("%f/%f",&n1,&n2);
         printf("\nInforme o peso das duas notas separadas por / \n");
         scanf("%d/%d",&p1,&p2);
         media = ((n1 * p1) + (n2 * p2)) / (p1 + p2);
         soma = soma + media;
         printf("\nA media do %d aluno e %2.1f",q,media);
         q = q + 1;
      }
   printf("\nA media da turma e %2.1f",soma/3);
  return 0;
}
