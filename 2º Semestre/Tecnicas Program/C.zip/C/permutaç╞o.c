/*
Quest�o 01:
Um n�mero A � dito permuta��o de um n�mero B se os d�gitos de A formam uma 
permuta��o dos d�gitos de B.
Exemplo: 5412434 � uma permuta��o de 4321445, mas n�o � uma permuta��o de
 4312455.
Obs.: Considere que o d�gito 0 (zero) n�o aparece nos n�meros.
1 � Fa�a uma fun��o que receba um inteiro N e um inteiro D (D sendo maior do 
que 0 e menor ou igual a 9)
e que devolve quantas vezes o d�gito D aparece em no n�mero N.
2 � Usando a fun��o do item anterior, fa�a um programa que l� dois inteiros 
positivos X e Y e que responda se X � permuta��o de Y.
*/
#include <stdio.h>

int prm(int n, int d){
  int c;
  c = 0;
  while (n > 0){
    if (n % 10 == d)
        c++;
    n = n / 10;
  }
  return c;
}

int main(){
  int x, y, a, R;
  printf("Verifica se X eh permutacao de Y\n");
  printf("Digite um valor inteiro para X (sem zeros): ");
  scanf("%d", &x);
  printf("Digite um valor inteiro para Y (sem zeros): ");
  scanf("%d", &y);
  R = 0;
  for(a = 1; a <= 9; a++){
    if ((prm(x,a)) != (prm(y,a))){
      R = 1;
      a = 10;
    }
  }
  if (R == 0)
    printf("%d eh permutacao de %d", x, y);
    else
      printf("%d nao eh permutacao de %d", x, y);
  return 0;
}
