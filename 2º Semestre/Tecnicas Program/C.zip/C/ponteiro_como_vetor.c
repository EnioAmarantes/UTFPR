#include <stdio.h>
#include <time.h>
#define T 10;


preenche(int *v, int l)
{
     int i;
     srand(time(NULL));
     for(i = 0; i <= T; i++)
       v[i] = rand()/100;
}
mostra(int *v, int T)
{
     int i;
     for(i = 0; i <= T; i++)
      printf("%d  ", v[i]);
}
main ()
{
	int m[T];
	preenche(&matrix, T);
	mostra(&matrix, T);
}
