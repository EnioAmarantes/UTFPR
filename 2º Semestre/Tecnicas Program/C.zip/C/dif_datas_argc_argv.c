#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <math.h> 
int main(int argc, char *argv[]){
  setlocale(LC_ALL, "Portuguese");	
  int i, a1, m1, d1, a2, m2, d2, a3, m3, d3, dif;
  if(argc == 7){
  	for(i = 0;i <= 7;i++)
  		printf("%s\n",argv[i]);
    d1 = atoi(argv[1]);
    m1 = atoi(argv[2]);
    a1 = atoi(argv[3]); 
    d2 = atoi(argv[4]);
    m2 = atoi(argv[5]);
    a2 = atoi(argv[6]);
    dif = (a2 * 365 + m2 * 30 + d2) - (a1 * 365 + m1 * 30 + d1);
    a3 = dif / 365;
    m3 = dif % 365 / 30;
    d3 = dif % 365 % 30;
    printf("\nA diferen�a entre %02d/%02d/%04d e %02d/%02d/%04d � de: ",d1,m1,a1,d2,m2,a2);    
    printf("%d anos %d meses %d dias",a3,m3,d3);    
  }
  else 
    printf("\nErro!\nN�mero de par�metros inv�lido!\n");
  return 0;
}