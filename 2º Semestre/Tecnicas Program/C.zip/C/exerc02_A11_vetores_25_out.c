//2. Fa�a um programa que leia um vetor N[20]. A seguir, encontre 
//o menor elemento do vetor N e a sua posi��o dentro do vetor, 
//mostrando: �O menor elemento de N �, M, �e sua posi��o dentro 
//do vetor �:�,P.
#include <locale.h>
#include <stdio.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n[20], menor, pos, i;
//preenche o vetor com valores informados pelo usu�rio  
  for(i = 0;i < 20;i = i + 1){
	  printf("Digite um valor para a posi��o %d do vetor: ",i);
	  scanf("%d",&n[i]);
  }
//mostra o conte�do do vetor na tela	
  printf("\n");
  for(i = 0;i < 20;i = i + 1){
	  printf("%4d",n[i]);
  }
//encontra o menor valor no vetor e sua posi��o
  menor = n[0];
  pos = 0;
  for(i = 1;i < 20;i = i + 1){
	  if (n[i] < menor){
		  menor = n[i];
		  pos = i;
	  }
  }
//mostra o resultado encontrado
  printf("O menor valor no vetor � %d na posi��o %d",menor,pos);  
	return 0;
}