#include <stdio.h>
#include <math.h>
int main(){
	float x, f, g, h, y;
	printf("Digite um valor para x: ");
	scanf("%f",&x);
	h = pow(x,2.0) - 16;
	if (h >= 0)
		f = h;
        else
        	f = 1;
    if (f == 0)
		g = pow(x,2.0) + 16;
	if (f > 0)
		g = 0;
	y = f + g;
	printf("\nX --> %4.2f\nH --> %4.2f\nF --> %4.2f\nG --> %4.2f\nY --> %4.2f",x,h,f,g,y);    
	return 0;
}