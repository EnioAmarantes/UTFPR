#include <stdio.h>

main(){
  int n, maior, menor;

  maior = -1;
  menor = 1000000;
  do{
    printf("Digite um numero: (ZERO para finalizar) ");
    scanf("%d",&n);
    if (n > 0){
      if (n < menor)
        menor = n;
      if (n > maior)
        maior = n;
    }
  }while (n != 0);
  printf("\nMaior numero %d",maior);
  printf("\nMenor numero %d",menor);
}
