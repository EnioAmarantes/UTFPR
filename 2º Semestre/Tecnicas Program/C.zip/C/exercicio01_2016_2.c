#include <stdio.h>
#include <locale.h>
#include <math.h>

int main(){
	float x = 5, y = 3;
	int a = 5, b = 3;
	
    setlocale(LC_ALL, "Portuguese");
	
	printf("\ninteiro %% inteiro - resto de %d por %d = %d",a,b,a % b);
	
	printf("\ninteiro / inteiro - quociente de %d por %d = %d",a,b,a / b);	
	
	printf("\ninteiro / float - divis�o real de %d por %f = %f",a,y,a / y);
	
	printf("\n(int)float / (int)float - resto de %f por %f = %d",x,y,(int)x % (int)y);	
	
	printf("\nfmod(x,y) - resto de %f por %f = %f",x,y,fmod(x,y));
			

	return 0;
}