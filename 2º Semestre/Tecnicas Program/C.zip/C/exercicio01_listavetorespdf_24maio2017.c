//1. Elaborar um programa que l� um conjunto de 30 valores e os coloca em 2 
//vetores conforme estes valores forem pares ou �mpares. O tamanho do vetor 
//� de 5 posi��es. Se algum vetor estiver cheio, escrev�-lo. Terminada a leitura 
//escrever o conte�do dos dois vetores. Cada vetor pode ser preenchido tantas 
//vezes quantas for necess�rio.

#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
    srand(time(NULL));
	int k[30], impar[5], par[5], i, ii, ip;
	
	for(i = 0;i < 30;i = i + 1)
		k[i] = rand()/1000+1;
	printf("\n");
	for(i = 0;i < 30;i = i + 1)
		printf("%3d",k[i]);
	printf("\n");
    ii = 0;
	ip = 0;	
	for(i = 0;i < 30;i = i + 1){
		if (k[i] % 2 == 0){
			par[ip] = k[i];
			ip = ip + 1;
			if (ip == 5){
				printf("\npares - ");
				for(ip = 0;ip < 5;ip = ip + 1)
					printf("%3d",par[ip]);
				ip = 0;
			}
		}
		else{
			impar[ii] = k[i];
			ii = ii + 1;
			if (ii == 5){
				printf("\n�mpares - ");
				for(ii = 0;ii < 5;ii = ii + 1)
					printf("%3d",impar[ii]);
				ii = 0;
			}
		}
	}
	
	printf("\npares - ");
    	for(i = 0;i < ip;i = i + 1)
			printf("%3d",par[i]);
		
	printf("\n�mpares - ");
    	for(i = 0;i < ii;i = i + 1)
			printf("%3d",impar[i]);
	
	
	
	return 0;
}