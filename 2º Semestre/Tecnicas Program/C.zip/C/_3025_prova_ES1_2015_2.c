/*
O n�mero 3025 possui a seguinte caracter�stica:
30 + 25 = 55
55^2 = 3025
Fazer um programa para imprimir todos os n�meros de quatro e de
seis d�gitos que apresentam tal caracter�stica.
*/
#include <stdio.h>
#include <math.h>
main(){
  int n, n1, n2, p;
  float N, N1, N2;
//------------------------------------
//1000 a 9999
//------------------------------------
  for(n = 1000; n <= 9999; n++){
    n1 = n / 100;
    n2 = n % 100;
    N1 = n1;
    N2 = n2;
    N = pow(N1+N2,2.0);
    if (N == n){
       printf("\n----------------------------");
       printf("%\n%02d + %02d = %02d --> %02d^2 = %4.f", n1, n2, n1+n2,n1+n2, N);
       printf("\n----------------------------");
    }
  }
//------------------------------------
//100000 a 999999
//------------------------------------
  for(n = 100000; n <= 999999; n++){
    n1 = n / 1000;
    n2 = n % 1000;
    N1 = n1;
    N2 = n2;
    N = pow(N1+N2,2.0);
    if (N == n){
       printf("\n----------------------------------");
       printf("%\n%03d + %03d = %03d --> %03d^2 = %6.f", n1, n2, n1+n2,n1+n2, N);
       printf("\n----------------------------------");
    }
  }
}
