#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){

  int I, J, Q[5][5];

  srand(time(NULL));

  for(I=0;I<5; I++) //linha
    for(J=0;J<5;J++){  //coluna
      Q[I][J] = rand()/1000;
    }

  printf("\nMatriz\n");
  for(I=0;I<5;I++){
    for(J=0;J<5;J++)
       printf("%3d",Q[I][J]);
    printf("\n");
  }
  return 0;
}
