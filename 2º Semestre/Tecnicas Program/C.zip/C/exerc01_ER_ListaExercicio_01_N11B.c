/*
Apresentar os n�meros inteiros pares entre 0 e 100.
*/
#include <stdio.h>
#include <locale.h>
#include <windows.h>
#include <stdlib.h>

void gotoxy(int x, int y){
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x-1,y-1});
}

int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, linha, coluna;
//-----------WHILE----------
  printf("-----------WHILE----------");
  linha = 3;
  coluna = 1;
  n = 2;
  while (n <= 100)
   {
     gotoxy(coluna, linha);
     printf("%4d", n);
     n = n + 2;
     linha = linha + 1;
     if (linha == 13)
     {
        linha = 3;
        coluna = coluna + 4;
     }
   }

//-----------DO...WHILE----------
  gotoxy(1,20);
  system("pause");
  system("cls");
  printf("-----------DO...WHILE----------");
  linha = 3;
  coluna = 1;
  n = 2;
  do
   {
     gotoxy(coluna,linha);
     printf("%4d", n);
     n = n + 2;
     linha = linha + 1;
     if (linha == 13)
     {
        linha = 3;
        coluna = coluna + 4;
     }
   }while (n <= 100);
//-----------FOR----------
  gotoxy(1,20);
  system("pause");
  system("cls");
  printf("-----------FOR----------");
  linha = 3;
  coluna = 1;
  n = 2;
  for(n = 2;n <= 100;n = n + 2)
  {
    gotoxy(coluna, linha);
    printf("%4d", n);
    linha = linha + 1;
    if (linha == 13)
    {
      linha = 3;
      coluna = coluna + 4;
    }
  }
  gotoxy(1,20);
  return 0;
}
