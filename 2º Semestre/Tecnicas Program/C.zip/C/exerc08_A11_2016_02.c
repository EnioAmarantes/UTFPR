//08 - Obter um n� qualquer e informar se este n� � par, �mpar, positivo ou negativo.
#include <stdio.h>
#include <locale.h>
int main(){
	int n;
	setlocale(LC_ALL,"Portuguese");
	printf("Digite um n�mero: ");
	scanf("%d",&n);
	
	if ((n % 2 == 0) && (n < 0)) 
	  printf("\nPAR e NEGATIVO\n");
	  else
		if ((n % 2 == 0) && (n >= 0))
		  printf("\nPAR e POSITIVO\n");
	        else 
			  if((n % 2 != 0) && (n < 0))
	            printf("\n�MPAR e NEGATIVO\n");
		     	  else
 		             printf("\n�MPAR e POSITIVO\n");
	
	return 0;
}

