/*
3. Escreva um programa que leia dois vetores de 10 posi��es e fa�a a
multiplica��o dos elementos de mesmo �ndice, colocando o resultado em um
terceiro vetor. Mostre o vetor resultante.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  srand(time(NULL));
  int a[10],b[10],c[10], i;
//preenche o vetor a com n�meros rand�micos
  for(i = 0;i < 10;i = i + 1)
    a[i] = rand()/1000;
//preenche o vetor b com n�meros rand�micos
  for(i = 0;i < 10;i = i + 1)
    b[i] = rand()/1000;
//mostra o conte�do do vetor a na tela
  printf("\nVetor A\n");
  for(i = 0;i < 10;i = i + 1)
    printf("%d ",a[i]);
  printf("\n");
//mostra o conte�do do vetor b na tela
  printf("\nVetor B\n");
  for(i = 0;i < 10;i = i + 1)
    printf("%d ",b[i]);
  printf("\n");
//percorre os vetores realizando a multiplica��o
  for(i = 0;i < 10;i = i + 1){
    c[i] = a[i] * b[i];
  }
//mostra o conte�do do vetor c na tela
  printf("\nVetor C\n");
  for(i = 0;i < 10;i = i + 1)
    printf("%d ",c[i]);
  printf("\n");
  return 0;
}
