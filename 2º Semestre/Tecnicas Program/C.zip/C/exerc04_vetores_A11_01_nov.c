//4. Fa�a um programa que leia um vetor K[30]. Troque a seguir, todos os elementos
//de ordem �mpar do vetor com os elementos de ordem par imediatamente posteriores.
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
#define T 16
int main(){
	setlocale(LC_ALL,"Portuguese");
	srand(time(NULL));
	int k[30], i, aux;
//preenche o vetor com 30 n�meros aleat�rios	
	for(i = 0;i < T;i++)
		k[i] = rand()/1000;
//mostra o vetor original	
	printf("\nVetor original\n");
	for(i = 0;i < T;i++)
		printf("%d ",k[i]);
//troca os valores de ordem �mpar pelos de ordem par imediatamente posteriores	
	for(i = 1;i < T - 2;i = i + 2){
		aux = k[i];
		k[i] = k[i+1];
		k[i+1] = aux;
	}
//mostra o vetor resultante	
	printf("\nVetor resultante\n");
	for(i = 0;i < T;i++)
		printf("%d ",k[i]);
	return 0;
}