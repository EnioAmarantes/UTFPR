//Escreva um algoritmo que calcule e escreva o valor de S para os n
//primeiros termos da s�rie:
//       1!    2!    3!    4!    5!            x!
//S = - --- + --- * --- / --- - --- + ...     ---
//       1!    3!    7!    15!   31!           y!
//
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	double s, x, y, fatx, fx, faty, fy;
	int qt, sinal;
	printf("Informe a quantidade de termos: ");
	scanf("%d",&qt);
	x = 1;
	y = 1;
	sinal = 1;
	while (qt >= 1){
	  	fatx = x;
	  	fx = x - 1;
	  	while (fx > 1){
			  fatx = fatx * fx;
			  fx = fx - 1;
		}
	  	faty = y;
	  	fy = y - 1;
	  	while (fy > 1){
			  faty = faty * fy;
			  fy = fy - 1;
		}
		switch (sinal){
			case 1:
				s = s - fatx/faty;
				sinal = 2;
				break;
			case 2:
				s = s + fatx/faty;
				sinal = 3;
				break;
			case 3:
				s = s * fatx/faty;
				sinal = 4;
				break;
			case 4:
				s = s / fatx/faty;
				sinal = 1;
				break;
		}
	    printf("\nS --> %e\tS --> %f",s,s);//mostra cada valor de s em nota��o cient�fica e float
		x = x + 1;
		y = y * 2 + 1;
		qt = qt - 1;	
   }
	printf("\nS --> %e\tS --> %f",s,s);//mostra o valor final de s em nota��o cient�fica e float
	return 0;
}
