#include <stdio.h>
int main(){
  int n;
  printf("Digite um numero inteiro: ");
  scanf("%d",&n);
  while (n > 0){
    printf("%d",n % 10);
    n = n / 10;
  }

  printf("\n\n");
  printf("Digite um numero inteiro: ");
  scanf("%d",&n);
  if ((n/100 + n%100) * (n/100 + n%100) == n)
    printf("ok");

  return 0;
}
//o n�mero 3025 possui a seguinte caracter�stica:
//   30 + 25 = 55
//   55^2 = 3025
//escreva um programa que receba um n�mero de quatro
//d�gitos do usu�rio e que mostre se ele possui a
//mesma caracter�stica do n�mero 3025
