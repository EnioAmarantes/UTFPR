#include <stdio.h>

main(){

int x;

printf("digite um numero ");
scanf("%d", &x);

if (x <5 )
    goto ENCERRA;
  else
    printf(" --> %d", x);


ENCERRA:
  printf("final");

}
