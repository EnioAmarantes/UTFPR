/*
mostrar todos os n�meros primos em um intervalo fechado de n1 a n2.
* n1 e n2 s�o fornecidos pelo usu�rio.
* o programa deve verificar se n1 e n2 s�o positivos e maiores do que 1;
  deve verificar se n1 � menor que n2; caso n1 e/ou n2 sejam menores do que 2,
  ou se n1 for menor ou igual a n2, o programa deve solicitar novamente
  a entrada de dados
*/
#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int n1, n2, soma, aux;
    printf("\nMostra todos os n�meros primos no intervalo fechado N1..N2");
    do{
		printf("\nInforme o valor de N1: ");
		scanf("%d",&n1);
	}while (n1 < 2);
    do{
		printf("\nInforme o valor de N2: ");
		scanf("%d",&n2);
	}while (n2 <= n1);	
	while (n1 <= n2){
		soma = 0;
		aux = n1;
		while ((aux >= 1) && (soma <= 2)){
			if (n1 % aux == 0)
				soma = soma + 1;
			aux = aux - 1;
		}
		if (soma == 2)
			printf("\nO n�mero %d � primo",n1);
		n1 = n1 + 1;
	}
	return 0;
}	
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 