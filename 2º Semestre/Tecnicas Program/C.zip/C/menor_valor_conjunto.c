/*1.	Construa um algoritmo que, dado um conjunto de valores inteiros e positivos, determine qual o menor valor do conjunto.
O final do conjunto de valores � conhecido atrav�s do valor zero, que n�o deve ser considerado.*/
main(){
  int menor = 0, n = 0;
  do{  //faz a leitura do primeiro valor do programa, somente para n�meros positivos. ZERO encerra o programa
    printf("\n.digite um n�mero inteiro e positivo (zero finaliza a digitacao): ");
    scanf("%d", &n);
    if ((n != 0) && (n > 0))
      menor = n;
  }while (n < 0);
  while (n != 0){ //faz a leitura dos demais valores do programa
    do{  //aceita somente n�meros positivos. ZERO encerra o programa
    printf("\n..digite um n�mero inteiro e positivo (zero finaliza a digitacao): ");
    scanf("%d", &n);
    if ((n != 0) && (n > 0) && (menor > n))
      menor = n;
    }while (n < 0);
  }
  if (n == 0)
    printf("\nVoce nao digitou nenhum numero valido para a serie.");
    else
      printf("\nO menor numero digitado foi %d", menor);
}
