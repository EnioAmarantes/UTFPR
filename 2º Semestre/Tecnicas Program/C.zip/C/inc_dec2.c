#include <stdio.h>

main(){

  for(;;)
    printf("oi ");
}
