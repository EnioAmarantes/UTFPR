#include <stdio.h>
#include <time.h>
#include <stdlib.h>
void preenche(int v[], int limite)
{
     int i;
	  srand(time(NULL));
     for(i = 0; i < limite; i++)
       v[i] = rand()/100;
}
void mostra(int *v, int limite)
{
     int i;
     for(i = 0; i < limite; i++)
       printf("%d  ", v[i]);
}
float fatorial(float a)
{
     float b;
     b = a - 1;
     while (b > 0) {
       a = a * b;
       b = b - 1;
     }
     return a;
}
void troca(int *a, int *b)
{
   int aux;
   aux = *a;
   *a = *b;
   *b = aux;
}
