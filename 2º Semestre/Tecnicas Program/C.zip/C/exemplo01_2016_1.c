#include <stdio.h>
#include <math.h>
#include <locale.h>
main(){
  float preco, ql, custo, raio, altura, area;

  setlocale(LC_ALL, "Portuguese");

  printf("Este programa calcula a quantidade de latas\n");
  printf("de tinta necess�rias para pintar um cilindro,\n");
  printf("al�m de seu custo.\n");
  printf("\nInforme a altura do cilindro: ");
  scanf("%f",&altura);
  printf("\nInforme o raio do cilindro: ");
  scanf("%f",&raio);
  printf("\nInforme o pre�o da lata de tinta: ");
  scanf("%f",&preco);
  area = 2 * M_PI * pow(raio,2.0) + 2 * M_PI * raio * altura;
  ql = area/15;
  custo = ql * preco;
  printf("\nSer�o necess�rias %2.2f latas de tinta", ql);
  printf("\nO custo ser� de R$%2.2f",custo);
}
