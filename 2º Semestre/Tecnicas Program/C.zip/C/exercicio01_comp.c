#include <stdio.h>
main(){
  float y, t, soma;
  int i;
  soma = 0;
  for(i = 1;i <= 15;i = i + 1){
    printf("Informe a altura para a %d medi��o: ", i);
    scanf("%f", &y);
    printf("Informe o tempo para a %d medi��o: ", i);
    scanf("%f", &t);
    soma = soma + 2 * y / (t*t);
  }
  printf("O melhor valor para g � %f", soma/15);
}
