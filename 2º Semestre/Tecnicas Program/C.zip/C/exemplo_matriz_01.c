#include <time.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
void gotoxy(int x, int y){
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x-1,y-1});
}
void main(){
  int I, J, col, lin;
  double QUADRADO[5][5], soma, somacol, somalin;

  srand(time(NULL));

  for(I=0;I<5; I++)
    for(J=0;J<5;J++){
      QUADRADO[I][J] = rand()/100;
    }

  for(I=0;I<5;I++){
    soma = 0;
    printf("Linha %d -> ",I);
    for(J=0;J<5;J++){
      printf("%4.0f",QUADRADO[I][J]);
      soma = soma + QUADRADO[I][J];
    }
    printf(" -> %5.0f\n", soma);
  }

  printf("\n\n");
  gotoxy(1,15);
  printf("Total -->");
  for(I = 0, col = 11;I < 5;I++, col = col + 8){
    somacol = 0;
    somalin = 0;
    gotoxy(8*I+11,7);
    printf("Col %d",I);
    for(J = 0, lin = 8;J < 5;J++,lin++){
      gotoxy(col, lin);
      printf("%5.0f",QUADRADO[J][I]);
      somacol = somacol + QUADRADO[J][I];
      somalin = somalin + QUADRADO[I][J];
    }
    gotoxy(8*I+11,lin+2);
    printf("%5.0f\n", somacol);
//    gotoxy(50,lin-1);
//    printf("%5.0f\n", somalin);
  }
}
