#include <stdio.h>
#include <math.h>

main(){

  double DENOMINADOR, PARCELA, PI, SINAL;

  DENOMINADOR = 1;
  PI = 0;
  SINAL =  1;
  PARCELA = 1;
  do {
    PI = PI + PARCELA * SINAL;
    DENOMINADOR = DENOMINADOR + 2.0;
    SINAL = SINAL * (-1);
    PARCELA = 4.0 / DENOMINADOR;
  }while (PARCELA > 0.0000001);

  printf("%f -- %f", PI,M_PI);
}
