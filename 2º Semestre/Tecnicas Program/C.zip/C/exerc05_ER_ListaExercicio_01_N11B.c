//5. Apresentar os n�meros entre 0 e 4, com intervalo de 0.25
//   entre eles, ou seja, 0, 0.25, 0.5, 0.75 ... 4.
#include <stdio.h>
int main(){
  float n;

//------WHILE------
  n = 0.25;
  while (n <= 4)
  {
    printf("%6.2f",n);
    n = n + 0.25;
  }

  printf("\n\n");
//------FOR------
  for(n = 0.25;n <= 4;n = n + 0.25)
  {
    printf("%6.2f",n);
  }

  printf("\n\n");
//------DO...WHILE------
  n = 0.25;
  do
  {
    printf("%6.2f",n);
    n = n + 0.25;
  }while (n <= 4);

  return 0;
}
