/*
5 - Fa�a um programa que receba dois n�meros reais e execute as opera��es listadas a seguir,
de acordo com a escolha do usu�rio.
ESCOLHA DO USU�RIO OPERA��O
1 M�dia entre os n�meros digitados.
2 Diferen�a do maior pelo menor.
3 Produto entre os n�meros digitados.
4 Divis�o do primeiro pelo segundo.
Se a op��o digitada for inv�lida, mostre uma mensagem de erro e termine a execu��o do
programa. Lembre-se de que, na opera��o 4, o segundo n�mero deve ser diferente de zero.
Use a estrutura switch..case para coordenar as escolhas do usu�rio.

entradas de dados: n�mero 1, n�mero 2, op��o do usu�rio
sa�das de dados: m�dia ou diferen�a ou produto ou divis�o ou mensagem de erro
processamento:
              obter dois n�meros
              obter a opera��o
              escolha a opera��o
                caso m�dia
                   mostrar o resultado da soma dos dois n�meros dividido por 2
                caso diferen�a
				   mostrar s subtra��o do primeiro pelo segundo n�mero
				caso produto
				   mostrar a multiplica��o do primeiro pelo segundo n�mero
				caso divis�o
				   se n�mero2 for igual a zero 
				      entao mostrar mensagem de erro "divis�o por zero"   
					  senao mostrar a divis�o do primeiro pelo segundo n�mero
			    caso contr�rio
				   mostrar mensagem "opera��o inv�lida"		      
*/
#include <stdio.h>
#include <locale.h>
int main(){
  float n1, n2;
  char op;
  setlocale(LC_ALL,"Portuguese");
  printf("\nEscolha uma das opera��es abaixo:\n");	
  printf("\n& M�dia entre os n�meros digitados.");
  printf("\n- Diferen�a do maior pelo menor.");
  printf("\n* Produto entre os n�meros digitados.");
  printf("\n/ Divis�o do primeiro pelo segundo.	");
  scanf("%c",&op);
  if (op == '&')
    {  
      printf("\nDigite dois n�meros separados por ENTER: ");
      scanf("%f%f",&n1,&n2);
      printf("\nA m�dia � %f",(n1 + n2) / 2);
    }
    else
      if (op == '-')
	  {
        printf("\nDigite dois n�meros separados por ENTER: ");
        scanf("%f%f",&n1,&n2);
     	printf("\nA diferen�a � %f",n1 - n2);
	  }
	  else
	  	if (op == '*')
		  {
            printf("\nDigite dois n�meros separados por ENTER: ");
            scanf("%f%f",&n1,&n2);
    	    printf("\nO produto � %f", n1 * n2);
		  }
		  else 
		  	if (op == '/')
			  {
                printf("\nDigite dois n�meros separados por ENTER: ");
                scanf("%f%f",&n1,&n2);
    	        if (n2 == 0)
    	          printf("\nERRO de divis�o por zero");
                  else
           	      printf("A divis�o � %f",n1 / n2);
			  }
			  else
    	        printf("\nOpera��o inv�lida");
  return 0;	
}
