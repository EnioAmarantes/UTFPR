#include <stdio.h>
#include <conio.h>

main() {
  int n, x;
  printf("Mostra na tela a tabuada de um n�mero informado pelo usu�rio\n");
  printf("Digite um n�mero inteiro: ");
  scanf("%d", &n);
  x = 1;

  do{
    printf("%d x %d = %d \n", n, x, (n*x));
    x = x + 1;}
  while (x <= 10);
  getch();
}


