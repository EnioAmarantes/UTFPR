#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 

  float n1, n2, media;
  char op;
  
  op = 's';
  
  while((op == 's') || (op == 'S')){
    printf("\ndigite a primeira nota: ");
    scanf("%f",&n1);
    printf("\ndigite a segunda nota: ");
    scanf("%f",&n2);
    media = (n1+n2)/2;
    printf("\nm�dia = %.2f",media);
    do{
      printf("\nDigite S para continuar ou N para encerrar: ");
      fflush(stdin);
      scanf("%c",&op);
	}while ((op != 's') && (op != 'n'));
  } 
}