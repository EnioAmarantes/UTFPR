/*
1 - Crie um programa que receba do usu�rio o n�mero (inteiro) de uma conta-corrente (por ex: 2319)
    e que informe seu d�gito verificador. Os passos s�o:
(a) Somar n�mero da conta com o seu n�mero invertido. Ex: Conta 2319, Invertido 9132.
   2319 + 9132 = 11451
(b) Multiplicar cada d�gito obtido do passo (a) pela sua ordem de posicionamento, e somar esses resultados.
   1  1  4  5  1
   5� 4� 3� 2� 1� (ordem da posi��o dos d�gitos)
   Ficaria algo assim: 5*1 + 4*1 + 3*4 + 2*5 + 1*1 = 32
(c) O �ltimo d�gito obtido do passo (b) � o d�gito verificador
Resultado: 32 , 2 � o d�gito verificador e a conta ficaria: 2319-2
*/
#include <stdio.h>'
#define T 5
main(){
    int n, i, m, x, x1, x2, p, p1, p2, numero, mult, contas[T] = {1543,23456,921,7639,6419};
//preenche o vetor com os valores iniciais
/*
    srand(time(NULL));
    for(i = 0; i <= T; i++)
      contas[i] = rand()/10;
*/
//calculo o digito verificador para cada valor do vetor
   for(i = 0;i < T; i++){
      printf("\nNumero digitado -----------------------------> : %d", contas[i]);
//calcula o tamamho de n
      n = contas[i];
      p = 0;
      while (n > 0){
        n = n / 10;
        p = p + 1;
      }
//inverte n para a vari�vel x
      n = contas[i];
      for(m = 1, x = p; x > 0; x--)
        m = m * 10;
      m = m / 10;
      x = 0;
      while (n > 0){
        x = x + ((n % 10) *  m);
        n = n / 10;
        m = m * 0.1;
      }
      printf("\nNumero invertido ----------------------------> : %d", x);
//calcula o tamanho de n + x
      n = contas[i] + x;
      p1 = 0;
      while (n > 0){
        n = n / 10;
        p1 = p1 + 1;
      }
      printf("\nQuantidade de digitos (numero + inv(numero) -> : %d | %d", contas[i]+x,p1);
//calcula os valores para obter o digito verificador
      x1 = contas[i]+x;
      x2 = 0;
      while( x1 != 0){
        x2 = x2 + (p1 * (x1 % 10));
        x1 = x1 / 10;
        p1 = p1 - 1;
      }

      printf("\nCalculo do digito verificador ---------------> : %d", x2);
      printf("\nDigito verificador --------------------------> : %d", x2 % 10);
      printf("\n%d - Conta com digito verificador ----------------> : %d-%d",i+1, contas[i], x2 % 10);
      printf("\n------------------------------------------------------------------\n");
    }
}
