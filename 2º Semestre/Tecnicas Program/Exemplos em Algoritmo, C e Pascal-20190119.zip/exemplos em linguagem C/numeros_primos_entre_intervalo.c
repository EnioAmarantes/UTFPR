#include <stdio.h>
#include <conio.h>

main() {
  int soma, x, n1, n2;
  printf("digite o primeiro n�mero do intervalo\n");
  scanf("%d", &n1);
  printf("digite o segundo n�mero do intervalo\n");
  scanf("%d", &n2);

  while (n1 <= n2) {
    x = n1;
    soma = 0;
    while (x >= 1){
      if (n1 % x == 0)
        soma = soma + 1;
      x = x - 1;
    }
    if (soma == 2)
      printf("o numero %d eh primo \n", n1);
      else
        printf("o numero %d nao eh primo \n", n1);
    n1 = n1 + 1;
  }
  getch();
}
