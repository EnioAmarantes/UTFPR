#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 

  int m, x;
  
  printf("Informe um n�mero inteiro?: ");
  scanf("%d",&m);
  for(;;);
	printf("...\n");
  

}