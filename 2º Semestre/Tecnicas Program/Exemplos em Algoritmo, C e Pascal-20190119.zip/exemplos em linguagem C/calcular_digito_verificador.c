/*
1 - Crie um programa que receba do usu�rio o n�mero (inteiro) de uma conta-corrente (por ex: 2319)
    e que informe seu d�gito verificador. Os passos s�o:
(a) Somar n�mero da conta com o seu n�mero invertido. Ex: Conta 2319, Invertido 9132.
   2319 + 9132 = 11451
(b) Multiplicar cada d�gito obtido do passo (a) pela sua ordem de posicionamento, e somar esses resultados.
   1  1  4  5  1
   5� 4� 3� 2� 1� (ordem da posi��o dos d�gitos)
   Ficaria algo assim: 5*1 + 4*1 + 3*4 + 2*5 + 1*1 = 32
(c) O �ltimo d�gito obtido do passo (b) � o d�gito verificador
Resultado: 32 , 2 � o d�gito verificador e a conta ficaria: 2319-2
*/
#include <stdio.h>
#define T 5
//retorna o tamanho de um n�mero
//� utilizada para o a invers�o de um n�mero e para o c�lculo do d�gito verificador
int tam(int n){
  int p = 0;
  while (n > 0){
    n = n / 10;
    p = p + 1;
  }
  return p;
}
//retorna o valor de n invertido
//utiliza o fun��o tam(int n), que retorna o tamanho de um  n�mero
int inv(int n){
  int x, m;
  for(m = 1, x = tam(n); x > 0; x--)
    m = m * 10;
  m = m / 10;
  x = 0;
  while (n > 0){
     x = x + ((n % 10) *  m);
     n = n / 10;
     m = m * 0.1;
  }
  return x;
}
//retorna o valor obtido pela multiplica��o do item (b) do exerc�cio:
//(b) Multiplicar cada d�gito obtido do passo (a) pela sua ordem de posicionamento, e somar esses resultados.
//   1  1  4  5  1
//   5� 4� 3� 2� 1� (ordem da posi��o dos d�gitos)
//   Ficaria algo assim: 5*1 + 4*1 + 3*4 + 2*5 + 1*1 = 32
//utiliza o fun��o inv(int n), que retorna um n�mero invertido
//n � a soma do n�mero da conta com o n�mero da conta invertido
//p � o tamanho da soma de n
int digito(int n, int p){
  int x;
  n = inv(n);
  x = 0;
  while( n != 0){
    x = x + (p * (n % 10));
    n = n / 10;
    p = p - 1;
  }
  return x;
}
//preenche o vetor com o n�meros de contas, aleatoriamente
preenche(int v[], int limite){
     int i;
     srand(time(NULL));
     for(i = 0; i <= limite; i++)
       v[i] = rand()/10;
}
main(){
    int i, numero, mult, contas[T] = {1543,23456,921,7639,6419};
//    preenche(contas, T);
//    printf("Digite o numero da conta, com quatro digitos: ");
//    scanf("%d", &numero);
    for(i = 0;i < T; i++){
//mostra o n�mero original da conta
      printf("\nNumero digitado -----------------------------> : %d", contas[i]);
//mostra o n�mero da conta invertido, retornado pela fun��o inv(int n)
      printf("\nNumero invertido ----------------------------> : %d", inv(contas[i]));
//mostra o n�mero da conta somado com o n�mero da conta invertido
//contas[i]+inv(contas[i])
//mostra o tamanho do n�mero da conta somado com o n�mero da conta invertido
//tam(conta[i]+inv(contas[i]))
      printf("\nQuantidade de digitos (numero + inv(numero) -> : %d | %d", contas[i]+inv(contas[i]),tam(contas[i]+inv(contas[i])));
//mostra o valor calculado para o d�gito verificar, conforme o item (b) do exerc�cio
//digito(contas[i]+inv(contas[i]), tam(contas[i]+inv(contas[i])))
      printf("\nCalculo do digito verificador ---------------> : %d", digito(contas[i]+inv(contas[i]), tam(contas[i]+inv(contas[i]))));
//mostra o �ltimo d�gito do valor calculado conforme o item (b) do exerc�cio, ao obter o resto da divis�o
//do retorno da fun��o digito(int n, int p) por 10
//digito(contas[i]+inv(contas[i]), tam(contas[i]+inv(contas[i]))) % 10
      printf("\nDigito verificador --------------------------> : %d", digito(contas[i]+inv(contas[i]), tam(contas[i]+inv(contas[i]))) % 10);
//mostra um �ndice, o n�mero da conta, e o d�gito verificador
      printf("\n%d - Conta com digito verificador ----------------> : %d-%d",i+1, contas[i],digito(contas[i]+inv(contas[i]), tam(contas[i]+inv(contas[i]))) % 10);
      printf("\n------------------------------------------------------------------\n");
    }
}
