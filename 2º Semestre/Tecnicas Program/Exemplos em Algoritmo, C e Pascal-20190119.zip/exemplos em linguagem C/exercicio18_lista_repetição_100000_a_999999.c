#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
main(){
  int n;
  float N, n1, n2;
  char num[6], valor[]="\0\0\0\0";
  for(n = 100000; n <= 990099; n++){
    itoa(n,num, 10);
    n1 = atof(strncpy(valor, &num[0], 3));
    n2 = atof(strncpy(valor, &num[3], 3));
    N = pow(n1+n2,2.0);
    if (N == n)
       printf("%d = %.0f\n", n, n1+n2);
  }
}
