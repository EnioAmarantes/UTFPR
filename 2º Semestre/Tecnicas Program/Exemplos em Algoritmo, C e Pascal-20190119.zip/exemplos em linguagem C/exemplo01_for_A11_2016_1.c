#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 

  int z, m, x;
  
  printf("Quantas tabuadas a partir do 1 voc� deseja?: ");
  scanf("%d",&m);
  for(z = 1;z <= m;z = z + 1){
    for(x = 1;x <= 10;x = x + 1);{
  	  printf("\n%2d * %2d = %2d",z,x,z*x);
   }
   printf("\n");
   system("pause");
   printf("\n");
  }
}


