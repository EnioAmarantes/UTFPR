#include <stdio.h>
#include <conio.h>

main() {
  int soma, x, n;
  printf("digite um numero inteiro\n");
  scanf("%d", &n);
  x = n;
  soma = 0;
  while (x >= 1){
    if (n % x == 0)
      soma = soma + 1;
    x = x - 1;
  }
  if (soma == 2)
    printf("o numero %d eh primo \n", n);
    else
      printf("o numero %d nao eh primo \n", n);
  getch();
}
