/*18.	O n�mero 3025 possui a seguinte caracter�stica:
30 + 25 = 55
55^2 = 3025
Fazer um algoritmo para um programa que pesquise e imprima todos os n�meros de quatro algorit�mos
que apresentam tal caracter�stica.
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
main(){
  int n;
  int N, n1, n2;
  float N1, N2;
  for(n = 3020; n <= 9999; n++){
    n1 = n / 100;
    n2 = n % 100;
    N1 = n1;
    N2 = n2;
    N = pow(N1+N2,2.0);
    if (N == n)
       printf("%d = %.0f\n", n, n1+n2);
  }
}
