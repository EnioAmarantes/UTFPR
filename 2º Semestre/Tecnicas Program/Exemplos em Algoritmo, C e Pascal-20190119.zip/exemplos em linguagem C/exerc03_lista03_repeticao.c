/*
A convers�o de graus Fahrenheit para cent�grados � obtida pela f�rmula C = 5/9(F-32).
Escreva um algoritmo que calcule e escreva uma tabela de graus cent�grados em fun��o de graus Fahrenheit
que variem de 50 a 150 de 1 em 1.
*/
#include <stdio.h>
main(){
  float F = 50;
  while(F <= 150){
    printf("+-----------------------+--------------------+\n");
    if (F < 100)
      printf("| Fahrenheit -> %3.2f   |  Celsius -> %3.2f  |\n",F, 5.0/9.0*(F-32));
      else
        printf("| Fahrenheit -> %2.2f  |  Celsius -> %2.2f  |\n",F, 5.0/9.0*(F-32));
    F++;
  }
  printf("+-----------------------+--------------------+\n");
}

