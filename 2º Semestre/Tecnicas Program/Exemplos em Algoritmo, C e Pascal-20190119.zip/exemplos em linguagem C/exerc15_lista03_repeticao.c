/*
15.	Fazer um algoritmo que calcule o valor de ex atrav�s da s�rie:

ex = x0 + x1/1! + x2/2! + x3/3! + ... sendo:

ex -> e elevado a x
x0 -> x elevado a zero...

de modo que o mesmo difira do valor calculado atrav�s da fun��o EXP de, no m�ximo, 0,0001.
0 valor de x deve ser lido de uma unidade de entrada. O algoritmo dever� escrever o valor de x,
o valor calculado atrav�s da s�rie, o valor dado pela fun��o EXP e o n�mero de termos utilizados da s�rie.
*/

#include <math.h>
#include <stdio.h>
main(){
  float e, x, c, fat, y;
  printf("digite um numero: ");
  scanf("%f", &x);
  e = 1;
  c = 1;
  do {
    fat = c;
    y = fat - 1;
    while (y >= 1){
      fat = fat * y;
      y = y - 1;
      }
    e = e + pow(x,c)/fat;
    c = c + 1;
  }while ( exp(x) - e > 0.0001);
  printf("\nfuncao exponencial da linguagem --> %f ", exp(x));
  printf("\nfuncao exponencial do programa ---> %f ", e);
}
