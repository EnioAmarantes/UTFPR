#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
main()
{
  setlocale(LC_ALL, "Portuguese"); 

  float joao, carlos, j, c;
  int tempo;
  printf("Jo�o � menor do que Carlos, mas cresce anualmente mais do que Carlos:");
  printf("\nQual a altura do Jo�o?: ");
  scanf("%f",&joao);
  printf("\nQual a altura do Carlos?: ");
  scanf("%f",&carlos);
  printf("\nQuantos cent�metros Jo�o cresce por ano?: ");
  scanf("%f",&j);
  printf("\nQuantos cent�metros Carlos cresce por ano?: ");
  scanf("%f",&c);
  tempo = 0;
  while(joao <= carlos){
     joao = joao + j;
     carlos = carlos + c;
     tempo = tempo + 1;
  }
  printf("\nJo�o %f",joao);
  printf("\nCarlos %f",carlos);
  printf("\nJo�o levar� %d anos para ultrapassar a altura de Carlos",tempo);
  
}


