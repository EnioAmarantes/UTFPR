#include <stdio.h>
#include <locale.h>
main(){
  setlocale(LC_ALL, "Portuguese");
  int n, i, num[100];
  printf("Digite um n�mero para convert�-lo para bin�rio: ");
  scanf("%d",&n);
  i = 0;
  while (n >= 1){
    num[i] = n % 2;
    n = n / 2;
    i = i + 1;
  }
  i = i -1;
  while (i >= 0){
    printf("%d",num[i]);
    i = i - 1;
  }
}
