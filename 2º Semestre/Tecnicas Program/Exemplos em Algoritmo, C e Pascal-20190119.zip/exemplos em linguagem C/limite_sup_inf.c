//algoritmo "semnome"
//Escreva um algoritmo que leia os limites inferior e superior de um intervalo,
//imprima todos os n�meros pares no intervalo aberto e tamb�m a soma destes n�meros.
//Por exemplo:
//Limite inferior: 3
//Limite superior: 12
//N�meros pares no intervalo aberto: 4 6 8 10
//Soma dos n�meros pares no intervalo aberto: 28
#include <stdio.h>
main(){
//var
  int li, ls, soma; //  li, ls, soma : inteiro
//inicio
  printf("Digite o valor do limite inferior: "); //escreva("digite o valor do limite inferior: ")
  scanf("%d",&li); //leia(li)
  printf("Digite o valor do limite superior: "); //escreva("digite o valor do limite superior: ")
  scanf("%d",&ls); //leia(ls)
  if (li % 2 == 0) //se (li % 2 = 0) entao
    li = li + 2; //li <- li + 2
    else //senao
      li = li + 1 ; //li <- li + 1
  //fimse
  if (ls % 2 == 0) //se (ls % 2 = 0) entao
    ls = ls - 2; //ls <- ls - 2
    else //senao
      ls = ls - 1; //ls <- ls - 1
  //fimse
  soma = 0;
  while (li <= ls){ //enquanto (li <= ls) faca
    soma = soma + li; //soma <- soma + li
    printf("%d ",li);//escreva(li," ")
    li = li + 2; //li <- li + 2
  }//fimenquanto
  //escreval
  printf("\nSoma %d",soma); //escreva("Soma : ", soma)
//fimalgoritmo
}
