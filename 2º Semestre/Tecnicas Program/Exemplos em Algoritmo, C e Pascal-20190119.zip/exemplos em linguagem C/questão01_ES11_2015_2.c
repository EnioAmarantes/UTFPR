//Escreva um algoritmo que leia os limites inferior e superior de um intervalo,
//imprima todos os n�meros pares no intervalo aberto e tamb�m a soma destes n�meros.
//Por exemplo:
//Limite inferior: 3
//Limite superior: 12
//N�meros pares no intervalo aberto: 4 6 8 10
//Soma dos n�meros pares no intervalo aberto: 28
#include <stdio.h>
main(){
  int p1, p2, soma;
  soma = 0;
  printf("Digite o primeiro numero do intervalo: ");
  scanf("%d",&p1);
  printf("Digite o segundo numero do intervalo: ");
  scanf("%d",&p2);
  if (p1 % 2 != 0) p1 = p1 + 1;
    else p1 = p1 + 2;
  if (p2 % 2 != 0) p2 = p2 - 1;
    else p2 = p2 - 2;
  for( ;p1 <= p2;p1 = p1 + 2){
     printf("%d ",p1);
     soma = soma + p1;
  }
  printf("\nsoma %d\n",soma);
}
