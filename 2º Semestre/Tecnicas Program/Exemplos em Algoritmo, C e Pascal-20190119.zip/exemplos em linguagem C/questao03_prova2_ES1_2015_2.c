//Capicua ou n�mero pal�ndromo � um n�mero (ou conjunto de n�meros) cujo reverso � ele pr�prio.
//O mesmo pode ser dito em rela��o a datas e as horas.
//Exemplos:
//	11
//	242
//	20002
//	1455665541
//	324567765423
//	123456789987654321
//	135792468864297531
//	123456789135792468864297531987654321
//Construa um programa que encontre todos os n�meros capicuas entre um intervalo num�rico (n1 e n2) fornecido pelo usu�rio
#include <stdio.h>
#include <locale.h>
main(){
  int n1, n2, tam, aux, inv, ok;
  setlocale(LC_ALL, "Portuguese");
  printf("Digite o primeiro valor do intervalo: ");
  scanf("%d",&n1);
  printf("Digite o segundo valor do intervalo: ");
  scanf("%d",&n2);
  for( ;n1 <= n2; n1++){ //la�o para percorrer o intervalo
//calcula o tamanho do valor atual de n1
    tam = 1;
    aux = n1;
    while(aux > 0){
        tam = tam * 10;
        aux = aux / 10;
    }
    tam = tam / 10;
//inverte o valor de n1 para inv
    aux = n1;
    inv = 0;
    while (aux > 0){
       inv = inv + ((aux % 10) *  tam);
       aux = aux / 10;
       tam = tam * 0.1;
      }
//verifica se o conte�do da vari�vel n1 � igual ao conte�do da vari�vel inv
    aux = n1;
    ok = 0;
    while (aux > 0){
      if ((aux % 10) != (inv % 10)){
        ok = 1;
        aux = -1;
      }
      aux = aux / 10;
      inv = inv / 10;
    }
    if (ok == 0)
      printf("\nO n�mero %d � pal�ndromo",n1);
  }//fim do la�o que percorre o intervalo
}
