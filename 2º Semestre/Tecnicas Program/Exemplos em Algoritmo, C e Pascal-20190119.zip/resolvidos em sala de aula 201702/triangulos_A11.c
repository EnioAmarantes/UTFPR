//Dados tr�s n�meros inteiros, verifique se eles podem ser lados de um tri�ngulo
//e, se puderem, classifique o tri�ngulo como equil�tero, is�scele ou escaleno.
//Para ser lados de um triangulo cada lado deve ser menor que a soma dos outros
//dois lados. Um tri�ngulo equil�tero possui os tr�s lados iguais; um tri�ngulo
//is�scele possui apenas dois lados iguais e em um tri�ngulo escaleno nenhum dos
//lados � igual.
//ENTRADAS DE DADOS:
//  a, b, c
//SA�DAS DE DADOS:
//  (1) os valores n�o podem compor um tri�ngulo   1 1 4
//  (2) � um tri�ngulo equil�tero                  2 2 2
//  (3) � um tri�ngulo is�sceles                   2 2 3
//  (4) � um tri�ngulo escaleno                    2 3 4
//PROCESSAMENTO:
//  se ((a >= (b + c)) ou (b >= (a + c)) ou (c >= a + b))
//    ent�o (1)
//    sen�o
//      se ((a = b) e (b = c))
//        ent�o (2)
//        sen�o
//          se (((a = b) e (b <> c)) ou ((a = c) e (c <> b)) ou ((b = c) e (c <> a)))
//            ent�o (3)
//            sen�o (4)
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  float a, b, c;
  printf("Verificar tipo de tri�ngulo a partir de tr�s valores: ");
  printf("Informe os valores dos tr�s lados do tri�ngulo separados por / \n");
  scanf("%f/%f/%f",&a,&b,&c);
  if ((a >= (b + c)) || (b >= (a + c)) || (c >= (a + b)))
    printf("\nos valores n�o podem compor um tri�ngulo");
    else
      if ((a == b) && (b == c))
        printf("\n� um tri�ngulo equil�tero");
        else
          if ((a != b) && (b != c) && (a != c))
            printf("\n� um tri�ngulo escaleno");
            else
              printf("\n� um tri�ngulo is�sceles");
   return 0;
}
