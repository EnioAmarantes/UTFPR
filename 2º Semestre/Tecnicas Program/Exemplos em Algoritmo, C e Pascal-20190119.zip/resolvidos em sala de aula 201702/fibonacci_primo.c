/*
Escrever um programa que gere os N primeiros termos da s�rie
de Fibonacci e, para cada termo da s�rie informar se o mesmo
� primo ou n�o
*/
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

void gotoxy(int x, int y){
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x-1,y-1});
}

int main(){
  setlocale(LC_ALL,"Portuguese");
  int x, soma, t1, t2, t3, c, qt, coluna, linha;
  printf("Quantos termos para a s�rie de Fibonacci? ");
  scanf("%d",&qt);
  printf("\n1   1   ");
  c = 2; // 1234567890
  t1 = 1;
  t2 = 1;
  coluna = 9;
  linha = 5;
  while (c < qt){
    t3 = t1 + t2;
    c = c + 1;
    gotoxy(coluna,3);
    coluna = coluna + 5;
    printf("%d ",t3);
    t1 = t2;
    t2 = t3;
//verifica se o termo atual � primo ou n�o
    x = t3;
    soma = 0;
    while (x >= 1){
      if (t3 % x == 0)
        soma = soma + 1;
      if (soma > 2)
        break;
      x = x - 1;
    }
    gotoxy(1,linha);
    if (soma == 2)
      printf("\n%4d � primo",t3);
      else
        printf("\n%4d n�o � primo",t3);
    linha = linha + 1;
//fim da verifica��o do termo atual
  }
  return 0;
}
