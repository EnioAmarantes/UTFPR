#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int copia, n, x;

  printf("Digite um n�mero para o c�lculo do fatorial: ");
  scanf("%d",&n);

  copia = n;
  x = copia - 1;
  while (x > 1){
    copia = copia * x;
    x = x  - 1;
  }
  printf("\n%d\n",copia);

  copia = n;
  x = copia - 1;
  do
  {
    copia = copia * x;
    x = x  - 1;
  }while (x > 1);
  printf("\n%d\n",copia);

  for(copia = n, x = copia - 1;x > 1;x = x - 1)
  {
    copia = copia * x;
  }
  printf("\n%d\n",copia);

  return 0;
}
