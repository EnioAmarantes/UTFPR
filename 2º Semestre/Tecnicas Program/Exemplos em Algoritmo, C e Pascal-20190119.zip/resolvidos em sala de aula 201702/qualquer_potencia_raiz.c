#include <math.h>
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int op;
  float x, y;
  printf("\nCalcula 'qualquer' raiz ou pot�ncia\n");
  printf("\n1 - pot�ncia\n2 - raiz\n");
  scanf("%d",&op);
  switch (op){
    case 1:
      printf("Digite o valor da base: ");
      scanf("%f",&x);
      printf("Digite o valor da expoente: ");
      scanf("%f",&y);
      printf("\n%f",pow(x,y));
      break;
    case 2:
      printf("Digite o valor do radicando: ");
      scanf("%f",&x);
      printf("Digite o valor da radical: ");
      scanf("%f",&y);
      printf("\n%f",pow(x,1/y));
      break;
    default:
      printf("\nOp��o inv�lida\n");
  }
  return 0;
}
