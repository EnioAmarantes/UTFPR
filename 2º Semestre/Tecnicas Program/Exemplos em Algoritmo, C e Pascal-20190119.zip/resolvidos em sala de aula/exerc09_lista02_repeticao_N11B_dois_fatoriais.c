//9.Fazer um algoritmo que calcule e escreva a soma dos
// 50 primeiros termos da s�rie:
//       1!    2!    3!    4!    5!       
//  S = --- - --- + --- - --- + --- - ... 
//       1!    3!    7!   15!   31!      
//
//Entradas: nenhuma
//Sa�da: valor de S
//Processamento: podemos considerar que S � a soma consecutiva
//               da divis�o de X por Y sendo que X come�a em 1 e � 
//               incrementado de 1 em 1. Deve-se calcular o FATORIAL
//               de X.
//               Os termos s�o alternados entre soma e subtra��o.
//               O valor de Y � sempre o valor anterior de Y * 2 + 1.
//               Deve-se calcular o fatorial de Y.
//               Este padr�o repete-se at� que seja atingido
//               o n�mero de 50 termos
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float s, x, y, fatx, fx, faty, fy;
	int count, sinal;
	s = 0;
	x = 1;
	y = 1;
	sinal = 1;
	count = 0;
	while (count < 50){
	  
	  fatx = x;	
	  fx = fatx - 1;
	  while (fx > 1){
		  fatx = fatx * fx;
		  fx = fx - 1;
	  }	
	  
	  faty = y;	
	  fy = faty - 1;
	  while (fy > 1){
		  faty = faty * fy;
		  fy = fy - 1;
	  }	
	  
	  s = s + fatx / faty * sinal;	
	  sinal = sinal * -1;
	  x = x + 1;
	  y = y * 2 + 1;
	  count = count + 1;
	}
    printf("\nS --> %f",s);	
  return 0;	
}