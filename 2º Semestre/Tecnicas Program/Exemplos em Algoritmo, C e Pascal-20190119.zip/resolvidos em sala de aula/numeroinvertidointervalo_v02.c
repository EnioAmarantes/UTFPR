/*
Mostrar na tela todos n�meros em um invervalo
fornecido pelo usu�rio, invertidos.
na tela.
Exemplo
20 - 45
20 - 02
21 - 12
...
45 - 54
*/
#include <stdio.h>
#include <unistd.h>
#include <time.h>
int main(){
	int n1, n2, aux;
	printf("Informe o valor inicial: ");
	scanf("%d",&n1);
	printf("Informe o valor final: ");
	scanf("%03d",&n2);
  while(n1 <= n2){
		aux = n1;
		printf("\n%d - ",n1);
		while(aux > 0){
			printf("%d",aux % 10);
			usleep(900000);
			aux = aux / 10;
		}
    n1 = n1 + 1;		
	}
	return 0;
}

