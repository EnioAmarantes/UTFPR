/*
O numero 3025 possui a seguinte caracter�stica:
3025
30 + 25 = 55
55^2 = 3025
Escreva um programa que encontre todos os n�meros com 4
d�gitos com a mesma caracter�stica

entrada de dados: n�o h�
sa�das de dados: n�meros com 4 d�gitos que possuem a
                 caracter�stica procurada
processamento: para cada n�mero no intervalor devemos
               obter os dois primeiros d�gitos atrav�s
               do quociente da divis�o inteira por 100
               e os dois �ltimos atrav�s do resto da divis�o
               inteira por 100. Caso a soma destes dois valores
               ao quadrado seja igual ao pr�prio n�mero, mostr�-lo
               na tela
*/
#include <stdio.h>
int main(){
	int i;

	for(i = 1000;i <= 9999;i = i + 1)
		if (((i / 100) + (i % 100)) * ((i / 100) + (i % 100)) == i)
			printf("\n%02d + %02d = %02d^2 = %02d",i/100,i%100,(i/100)+(i%100),i);		

  i = 1000;
  while(i <= 9999){
		if (((i / 100) + (i % 100)) * ((i / 100) + (i % 100)) == i)
			printf("\n%02d + %02d = %02d^2 = %02d",i/100,i%100,(i/100)+(i%100),i);		
    i = i + 1;
	} 

  i = 1000;
  do{
		if (((i / 100) + (i % 100)) * ((i / 100) + (i % 100)) == i)
			printf("\n%02d + %02d = %02d^2 = %02d",i/100,i%100,(i/100)+(i%100),i);		
    i = i + 1;
	}while(i <= 9999);

  return 0;		
}