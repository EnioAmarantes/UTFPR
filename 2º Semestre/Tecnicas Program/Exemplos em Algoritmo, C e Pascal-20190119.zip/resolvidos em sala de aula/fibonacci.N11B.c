#include <stdio.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int p, s, t, count, qt;
	p = 1;
	s = 1;
	count = 2;
	printf("Quantos termos? ");
	scanf("%d",&qt);
	printf("1  1");
	while (count < qt){
	   t = p + s;
	   p = s;
	   s = t;
	   printf("%3d",t);
	   count = count + 1;
	}
	return 0;
}
