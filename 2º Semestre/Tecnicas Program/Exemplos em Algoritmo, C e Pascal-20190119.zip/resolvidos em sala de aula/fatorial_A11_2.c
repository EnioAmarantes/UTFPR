//       n!    n+1!   n+2!   n+3!
//  S = ---- + ---- + ---- + ---- + ....
//       y!    y+1!   y+2!   y+3!
#include "C:\Users\gcanh\OneDrive\Documentos\_material_para_aulas\_algoritmos\C\lib\minhasbibliotecas.h"
int main(){
  int n, y, c;
  float s;
  printf("\nCalcula os 5 primeiros termos da s�rie:\n");
  printf("     n!    n+1!   n+2!   n+3!\n");
  printf("S = ---- + ---- + ---- + ---- + ....\n");
  printf("     y!    y+1!   y+2!   y+3!\n");
  printf("Digite o valor de n: ");
  scanf("%d",&n);
  printf("Digite o valor de y: ");
  scanf("%d",&y);
  c = 0;
  s = 0;
  while (c < 5){
    s = s + fatorial(n) / fatorial(y);
    n = n + 1;
    y = y + 1;
    c = c + 1;
  }
  printf("\nS --> %f",s);
  return 0;
}
