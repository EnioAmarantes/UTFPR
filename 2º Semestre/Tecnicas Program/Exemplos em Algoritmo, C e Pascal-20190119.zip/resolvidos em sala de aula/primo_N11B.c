#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, x, s;
  printf("\ndigite um n�mero inteiro: ");
  scanf("%d",&n);
  x = n;
  s = 0;
  while(x >= 1)
  {
     if (n % x == 0)
     {
        s = s + 1;
     }
     if (s > 2)
     {
        break;
     }
     x = x - 1;
  }
  if (s == 2)
  {
     printf("\nO n�mero %d � primo",n);
  }
  else
  {
     printf("\nO n�mero %d n�o � primo",n);
  }
  return 0;
}
