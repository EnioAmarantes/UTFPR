#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int t1, t2, t3, qt, c;
  t1 = 1;
  t2 = 1;
  printf("\nquantos termos para a s�rie de Fibonacci: ");
  scanf("%d",&qt);
  printf("%d %d",t1,t2);
  c = 2;
  while (c < qt){
    t3 = t1 + t2;
    t1 = t2;
    t2 = t3;
    printf(" %d",t3);
    c = c + 1;
  }
  return 0;
}

