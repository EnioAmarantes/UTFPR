#include "C:\Users\gcanh\OneDrive\Documentos\_material_para_aulas\_algoritmos\C\lib\minhasbibliotecas.h"
int main(){
  int n1, n2;
  printf("Digite os valores de n1 e de n2 separados por /: ");
  scanf("%d/%d",&n1,&n2);
  while(n1 <= n2){
     printf("\nO fatorial de %d --> %f",n1,fatorial(n1));
     n1 = n1 + 1;
  }
  return 0;
}
