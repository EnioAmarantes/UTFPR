#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n1, n2, x, soma;

  printf("Digite o primeiro valor do intervalo: ");
  scanf("%d",&n1);
  printf("Digite o segundo valor do intervalo: ");
  scanf("%d",&n2);
  while (n1 <= n2){
    x = n1;
    soma = 0;
    while (x >= 1){
      if (n1 % x == 0)
        soma = soma + 1;
      if (soma > 2)
        break;
      x = x - 1;
    }
    if (soma == 2)
      printf("\n%4d � primo",n1);
      else
        printf("\n%4d n�o � primo",n1);
    n1 = n1 + 1;
  }
  return 0;
}
