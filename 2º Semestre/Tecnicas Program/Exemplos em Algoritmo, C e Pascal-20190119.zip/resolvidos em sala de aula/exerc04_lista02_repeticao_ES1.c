//4.	Fazer um algoritmo que calcule e escreva a seguinte soma:
//       1!    2!    3!    4!    5!    6!        20!
//S = + --- - --- * --- / --- + --- - --- * ... 
//       1     4     9     16    25    36         
//
//Entradas: nenhuma
//Sa�da: valor de S
//Processamento: podemos considerar que S � a soma consecutiva
//               da divis�o do fatorial de X pelo quadrado de X, 
//               sendo que X come�a em 1 e � incrementado de 1 em 
//               1 at� 20.
//               O primeiro termo � uma soma, o segundo uma subtra��o,
//               o terceiro uma multiplica��o e o quarto uma divis�o.
//               Este padr�o repete-se at� o final da somat�ria.
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float x, s, fat, f;
	int sinal;	
	s = 0;
	sinal = 1;
	x = 1;
	while (x <= 20){
		fat = x;	
		f = fat -1;
		while (f > 1){
			fat = fat * f;
			f = f - 1;
		}	
		if (sinal == 1){
		  s = s + (fat / pow(x,2.0));
		  sinal = 2;
		}
		else
		  if (sinal == 2){
		    s = s - (fat / pow(x,2.0));
		    sinal = 3;
		  }
		  else
		    if (sinal == 3){
		      s = s * (fat / pow(x,2.0));
		      sinal = 4;  
		    }
		    else
			{
		      s = s / (fat / pow(x,2.0));
		      sinal = 1;  
			}
		x = x + 1;
	}
	printf("O valor de S � %f",s);		
	return 0;
}
