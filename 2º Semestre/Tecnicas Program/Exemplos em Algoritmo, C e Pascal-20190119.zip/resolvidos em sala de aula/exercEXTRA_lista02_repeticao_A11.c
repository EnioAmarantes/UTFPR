//4.	Fazer um algoritmo que calcule e escreva a seguinte soma,
//para n TERMOS:
//       1     2     3     4     5     6     7     
//  S = --- - --- * --- / --- + --- - --- * --- / ... 
//       1     4     9     16    25    36    49       
//
//Entradas: quantidade de termos
//Sa�da: valor de S
//Processamento: podemos considerar que S � a soma consecutiva
//               da divis�o de X pelo quadrado de X, sendo que X
//               come�a em 1 e �  incrementado de 1 em 1.
//               O primeiro termo � uma soma, o segundo � uma subtra��o
//               o terceiro � uma multiplica��o, e o quarto � uma
//               divis�o. Este padr�o repete-se at� que seja atingido
//               o n�mero de termos informado
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	float x, s;
	int sinal, qt, cont;
	s = 0;
	sinal = 1;
	x = 1;
	cont = 0;
	printf("Informe a quantidade de termos: ");
	scanf("%d",&qt);
	while (cont < qt){
		if (sinal == 1){
		  s = s + (x / pow(x,2.0));
		  sinal = 2;
		}
		  else{
		  	if (sinal == 2){
		      s = s - (x / pow(x,2.0));
		      sinal = 3;
			  }
			  else{
				  if (sinal == 3){
		            s = s * (x / pow(x,2.0));
		            sinal = 4;
				  }
				  else{
					 s = s / (x / pow(x,2.0));
		             sinal = 1;
				  }
			  }
		   }
		x = x + 1;
		cont = cont + 1;
	}
	printf("O valor de S � %f",s);		
	return 0;
}
