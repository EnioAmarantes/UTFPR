#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n1, n2, x, c;
  printf("digite o valor inicial do intervalo: ");
  scanf("%d",&n1);
  printf("digite o valor final do intervalo: ");
  scanf("%d",&n2);
  while (n1 <= n2){
    x = n1;
    c = 0;
    while (x >= 1){
      printf("\n n1(%d) mod x(%d) = %d",n1,x,n1 % x);
      if (n1 % x == 0){
        c = c + 1;
        if (c == 3){
          break;
        }
      }
      x = x - 1;
    }
    if (c == 2){
      printf("\nO n�mero %d � primo",n1);
    }
    else{
      printf("\nO n�mero %d n�o � primo",n1);
      }
    n1 = n1 + 1;
  }
  return 0;
}
