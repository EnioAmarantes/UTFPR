//obter um n�mero do usu�rio e mostr�-lo invertido:
//exemplo:
//1234 - 4321
//mostre na tela a soma o n�mero original com o n�mero invertido
//1234 + 4321 =
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int n, copia, aux, tam;
  printf("Digite um n�mero inteiro: ");
  scanf("%d",&n);
	tam = pow(10,(int)(log10(n)+1));
  aux = n;
  copia = 0;
  tam = tam / 10;
  while(aux > 0){
    copia = aux % 10 * tam + copia;
    aux = aux / 10;
    tam = tam / 10;
  }
  printf("\n%d + %d = %d",n,copia,n+copia);
  return 0;
}
