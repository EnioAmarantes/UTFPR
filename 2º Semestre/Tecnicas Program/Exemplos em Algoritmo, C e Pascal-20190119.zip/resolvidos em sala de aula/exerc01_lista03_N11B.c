//1.Construa um algoritmo que, dado um conjunto de valores 
//inteiros e positivos, determine qual o menor valor do conjunto.  
//O final do conjunto de valores � conhecido atrav�s do valor zero,
//que n�o deve ser considerado.
//Entrada de dados: v�rios valores inteiros e positivos, um a cada vez
//Sa�da de dados: o maior e o menor valor do conjunto
//Processamento: obter um valor, e se o mesmo for positivo, verificar
//               se � menor que o valor armazenado na vari�vel menor,
//               caso positivo atribuir este valor para a vari�vel menor.
//               Verificar se o valor lido � maior que o conte�do da
//               vari�vel maior, caso postivo, atribuir este valor
//               para a vari�vel maior.
//               Se o valor lido for igual a 0(zero), encerrar o programa
//               e mostrar o conte�do das vari�veis maior e menor.
#include <stdio.h>
#include <locale.h>
int main(){
  setlocale(LC_ALL,"Portuguese");
  int maior, menor, n;
  maior = -2;
  menor = 9999999;
  while (n != 0){
    do{  
      printf("Digite um n�mero: ");
      scanf("%d",&n);
    }while (n < 0);
	if ((n != 0) && (n > maior))
		maior = n;
	if ((n != 0) && (n < menor))
		menor = n;
  }
  if (maior != -2)
    printf("\nMaior -> %d",maior);
    else
      printf("\nN�o foram digitados valores v�lidos.");
  if (menor != 9999999)  
    printf("\nMenor -> %d",menor);
    else
      printf("\nN�o foram digitados valores v�lidos.");
  return 0;	
}  