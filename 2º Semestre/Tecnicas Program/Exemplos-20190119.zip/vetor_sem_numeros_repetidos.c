#include <stdio.h>
main(){
  srand(time(NULL));
  int v[20], x, i, j, n;
  for(i = 0; i <= 19; i++)
    v[i] = 0;
  i = 0;
  while (i <= 19){
    do{
      x = rand()/1000;
    }while ((x % 2 != 0) && (x < 6));
    printf("\nx --> %d\n",x);
    n = 0;
    for(j = 0; j < i; j++)
      if (v[j] == x){
        n = 1;
        j = i + 1;
      }
     if (n == 0) {
      v[i] = x;
      i++;
    }
  }
  for(i = 0; i <= 19; i++)
    printf("%d ",v[i]);
//  do{
//    x = rand()/1000;
//  }while (x > 19);

//  printf("\n\nO numero na posicao %d do vetor e %d ",x,v[x]);
}
