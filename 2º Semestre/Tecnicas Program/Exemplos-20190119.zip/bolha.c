#include <stdio.h>

main(){
   int vetor[15], i, j, x;
/* ******************************************************************************************************************
A fun��o rand tem uma mem�ria interna que armazena o n�mero, digamos r, produzido pela execu��o anterior da fun��o.
A cada nova execu��o, a fun��o rand usa r para calcular um novo n�mero "aleat�rio".
(O n�mero calculado passa a ser o novo valor de r.)
Onde tudo isso come�a?  O n�mero r que corresponde � primeira invoca��o de rand � conhecido como semente (= seed).
Dada a semente, a sequ�ncia de n�meros produzida por rand est� completamente determinada.
O programador pode especificar a semente por meio da fun��o srand, que tem um unsigned int como argumento e est� na
biblioteca stdlib. (Se o programador n�o especificar a semente, o sistema adota o valor 0.)
A seguinte fun��o usa o rel�go para especificar a semente:  srand(time(NULL));
em http://www.ime.usp.br/~pf/algoritmos/aulas/random.html - 23 de maio de 2011
****************************************************************************************************************** */
  srand(time(NULL));

  for(i=0;i<15;i++)
    vetor[i]=(rand()%50)+1; //rand() gerar� v�rios n�meros positivos como quero somente entre 1 e 1000 fa�o mod 1000,
                          //logo terei elementos entre 0 e 999 ent�o somo 1 sempre e terei elementos entre 1 e 1000

  printf("vetor nao ordenado \n");
  for(i=0;i<15;i++)
    printf("%.3d ",vetor[i]);

   for(i=0; i<14; i++){
     for(j=i+1; j<15; j++){
   	   if(vetor[i] > vetor[j]){
	     x = vetor[i];
	     vetor[i] = vetor[j];
	     vetor[j] = x;
	   }
     }
   }

  printf("\n\nvetor ordenado \n");
  for(i=0;i<15;i++)
    printf("%.3d ",vetor[i]);


}
