#include <stdio.h>
#include <string.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"Portuguese");
	int i;
	char valor[50];
	char inverso[50];
	char copia[] = "\0\0\0";
   
    for(i = 0;i < 50;i++){
    	valor[i] = '\0';
    	inverso[i] = '\0';
	}
			
    strcpy(valor,"11001111101100");
    
	if (strlen(valor) % 3 == 1){
		for(i = strlen(valor) + 1;i > 1;i--){
		  valor[i] = valor[i - 2];	
		}
		valor[1] = '0';
		valor[0] = '0';			
    }
    else{
	  if (strlen(valor) % 3 == 2){
		for(i = strlen(valor);i > 1;i--){
		  valor[i] = valor[i - 1];	
		}
		valor[0] = '0';			
      }
    }
	
	printf("\nbin�rio %s\n",valor);
	
	for(i = 0;i < strlen(valor);i = i + 3){
		strncpy(copia, &valor[i], 3);
	    if (strcmp(copia,"000") == 0) printf("%d",0);
	    if (strcmp(copia,"001") == 0) printf("%d",1);
	    if (strcmp(copia,"010") == 0) printf("%d",2);
	    if (strcmp(copia,"011") == 0) printf("%d",3);
	    if (strcmp(copia,"100") == 0) printf("%d",4);
	    if (strcmp(copia,"101") == 0) printf("%d",5);
	    if (strcmp(copia,"110") == 0) printf("%d",6);
        if (strcmp(copia,"111") == 0) printf("%d",7);			
	}
	return 0;
}