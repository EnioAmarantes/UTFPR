#include <stdio.h>
#include <time.h>
void preenche(int *v, int limite)
{
     int i;
     srand(time(NULL));
     for(i = 0; i <= limite; i++)
       v[i] = rand()/100;
}
void mostra(int *v, int limite)
{
     int i;
     for(i = 0; i <= limite; i++)
      printf("%d  ", v[i]);
}
main ()
{
	int matrix[10];
	preenche(matrix, 10);
	mostra(matrix, 10);
}
