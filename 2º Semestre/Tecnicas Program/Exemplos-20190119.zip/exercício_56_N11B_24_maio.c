/*56 - Fa�a um programa que l� uma matriz A 7 x 7 de n�meros e que possua 2
vetores ML(7) e MC(7), que contenham, respectivamente, o maior elemento de 
cada uma das linhas e o menor elemento de cada uma das colunas. 
Escrever a matriz A e os vetores ML e MC.*/
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
main(){	
  int a[7][7], ml[7],mc[7], i, j, maiorl, menorc;
  setlocale(LC_ALL, "Portuguese");
  srand(time(NULL));	
//preenche a matriz com valores randomicos  
  for(i = 0;i < 7;i++)   //linha
  	for(j = 0;j < 7;j++) //coluna
  		a[i][j] = rand()/100;
//mostra o conte�do da matriz na tela
  printf("\nMatriz a:\n");
  for(i = 0;i < 7;i++){  //linha
  	for(j = 0;j < 7;j++) //coluna
  		printf("%4d",a[i][j]);
  	printf("\n");
  }
//procura o maior valor de cada linha e o menor valor de cada coluna
  for(i = 0;i < 7;i++){       //in�cio do la�o que percorre cada linha
  	maiorl = a[i][0];         //inicializa com o primeiro valor de as linhas
    menorc = a[0][i];         //inicializa com o primeiro valor de as colunas  
	  for(j = 0;j < 7;j++){   //in�cio do la�o que percorre cada coluna
  		if (a[i][j] > maiorl) //verifica se o valor atual � maior do que o valor inicializado
  			maiorl = a[i][j]; //maiorl = a[linha][coluna]
        if (a[j][i] < menorc) //verifica se o valor atual � menor do que o valor inicializado
			menorc = a[j][i]; //menorl = a[coluna][linha]
	  }                       //fim do la�o que percorre as colunas
     ml[i] = maiorl; //atribui maiorl para o vetor ml, indexado pelo valor de i, que varia de 0 a 6
     mc[i] = menorc; //atribui menorc para o vetor mc, indexado pelo valor de i, que varia de 0 a 6
  }                  //fim do la�o que percorre as linhas
  printf("\nMaiores de cada linha : ");  
  for(i = 0;i < 7;i++)
  	printf("%4d",ml[i]);
  printf("\nMenores de cada coluna: ");
  for(i = 0;i < 7;i++)
  	printf("%4d",mc[i]);
  printf("\n");
}