#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T 10
#define Li 40
#define Ls 80
main(){
  float n[T];
  int i, aux;

  srand(time(NULL));
  	 
  for(i = 0;i < T;i++)
  	n[i] = 0;

  for(i = 0;i < T;i++){
  	do{
      aux = rand()/100;
    }while ((aux % 2 != 0) || (aux < Li) || (aux > Ls));
    n[i] = aux;   
  } 
   
  for(i = 0;i < T;i++)
  	printf("%.2f ",n[i]);
} 