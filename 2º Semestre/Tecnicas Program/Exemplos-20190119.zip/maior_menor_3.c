//algoritmo "semnome"
//Quest�o 01:
//Obter valores para um vetor de inteiros com dimens�o 20 e ent�o
//determinar qual o menor e qual o maior valor do conjunto.
//O vetor n�o est� e n�o dever� ser ordenado.
//var
#include <stdio.h>
main(){
  int maior, menor, i;//maior, menor, i : inteiro
  int v[20]; //v : vetor[1..20] de inteiro
//inicio
  for(i = 0;i <= 19; i = i + 1){ //para i de 1 ate 20 faca
    printf("Digite o  valor par a %d posicao do vetor: ",i);//escreva("Digite o valor para a ",i,"� posi��o do vetor: ")
    scanf("%d",&v[i]); //leia(v[i])
  }//fimpara
  maior = v[0]; //maior <- v[1]
  menor = v[0]; //menor <- v[1]
  for(i = 1;i <= 19;i = i + 1){//para i de 2 ate 20 faca
    if (v[i] > maior) //se (v[i] > maior) entao
      maior = v[i];//maior <- v[i]
    //fimse
    if (v[i] < menor) //se (v[i] < menor) entao
      menor = v[i]; //menor <- v[i]
    //fimse
  }//fimpara
  //escreval
  printf("\nmaior: %d", maior); //escreval("maior : ",maior)
  printf("\nmenor: %d", menor); //escreval("menor : ",menor)
}//fimalgoritmo
