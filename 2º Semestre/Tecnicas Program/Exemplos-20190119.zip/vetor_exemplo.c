/****************************
* 16 de julho de 2003
* Prof. Gabriel Canhadas Genvigir
* Este programa tem a finalidade de demonstrar a declaracao e manipulacao
* simples de um vetor de inteiros de 10 posicoes.
* As seguintes operacoes sao realizadas com o vetor:
* ==> Leitura dos valores para o vetor atraves do teclado
* ==> Escrita dos valores do vetor (sem e com ordenacao)
* ==> Ordenacao dos valores do vetor atraves do Metodo da Bolha
*****************************/
#include <stdio.h>
#include <stdlib.h>
void main(){
/****************************
* vetor[10] --> vetor com 10 elementos inteiros (posicoes de 0 a 9)
* i, j --> variaveis de controle para leitura, escrita e ordenacao do vetor
* aux --> variavel auxiliar para ordenacao do vetor
*****************************/
  int vetor[10], i, j, aux;
  system("cls");
  srand(time(NULL));
/****************************
* leitura do vetor
* entrada de dados atraves do teclado
****************************/
  for(i=0;i<10;i++){
    //printf("\nDigite o valor para a posicao %d do vetor --> ",i);
    //scanf("%d",&vetor[i]);
    vetor[i] = rand();
  }  //fim do for para leitura do vetor
/****************************
* escrita do vetor na mesma ordem em que foi lido
*****************************/
  printf("\n\nVetor original ==> | ");
  for(i=0;i<10;i++)
    printf("%d | ",vetor[i]);
/****************************
* ordenacao do vetor atraves do Metodo da Bolha
*****************************/
  for(i=0;i<10;i++){
    for(j=0;j<10;j++){
      if (vetor[j] > vetor[j+1]){
	    aux=vetor[j];
	    vetor[j]=vetor[j+1];
	    vetor[j+1]=aux;
      } // fim do if
    } //fim do for interno
  } //fim do for externo
/****************************
* escrita do vetor ordenado
*****************************/
  printf("\n\nVetor ordenado ==> | ");
  for(i=0;i<10;i++)
    printf("%d | ",vetor[i]);
  getch(); //aguarda a leitura de qualquer tecla
}
