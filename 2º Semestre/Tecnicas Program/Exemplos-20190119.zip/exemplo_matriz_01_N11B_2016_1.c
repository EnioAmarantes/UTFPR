#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T 3
main(){
	
  float notas[T][5], soma, media; 
  int lin, col, k, j;
  
  setlocale(LC_ALL, "Portuguese");
  
  srand(time(NULL)); 

  for(lin = 0, j = 1, media = 0;lin < T;lin++,j++){
  	for(col = 0,k = 1, soma = 0;col < 4;col++,k++){
      do{
        notas[lin][col] = rand()/1000;
	  }while (notas[lin][col] > 10);
      printf("\nA %d� nota do %d� aluno �: %.2f",k,j,notas[lin][col]); 
	  soma = soma + notas[lin][col];
    }
    notas[lin][col] = soma / 4;
	media = media + notas[lin][col];
	printf("\tA m�dia do %d� aluno � %.2f",j,notas[lin][col]);
    printf("\n--------------------------------\n");
  }

  printf("\nA m�dia da turma � %.2f\n",media/T);  
  
  printf("\n");
  
  for(lin = 0;lin < T;lin ++){
	  for(col = 0;col < 5;col++)
	  	printf("%5.2f ",notas[lin][col]);
	  printf("\n");
  }
  
} 