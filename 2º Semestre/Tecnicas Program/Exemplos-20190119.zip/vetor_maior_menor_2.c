/*
Quest�o 01: Obter valores para um vetor de inteiros com dimens�o 20 e
ent�o determinar qual o menor e qual o maior valor do conjunto.
O vetor n�o est� e n�o dever� ser ordenado.
*/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#define T 20
uint32_t stampstart();
uint32_t stampstop(uint32_t start);
void preencher(int[], int);
void imprimir(int[], int);
int maior(int[], int);
int menor(int[], int);
int main(){
  int vetor[T];
  uint32_t start, stop;
  start = stampstart();
  preencher(vetor,T);
  imprimir(vetor, T);
  printf("\nO maior valor no vetor e --> %d\n", maior(vetor,T));
  printf("\nO menor valor no vetor e --> %d\n", menor(vetor,T));
  stop = stampstop(start);
  return 0;
}
void preencher(int v[], int t){
 int i = 0, x, j, n;
 srand(time(NULL));
 while (i <= t){
    x = rand()/1000;
    n = 0;
    for(j = 0; j < i; j++)
      if (v[j] == x)
        n = 1;
    if (n == 0) {
      v[i] = x;
      i++;
    }
  }
}
void imprimir(int v[], int t){
  int i;
  for(i = 0; i <= t;i++)
    printf("%d ",v[i]);
}
int maior(int v[], int t){
  int m, i;
  m = v[0];
  for(i = 1;i <= t;i++)
    if (m < v[i])
       m = v[i];
  return m;
}
int menor(int v[], int t){
  int m, i;
  m = v[0];
  for(i = 1;i <= t;i++)
    if (m > v[i])
       m = v[i];
  return m;
}
uint32_t stampstart(){
	struct timeval  tv;
	struct timezone tz;
	struct tm      *tm;
	uint32_t         start;
	gettimeofday(&tv, &tz);
	tm = localtime(&tv.tv_sec);
	printf("\nTIMESTAMP-START\t  %d:%02d:%02d:%d (~%d ms)\n", tm->tm_hour,
	       tm->tm_min, tm->tm_sec, tv.tv_usec,
	       tm->tm_hour * 3600 * 1000 + tm->tm_min * 60 * 1000 +
	       tm->tm_sec * 1000 + tv.tv_usec / 1000);
	start = tm->tm_hour * 3600 * 1000 + tm->tm_min * 60 * 1000 + tm->tm_sec * 1000 + tv.tv_usec / 1000;
	return (start);
}
uint32_t stampstop(uint32_t start){
	struct timeval  tv;
	struct timezone tz;
	struct tm      *tm;
	uint32_t         stop;
	gettimeofday(&tv, &tz);
	tm = localtime(&tv.tv_sec);
	stop = tm->tm_hour * 3600 * 1000 + tm->tm_min * 60 * 1000 + tm->tm_sec * 1000 + tv.tv_usec / 1000;
	printf("\nTIMESTAMP-END\t  %d:%02d:%02d:%d (~%d ms) \n", tm->tm_hour,
	       tm->tm_min, tm->tm_sec, tv.tv_usec,
	       tm->tm_hour * 3600 * 1000 + tm->tm_min * 60 * 1000 +
	       tm->tm_sec * 1000 + tv.tv_usec / 1000);
	printf("ELAPSED\t  %d ms\n", stop - start);
	return (stop);
}
