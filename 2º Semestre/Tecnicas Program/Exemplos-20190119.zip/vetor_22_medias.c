#include <stdio.h>

main(){
  float notas[88], media, aux;
  int i, c, x, y;

  srand(time(NULL));
/*gera as 88 notas aleat�rias, entre 50 e 100
  for(i = 0;i < 88; i++){
    do{
      aux = rand()/100;
    }while ((aux < 50) || (aux > 100));
    notas[i] = aux;
  }
*/
  x = 1; y = 1;
  for(i = 0; i < 88;i ++){
    printf("Digite a %d nota do %d aluno: ", x, y);
    scanf("%f", &notas[i]);
    x++;
    if (x > 4){
        y++;
        x = 1;
    }
  }

  c = 0;
  media = 0;
  for(i = 0;i < 88; i++){
    printf("%2.2f - ", notas[i]);
    media = media + notas[i];
    c++;
    if (c == 4){
      printf("  media --> %2.2f\n", media/4);
      c = 0;
      media = 0;
    }
  }
}
