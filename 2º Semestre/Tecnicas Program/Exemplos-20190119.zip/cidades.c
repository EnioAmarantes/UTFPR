#include <stdio.h>
main(){
  int m[5][5] = {{0,15,396,90,15},{15,0,411,75,30},{396,411,0,486,411},{90,75,486,0,105},{15,30,411,105,0}};
  int iti[15] = {0,4,3,2,1,0,3,2,4,1,0,2,1,4,1};
  char cid[5][10]={"Londrina", "Cambe","Curitiba","Maringa","Ibipora"};
  int j, i, s, s2, soma;
/*
Fa�a um algoritmo que receba o itiner�rio de uma viagem entre estas cidades (considere qualquer itiner�rio e tamb�m a
repeti��o de trechos entre as cidades com um m�ximo de 15 trechos percorridos), armazenados em um vetor da seguinte
forma (este vetor deve receber os dados do itiner�rio e o algoritmo deve permitir somente a digita��o dos c�digos que
existem no vetor de cidades).
*/
/*
 for(i = 0; i <= 14; i++){
    do{
      printf("Digite o codigo da %d cidade do itinerario: ", i+1);
      printf("\n0 - Londrina\n1 - Cambe\n2 - Curitiba\n3 - Maringa\n4 - Ibipora\n");
      scanf("%d", &iti[i]);
    }while ((iti[i] <0) || (iti[i] > 4));
  }
*/
/*Calcule e mostre um relat�rio da seguinte forma:
Cidade	        quilometragem percorrida
Londrina
Ibipor�	                 15
Maring�	                105
Curitiba	            486
*/
  for(i = 0; i < 15; i++)
    printf("%d  ", iti[i]);

  printf("\n\ncidade\tkm percorrida\t km acumulada\n\n");

//********** SOLU��O 01 - in�cio **********//
  s = 0;
  soma = 0;
  for(i = 0; i <= 14; i++){
    s2 = s;
    s = iti[i];
    if (i == 0)
      printf("%s\n", cid[s]);
      else{
        soma = soma + m[s][s2];
        printf("%s   \t%5d\t\t%5d\n", cid[s],m[s][s2],soma);
      }
  }

//********** SOLU��O 01 - fim **********//
printf("\n\n");
//********** SOLU��O 02 - in�cio **********//

  printf("%s\n", cid[iti[0]]);
  for(i = 1, soma = 0; i <= 14; i++){
    soma = soma + m[iti[i-1]][iti[i]];
    printf("%s    \t%5d\t\t%5d\n", cid[iti[i]],m[iti[i-1]][iti[i]],soma);
  }

//********** SOLU��O 02 - fim **********//
printf("\n\n");
//********** SOLU��O 03 - in�cio **********//
  printf("%s\n", cid[iti[0]]);
  for(i = 1, soma = 0; i <= 14;soma = soma + m[iti[i-1]][iti[i]], printf("%s    \t%5d\t\t%5d\n", cid[iti[i]],m[iti[i-1]][iti[i]],soma), i++);
//********** SOLU��O 03 - fim **********//

  printf("\n\nKm total \t%5d\n\n", soma);
}
