#include<stdio.h>
#include<math.h>

main(){

  int repeticao,a,sinal,expoente,b,c;
  float fat,rad,soma,angulo;
  for(angulo = 0.0 ; angulo <= 6.3 ; angulo = angulo + 0.1) {
    soma=0;
    sinal=1;
    expoente=1;
    fat=1;
    for(a=1;a<=1000;a+=1){
      for(c=1;c<=expoente;c+=1)
	    fat=fat*c;
      rad = angulo * M_PI / 180;
	  soma=soma+sinal*pow(rad,expoente)/fat;
  	  expoente+=2;
	  b+=2;
  	  fat=1;
	  sinal=-sinal;
    }
    printf("\nangulo em graus --> %f  angulo em radianos --> %f  seno --> %f",angulo, rad, soma);
  }
}

