/*
troca os valores que est�o acima da diagonal principal, pelos valores que est�o abaixo da diagonal principal
diagonal principal ------------> 0,0 1,1 2,2 3,3 4,4
acima da diagonal principal ---> 0,1 0,2 0,3 0,4 1,2 1,3 1,4 2,3 2,4 3,4
abaixo da diagonal principal --> 1,0 2,0 3,0 4,0 2,1 3,2 4,1 3,2 4,2 4,3
      0    1     2     3     4
  +-----+-----+-----+-----+-----+
0 | 0,0 | 0,1 | 0,2 | 0,3 | 0,4 |
  +-----+-----+-----+-----+-----+
1 | 1,0 | 1,1 | 1,2 | 1,3 | 1,4 |
  +-----+-----+-----+-----+-----+
2 | 2,0 | 2,1 | 2,2 | 2,3 | 2,4 |
  +-----+-----+-----+-----+-----+
3 | 3,0 | 3,1 | 3,2 | 3,3 | 3,4 |
  +-----+-----+-----+-----+-----+
4 | 4,0 | 4,1 | 4,2 | 4,3 | 4,4 |
  +-----+-----+-----+-----+-----+

  i,j  j,1
-----------
  0,1  1,0
  0,2  2,0
  0,3  3,0
  0,4  4,0
-----------
  1,2  2,1
  1,3  3,1
  1,4  4,1
-----------
  2,3  3,1
  2,4  4,1
-----------
  3,4  4,3
-----------
*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define L 5
#define C 5
void preencher(int [L][C]);
void imprimir(int [L][C]);
int main(){
  int i, j, aux, m[5][5];
  srand(time(NULL));
  //inicializa a matriz com zeros
  for(i = 0; i < L; i++)
    for(j = 0; j < C; j++)
       m[i][j] = 0;
  //mostra o conte�do da matriz
  imprimir(m);
  //preenche a matriz
  preencher(m);
  //mostra o conte�do da matriz
  imprimir(m);
  //troca os valores dentro da matriz
  for(i = 0; i < L; i++)
    for(j = i+1; j < C; j++){
      aux = m[i][j];
      m[i][j] = m[j][i];
      m[j][i] = aux;
    }
  //mostra o conte�do da matriz
  imprimir(m);
  return 0;
}
//preenche a matriz com n�meros rand�micos n�o repetidos
void preencher(int m[L][C]){
 int i, j, aux, r, i2, j2;
 srand(time(NULL));
  i = 0;
  while (i < L){
    j = 0;
    while (j < C){
      aux = rand()/1000;
      r = 0;
      for(i2 = 0; i2 <= i; i2++)
        for(j2 = 0; j2 <= j; j2++)
          if (m[i2][j2] == aux)
             r = 1;
      if (r == 0){
        m[i][j] = aux;
        j++;
      }
    }
    i++;
  }
}
void imprimir(int m[L][C]){
  int x, y;
  printf("\n");
  for(x = 0;x < L;x++){
    for(y = 0;y < C;y++)
       printf("%3d ",m[x][y]);
    printf("\n");
  }
}
