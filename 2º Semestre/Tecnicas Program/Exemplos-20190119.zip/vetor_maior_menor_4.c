#include <stdio.h>
#include <time.h>

main(){
  int v[20], i, x, j, n, maior, menor;
  srand(time(NULL));

  i = 0;
  while (i < 20){
    x = rand()/100;
    n = 0;
    for(j = 0; j < i; j++)
      if (v[j] == x)
        n = 1;
    if (n == 0) {
      v[i] = x;
      i++;
    }
  }

  for(i = 0;i < 20; i++)
    printf("%d ",v[i]);

  for(maior = v[0], menor = v[0], i = 1; i < 20; i++){
    if (v[i] > maior)
        maior = v[i];
    if (v[i] < menor)
        menor = v[i];
  }

  printf("\nO maior numero e --> %d\n", maior);
  printf("\nO menor numero e --> %d\n", menor);
}
