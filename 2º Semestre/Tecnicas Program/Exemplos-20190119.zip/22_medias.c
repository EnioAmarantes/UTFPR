#include <stdio.h>
main(){
  float v[88], soma, media;
  int i, j;
  srand(time(NULL));
  for(i = 0; i <= 87; i++)
    v[i] = (rand() / 100) * 1.3456 / 10;

  for(i = 0, j = 0, soma = 0, media = 0; i <= 87; i++){
    printf("%5.1f ",v[i]);
    soma = soma + v[i];
    j++;
    if (j == 4){
        printf(" - %5.1f",soma/4);
        printf("\n");
        media = media + (soma / 4);
        soma = 0;
        j = 0;
    }
  }
  printf("\nmedia da turma %5.1f",media/22);
}
