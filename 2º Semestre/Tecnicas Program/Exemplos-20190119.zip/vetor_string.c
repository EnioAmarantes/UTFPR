#include <stdio.h>
main ()
{
  float vect[6] = { 1.3, 4.5, 2.7, 4.1, 0.0, 100.1 };
  int matrx[3][4] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
  char str[10] = { 'J', 'o', 'a', 'o', '\0' };
  char str1[10] = "Joao";
  char str_vect[3][10] = { "Joao", "Maria", "Jose" };
  char nomes[5][100];
  int c, l;

  for (c=0;c<5;c++){
    printf("\n\nDigite uma string(%d): ", c+1);
    gets(nomes[c]);
  }

  printf ("\n\n\nOs nomes que voce digitou foram:\n\n");
  for (c=0;c<5;c++)
    printf ("%s\n",nomes[c]);
}

