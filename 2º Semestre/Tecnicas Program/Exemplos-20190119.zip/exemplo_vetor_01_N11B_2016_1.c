#include <locale.h>
#include <stdio.h>
#include <time.h>
#define T 88
main(){
  float notas[T], soma, media, maior, menor, maiorm, menorm;
  int i, j, k, maiorj, menorj;
  
  setlocale(LC_ALL, "Portuguese");
  srand(time(NULL));
  
  for(i = 0, soma = 0, k = 1, j = 1, media = 0;i < T;i++){
//	  printf("Digite a %d� nota do %d� aluno: ",k, j);
//	  scanf("%f",&notas[i]);
      do{
        notas[i] = rand()/1000.0;
	  }while (notas[i] > 10.0);
	  k = k + 1;
	  if (k == 5){
        k = 1;
	  	j = j + 1;
	  }
  }
  printf("\n");
  soma = 0;
  media = 0;
  j = 1;
  k = 1;
  for(i = 0;i < T;i++){
  	if (k == 1)
	  printf("\nAs notas do %d� aluno s�o:\n",j);
    printf("%.2f ",notas[i]);
    soma = soma + notas[i];
	media = media + notas[i];
	k++;
    if (k == 5){
      printf("\n\tA m�dia do %d� aluno � %.2f",j,soma/4);
      printf("\n--------------------------------\n");
      soma = 0;
      k = 1;
      j = j + 1;
   	}
  }   
  for(i = 0, k = 1, j = 1, maior = -1, menor = 11;i < T;i++){
      k = k + 1;
	  if (k == 5){
        k = 1;
	  	j = j + 1;
	  }
	  if (notas[i] > maior){
	  	maior = notas[i];
	    maiorj = j;
	  }
	  if (notas[i] < menor){
	  	menor = notas[i];
	  	menorj = j;
	  }
  }
  printf("\nA m�dia da turma � %.2f\n",media/T);
  printf("\nA maior nota � %.2f do aluno %d\n",maior, maiorj);
  printf("\nA menor nota � %.2f do aluno %d\n",menor, menorj);

  for(i = 0, j = 1, k = 1;i < T;i++){
  	  if (notas[i] == maior)
	  	printf("\nO aluno %d possui nota igual � maior nota",j);
  	  if (notas[i] == menor)
	  	printf("\nO aluno %d possui nota igual � menor nota",j);
      k = k + 1;
	  if (k == 5){
        k = 1;
	  	j = j + 1;
	  }
  }

    for(i = 0, soma = 0, k = 1;i < T;i++){
      soma = soma + notas[i]; 
      k = k + 1;
      if (i == 3){
		maiorm = soma / 4;
		menorm = soma / 4;
		k = 1;  
		soma = 0;
	  }
	  if ((k == 5) && (i > 3)){
        if (soma/4 > maiorm)
        	maiorm = soma/4;
        if (soma/4 < menorm)
        	menorm = soma/4;
	  	soma = 0;
	  	k = 1;
	  }
	}
	printf("\nA maior m�dia � %.2f",maiorm);
	printf("\nA menor m�dia � %.2f",menorm);
	
} 