#include <stdio.h>
main(){
  int A[3][3], B[3][3], R[3][3], K, I, J;

  printf("matriz A \n");
  for(I=0; I<3; I=I+1)
    for(J=0; J<3; J=J+1){
      printf("digite um valor para a linha %d e coluna %d: ", I, J);
      scanf("%d", &A[I][J]);
    }

  for(I=0; I<3; I=I+1){
    for(J=0; J<3; J=J+1)
      printf("%d ", A[I][J]);
    printf("\n");
  }

  printf("\nmatriz B \n");
  for(I=0; I<3; I=I+1)
    for(J=0; J<3; J=J+1){
      printf("digite um valor para a linha %d e coluna %d: ", I, J);
      scanf("%d", &B[I][J]);
    }

  for(I=0; I<3; I=I+1){
    for(J=0; J<3; J=J+1)
      printf("%d ", B[I][J]);
    printf("\n");
  }


  for(I=0;I<3;I=I+1)
    for(J=0;J<3;J=J+1){
      R[I][J]=0;
      for(K =0;K<3;K=K+1)
        R[I][J]=R[I][J]+A[I][K]*B[K][J];
    }

  printf("\n");
  for(I=0; I<3; I=I+1){
    for(J=0; J<3; J=J+1)
      printf("%d ", R[I][J]);
    printf("\n");
  }
}
