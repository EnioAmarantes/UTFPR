#include <stdio.h>
#include <conio.h>
void main(){
  int I, J, VALOR;
  int QUADRADO[5][5];
  VALOR=1;
  for(I=0;I<5; I++)
    for(J=0;J<5;J++){
      QUADRADO[I][J]=VALOR;
      VALOR++;
    }
  for(I=0;I<5;I++){
    for(J=0;J<5;J++)
       printf("%3d ",QUADRADO[I][J]);
    printf("\n");
  }
}
