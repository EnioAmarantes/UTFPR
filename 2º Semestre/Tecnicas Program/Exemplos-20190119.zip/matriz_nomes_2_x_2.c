#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
main(){

//  char nomes[2][2][50]={"Luiz XVI", "Maria Antonieta","Francisco Xico","Jo�o J�o"};
  int lin, col, p;
  
  char nome[50];
  
  setlocale(LC_ALL, "Portuguese");

  printf("\nDigite um nome: ");
  fflush(stdin);
//  scanf("%s",&nome);
//  scanf("%[^\n]s",&nome);
  gets(nome);
/*  
  p = 0;
  do{
	nome[p] = getchar();  
	p++;  
  }while (nome[p-1] != '\0');
*/
  
  printf("\n");
  
  for(p = 0;nome[p] != '\0';p++){
    if ((nome[p] >= 65) && (nome[p] <=90))
		printf("%c",nome[p]);	
  }
  
  printf("\n");

  printf("%s",nome);

// ERRO  
//  if (nome == "Antonio") 
//    printf("\nNomes iguais");

  if (strcmp(nome,"Antonio") == 0)
  	  printf("\nNomes iguais");
  
  /*
    for(lin = 0;lin < 2;lin++){
	   for(col = 0;col < 2;col++)
	     printf("%s\t",nomes[lin][col]);
	   printf("\n");
    }
  
  printf("\n");
 
   for(lin = 0;lin < 2;lin++){
	for(col = 0;col < 2;col++)
	   for(p = 0;p < 50;p++)
   	  	  putchar(nomes[lin][col][p]);
	  printf("\n");
  }
  
  printf("\n");  
  for(lin = 0;lin < 2;lin++){
	for(col = 0;col < 2;col++)
	   for(p = 0;nomes[lin][col][p] != '\0';p++)
   	  	  putchar(nomes[lin][col][p]);
	  printf("\n");
  } 
  */ 
}