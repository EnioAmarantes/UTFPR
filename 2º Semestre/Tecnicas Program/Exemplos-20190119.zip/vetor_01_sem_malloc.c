#include <stdio.h>
main(){
  int i, q, v[100];

  printf("Qual a quantidade de elementos do vetor: ");
  scanf("%d", &q);

  for(i = 0;i < q; i++){
    scanf("%d", &v[i]);
  }

  for(i = 0;i < q; i++)
    printf("%d ", v[i]);
}
