#include <stdio.h>
#include <time.h>
#define T 10
void preenche(int v[T])
{
     int i;
     srand(time(NULL));
     for(i = 0; i < T; i++)
       v[i] = rand()/100;
}
void mostra(int v[T])
{
     int i;
     for(i = 0; i < T; i++)
      printf("%d  ", v[i]);
}
main ()
{
	int matrix[T];
	preenche(matrix);
	mostra(matrix);
}
