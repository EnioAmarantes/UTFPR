/*O dia da semana para uma data qualquer pode ser calculado pela seguinte f�rmula:
Dia da semana = (int(2,6*M-0,1)+D+A+Adiv4+Sdiv4-2*S)MOD7
int() retorna a parte inteiro de um n�mero
Onde:
M � representa o n�mero do m�s. Janeiro e fevereiro s�o os meses 11 e 12 do ano precedente, mar�o � o m�s 1 e dezembro � o m�s 10;
D � representa o dia do m�s;
A � representa o n�mero formado pelos dois �ltimos algarismos do ano;
S � representa o n�mero formado pelos dois primeiros algarismos do ano;
Os dias da semana s�o numerados de zero a seis; Domingo corresponde a zero, Segunda a 1, e assim por diante.*/
#include <stdio.h>
int main(){
  int m, d, ano, a, s, ds;
  printf("Informe o dia: ");
  scanf("%d",&d);
  printf("Informe o mes: ");
  scanf("%d",&m);
  printf("Informe o ano com quatro digitos: ");
  scanf("%d",&ano);
  a = ano % 100;
  s = ano / 100;
  if ((m == 1) || (m == 2)) m = m + 10;
  if ((m >= 3) && (m <= 12)) m = m - 2;
  ds = ((int)(2.6 * m - 0.1) + (m + d + a + a / 4 + s / 4 - 2 * s)) % 7;
  switch (ds){
    case 0:
        printf("Domingo");
        break;
    case 1:
        printf("Segunda-feira");
        break;
    case 2:
        printf("Terca-feira");
        break;
    case 3:
        printf("Quarta-feira");
        break;
    case 4:
        printf("Quinta-feira");
        break;
    case 5:
        printf("Sexta-feira");
        break;
    case 6:
        printf("Sabado");
        break;
  }
  return 0;
}
