#include <stdio.h>
#include <stdlib.h>
int main()
{
	char url[50];// = "BasedeDados - Copia.txt";
	char ch;
	FILE *arq;
	
	printf("\nInforme caminho/nome do arquivo texto: ");
	fflush(stdin);
	gets(url);
	
	arq = fopen(url, "r");
	if(arq == NULL)
	    printf("Erro, nao foi possivel abrir o arquivo\n");
	else
	    while( (ch = fgetc(arq))!= EOF )
	    	putchar(ch);
			
	fclose(arq);
	
	return 0;
}