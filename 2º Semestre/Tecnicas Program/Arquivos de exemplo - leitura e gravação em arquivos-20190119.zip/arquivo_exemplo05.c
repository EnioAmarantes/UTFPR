#include <stdio.h>

int main()
{
	char url[]="basededados - copia.txt",
	     info[80];
	FILE *arq;
	
	arq = fopen(url, "r");
	if(arq == NULL)
			printf("Erro, nao foi possivel abrir o arquivo\n");
	else
		while( (fgets(info, sizeof(info), arq))!= NULL )
			printf("%s", info);
	
	fclose(arq);
	
	return 0;
}