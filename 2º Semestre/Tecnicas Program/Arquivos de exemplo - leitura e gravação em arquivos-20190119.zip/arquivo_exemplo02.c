#include <stdio.h>
#include <conio.h>
#include <string.h>
/*
codigo                - int			- cod
cliente               - string	- cl
funcion�rio           - string	- fc
data                  - string	- dt
Via                   - string	- via
Frete                 - float		- frete
Nome do Destinat�rio  - string	- nome
Cidade de Destino     - string	- cid
Pa�s de Destino       - string	- pais
Trim-Ano              - string	- trim
S� Ano                - int			- ano
S� trimestre          - int			- tri
Vendas                - float		- vendas
*/

int main()
{
	FILE *arq_cliente;
	FILE *destino;
	char cl[50], fc[50], dt[15], via[50], nome[50], cid[50], pais[50],
       trim[15], frete[20], vendas[20];
	int cod, ano, tri, indice = 0;
	arq_cliente = fopen("BasedeDados - Copia.txt", "r");
	destino = fopen("BasedeDados - Destino.txt","a");

	if (arq_cliente == NULL)
	{
		printf("\nArquivo CLIENTE.TXT nao pode ser aberto.");
		printf("\nOcorreu um Erro Grave ! Use alguma tecla para finalizar !");
		getch();
	}
	else
	{
		while((fscanf(arq_cliente, 
		             	  	"%d %s %s %s %s %s %s %s %s %s %d %d %s", 
											 &cod, &cl, &fc, &dt, &via, &frete, &nome, 
											 &cid, &pais, &trim, &ano, &tri, &vendas)
		      )!= EOF)
		{
			indice = indice + 1;
			printf("\n Dados do %d cliente : ", indice);
			printf("\n Cliente.......: %d - %s", cod, cl);
			printf("\n Funcionario...: %s", fc);
			printf("\n Data..........: %s", dt);
			printf("\n Via...........: %s", via);
			printf("\n Frete.........: %s", frete);
			printf("\n Destinatario..: %s - %s - %s", nome, cid, pais);
			printf("\n Per�odo.......: %s - %d - %d", trim, ano, tri);
			printf("\n Vendas........: %s", vendas);
			printf("\n--------------------------------------------------------------");
			getch();
			
			fprintf(destino,"%d;%s;%s;%s;%s;%s;%s;%s;%s;%s;%d;%d;%s\n", 
										 cod, cl, fc, dt, via, frete, nome, 
										 cid, pais, trim, ano, tri, vendas);
		}
		fclose (arq_cliente);
		fclose(destino);
		printf("\n *** FIM : [Tecle algo] !");
		getch();
	}
	return 0;
}
