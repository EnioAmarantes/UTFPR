package semana_02;

public class VerificadorDeSenhas {
	Dicionario dic;
	 public VerificadorDeSenhas(Dicionario dic) {
	 this.dic = dic;
	 }

	 public boolean validarNovaSenha(String senhaFornecida) {
	 //TODO
	 return true;
	 }

}
