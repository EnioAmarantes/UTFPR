package semana_02;

import java.util.ArrayList;

public interface Dicionario {
	public ArrayList<String> getListaDeSenhasInvalidas();
}
