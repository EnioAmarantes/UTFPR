package semana_02;

public interface VerificadorDeCodigos {
	 public boolean verificarCodigoDisciplina(String codigo);
	 public boolean verificarCodigoTurma(String codigo);
}
