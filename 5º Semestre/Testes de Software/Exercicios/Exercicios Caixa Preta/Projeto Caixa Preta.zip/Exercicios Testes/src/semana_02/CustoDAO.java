package semana_02;

public interface CustoDAO {
    public int getCustoPorGrama(String regiao);
}
