package mock;

public interface Helper {
	public String[] getCensoredWords();
}
