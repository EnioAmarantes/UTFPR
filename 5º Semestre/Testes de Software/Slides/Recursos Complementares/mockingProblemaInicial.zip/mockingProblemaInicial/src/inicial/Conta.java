package inicial;

/**
 *
 * @author andreendo
 */
public class Conta {
    
}
