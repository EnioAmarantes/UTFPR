package inicial;

/**
 *
 * @author andreendo
 */
public class SemFundosException extends Exception {
}
