package inicial;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

class ClienteTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
