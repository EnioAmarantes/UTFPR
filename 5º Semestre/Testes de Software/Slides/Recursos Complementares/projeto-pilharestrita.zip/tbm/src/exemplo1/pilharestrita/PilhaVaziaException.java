package exemplo1.pilharestrita;

public class PilhaVaziaException extends Exception {
}
