package exemplo1.pilharestrita;

public class PilhaCheiaException extends Exception {
}