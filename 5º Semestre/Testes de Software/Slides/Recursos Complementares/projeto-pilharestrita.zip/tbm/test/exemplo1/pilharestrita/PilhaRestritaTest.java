package exemplo1.pilharestrita;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PilhaRestritaTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
