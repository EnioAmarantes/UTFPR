#include <stdio.h>
#include <stdlib.h>

typedef struct Ponto {
    int x;
    float y;
    double z;
} PONTO;

int main() {
    
    printf("Tamanho do char: %d\n", (int)sizeof(char));
    printf("Tamanho do int: %d\n", (int)sizeof(int));
    printf("Tamanho do float: %d\n", (int)sizeof(float));
    printf("Tamanho do double: %d\n", (int)sizeof(double));
    printf("Tamanho da struct Ponto: %d\n", (int)sizeof(PONTO));

    return 0;
}
