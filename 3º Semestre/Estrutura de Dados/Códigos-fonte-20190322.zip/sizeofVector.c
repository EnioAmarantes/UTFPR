#include <stdio.h>
#include <stdlib.h>

int main() {
    int vet[3];

    printf("Tamanho: %d\t endereço v[0]: %d\t\n", (int) sizeof(vet[0]), &vet[0]);
    printf("Tamanho: %d\t endereço v[1]: %d\t\n", (int) sizeof(vet[1]), &vet[1]);
    printf("Tamanho: %d\t endereço v[2]: %d\t\n", (int) sizeof(vet[2]), &vet[2]);

    return 0;
}
