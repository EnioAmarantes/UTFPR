#include <stdio.h>
#include <stdlib.h>

int main() {

    int i;
    int *v;
    v = (int*) malloc(sizeof(int) * 5);
    
    v[0] = 10;
    v[1] = 20;
    v[2] = 30;
    v[3] = 30;
    v[4] = 10;
   
    printf("\nVetor atual: %d %d %d %d %d\n", v[0], v[1], v[2], v[3], v[4]);  
    
    printf("\nRealocando espaço no vetor...\n");    
    v = (int*) realloc(v, sizeof(int) * 6);

    v[5] = (v[0] + v[1] + v[2] + v[3] + v[4]) / 5;

    printf("\nNovo vetor: %d %d %d %d %d %d\n\n", v[0], v[1], v[2], v[3], v[4], v[5]);

    free(v);
    return 0;
}
