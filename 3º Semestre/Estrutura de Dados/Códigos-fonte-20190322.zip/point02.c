#include <stdio.h>
#include <stdlib.h>

int main() {
    int x, y;
    int *px, *py;

    x = 10; y = 20;

    printf("Valor de x: %d - y: %d\n", x, y);

    px = &x; 
    py = &y;

    printf("Conteúdo apontado por px: %d - py: %d\n", *px, *py);

    *px = 3;
    *py = 5;

    printf("Conteúdo apontado por px: %d - py: %d\n", *px, *py);
    printf("Valor de x: %d - y: %d\n", x, y);

    return 0;
}
