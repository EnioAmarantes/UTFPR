#include <stdio.h>
#include <stdlib.h>

int main() {
    int *p;
    
    printf("Endereço: %d\t\n", p);
    printf("Endereço: %d\t\n", ++p);
    printf("Endereço: %d\t\n", ++p);

    return 0;
}
