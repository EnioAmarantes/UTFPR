#include <stdlib.h>
#include <stdio.h>

#define RET 0
#define TRI 1
#define CIR 2

typedef struct listHet {
    int tipo;
    void *info;
    struct listHet *prox;
} Lista;

typedef struct retangulo {
    float base;
    float altura;
} Retangulo;

typedef struct triangulo {
    float base;
    float altura;
} Triangulo;

typedef struct circulo {
    float raio;
} Circulo;

Lista* cria_ret(float b, float h) {
    Retangulo *r;
    Lista *p;
    
    r = (Retangulo*) malloc(sizeof(Retangulo));
    r->base = b;
    r->altura= h;
    
    p = (Lista*) malloc(sizeof(Lista));
    p->tipo = RET;
    p->info = r;
    p->prox = NULL;

    return p;
}

Lista* cria_circ(float r) {
    Circulo *c;
    Lista *p;
    
    c = (Circulo*) malloc(sizeof(Circulo));
    c->raio = r;
    
    p = (Lista*) malloc(sizeof(Lista));
    p->tipo = CIR;
    p->info = c;
    p->prox = NULL;
    return p;
}

Lista* cria_tri(float b, float h) {
    Triangulo *t;
    Lista *p;
    
    t = (Triangulo*) malloc(sizeof(Triangulo));
    t->base = b;
    t->altura = h;
    
    p = (Lista*) malloc(sizeof(Lista));
    p->tipo = TRI;
    p->info = t;
    p->prox = NULL;
    
    return p;
}

Lista* criaLista() {
    return NULL;
}

Lista* insereElemento(Lista *pLista, Lista *elemento) {

    if(pLista == NULL) {
        elemento->prox = NULL;
    } else {
        elemento->prox = pLista;
    }
    
    return elemento;
}


float calcArea(Lista *p) {
    float area;

    switch(p->tipo) {
        case RET:
            area = ((Retangulo*)p->info)->base * ((Retangulo*)p->info)->altura;
            break;

        case TRI:
            area = ((Triangulo*)p->info)->base * ((Triangulo*)p->info)->altura / 2;
            break;

        case CIR:
            area = ((Circulo*)p->info)->raio * 2 * 3.14;
            break;

    }
    return area;
}

void imprimeLista(Lista *pLista) {
    
    Lista *p;
    
    for(p=pLista; p!=NULL; p=p->prox) {
        printf("\n");
   
        if(p->tipo == RET) {
            printf("Retangulo - base: %.2f | altura: %.2f | área: %.2f", ((Retangulo*)p->info)->base, ((Retangulo*)p->info)->altura, calcArea(p));
        } else if(p->tipo == TRI) {
            printf("Triangulo - base: %.2f | altura: %.2f | área: %.2f", ((Triangulo*)p->info)->base, ((Triangulo*)p->info)->altura, calcArea(p));
        } else if(p->tipo == CIR) {
            printf("Circulo - raio: %.2f | área: %.2f", ((Circulo*)p->info)->raio, calcArea(p));
        }
    }
}

void liberaLista(Lista *pLista) {
    Lista *p;
    Lista *ant = NULL;

    for(p=pLista; p!=NULL; p=p->prox) {
        ant = p->prox;

        switch(p->tipo) {
            case RET:
                printf("\nDesalocando retangulo...\n");
                break;
            case TRI:
                printf("\nDesalocando triangulo...\n");
                break;
            case CIR:
                printf("\nDesalocando circulo...\n");
                break;;
        }
        free(p);
    }
}

int main() {

    Lista *lista = criaLista();

    lista = insereElemento(lista, cria_ret(10,20)); 
    lista = insereElemento(lista, cria_ret(30,60));
    lista = insereElemento(lista, cria_tri(10,10));
    lista = insereElemento(lista, cria_circ(20));
    imprimeLista(lista);

    liberaLista(lista);  
    return 0;
}
