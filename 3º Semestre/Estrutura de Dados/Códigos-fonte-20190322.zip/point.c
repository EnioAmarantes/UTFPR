#include <stdio.h>
#include <stdlib.h>

int main() {
    int i, j, k;

    printf("O endereço da variável i -> %u\n", &i);
    printf("O endereço da variável j -> %u\n", &j);
    printf("O endereço da variável k -> %u\n", &k);

    return 0;
}
