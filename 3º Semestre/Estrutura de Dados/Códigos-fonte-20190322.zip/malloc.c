#include <stdio.h>
#include <stdlib.h>

int main() {

    int *v = malloc(200);
    
    char *c = malloc(200);
    
    return 0;
}
