#include <stdio.h>
#include <stdlib.h>

int main() {
    int *vet;
    int i;
    
    vet = (int*) malloc(sizeof(int) * 5);
    
    printf("\n\nDigite 5 valores: ");
    scanf("%d %d %d %d %d", &vet[0], &vet[1], &vet[2], &vet[3], &vet[4]);

    for(i=0; i<5; i++) {
        printf("%d ", vet[i]);
    }
    printf("\n");

    vet = (int*) realloc(vet, sizeof(int) * 8);

    printf("Digite mais 3 valores: ");
    scanf("%d %d %d", &vet[5], &vet[6], &vet[7]);

    for(i=0; i<8; i++) {
        printf("%d ", vet[i]);
    }
    printf("\n\n");

    free(vet);
    return 0;
}
