#include <stdio.h>
#include <stdlib.h>

typedef struct retangulo {
    float base;
    float altura;
} Retangulo;

typedef struct lista {
    Retangulo *info;
    struct lista *prox;
} Lista;

Lista* criarVazia() {
    return NULL;
}

Lista* insereLista(Lista* pLista, float base, float altura) {
    Lista *lst = (Lista*) malloc(sizeof(Lista));
    Retangulo *r = (Retangulo*) malloc(sizeof(Retangulo));
    
    r->base = base;
    r->altura = altura;
    lst->info = r;    

    if(pLista == NULL) {
        lst->prox = NULL;
    } else {
        lst->prox = pLista;
    }
    
    return lst;
}

void imprimeLista(Lista* pLista) {
    Lista *p;

    printf("\n");
    for(p=pLista; p!=NULL; p=p->prox) {
        printf("%.2f %.2f\n", p->info->base, p->info->altura);
    }
}

Lista* removeLista(Lista* pLista, float base, float altura) {
    Lista *p = pLista;
    Lista *ant = NULL;

    while(p!=NULL) {
        
        if( (p->info->altura == altura) && (p->info->base == base) ) {
            if(ant == NULL) {
                return p->prox;
            } else {
                ant->prox = p->prox;
            }
        }
        ant=p;
        p=p->prox;
    }
    return p;
}

int main() {

    Lista *lista = criarVazia(); 
    
    lista = insereLista(lista, 10, 20); 
    lista = insereLista(lista, 40, 80);

    imprimeLista(lista);

    lista = removeLista(lista, 40.00, 80.00);

    imprimeLista(lista);

    return 0;
}
