#include <stdio.h>
#include <stdlib.h>

typedef struct Lista {
    int info;
    struct Lista *prox;
    struct Lista *ant;
} LISTA_DUPLA;

LISTA_DUPLA* inserir_elemento(LISTA_DUPLA* pLista, int valor) {

    LISTA_DUPLA* novo = (LISTA_DUPLA*) malloc(sizeof(LISTA_DUPLA));

    novo->info = valor;
    novo->prox = pLista;
    novo->ant=NULL;

    if(pLista != NULL) {
        pLista->ant=novo;
    }
    
    return novo;
}

LISTA_DUPLA* listaVazia() {
    return NULL;
}

void imprimir(LISTA_DUPLA* pLista) {
    LISTA_DUPLA* p;
    printf("\n");
    for(p=pLista; p!=NULL; p=p->prox) {
        printf("%d ", p->info);
    }
    printf("\n");
}

LISTA_DUPLA* buscarElemento(LISTA_DUPLA* pLista, int valor) {
    LISTA_DUPLA *p;

    for(p=pLista; p!=NULL; p=p->prox) {
        if(p->info == valor) {
            return p;
        }
    } 

    return NULL;
}

LISTA_DUPLA* retirarElemento(LISTA_DUPLA* pLista, int valor) {

    LISTA_DUPLA *p = buscarElemento(pLista, valor);

    if(p==NULL) {
        return pLista;
    }

    if(pLista == p) {
        pLista = p->prox;
    } else {
        p->ant->prox = p->prox;
    }

    if(p->prox!=NULL) {
        p->prox->ant=p->ant;
    }

    free(p);
    return pLista;
}

LISTA_DUPLA* inserir_ordenado(LISTA_DUPLA* pLista, int valor) {

    LISTA_DUPLA* ant = NULL;
    LISTA_DUPLA* p = pLista;
    LISTA_DUPLA* novo = (LISTA_DUPLA*) malloc(sizeof(LISTA_DUPLA));
    novo->info = valor;

    while(p!=NULL && p->info < valor) {
        ant=p;
        p = p->prox;
    }

    if(ant==NULL) { 
        novo->prox = pLista;
        novo->ant = ant;
        pLista = novo;
    } else {
        novo->prox = ant->prox;
        novo->ant = ant;
        ant->prox = novo;
        ant->prox->ant = novo; 
    }
    return pLista;
}


int main() {

    LISTA_DUPLA* lista = listaVazia();    
    LISTA_DUPLA* p;    

    imprimir(lista);

    lista = inserir_ordenado(lista, 5);
    lista = inserir_ordenado(lista, 10);
    lista = inserir_ordenado(lista, 7);
    imprimir(lista);
    /*p = buscarElemento(lista, 10);
    if(p!=NULL) {
        printf("Entrou o elemento %d\n", p->info);
    } else {
        printf("Não encontrou o elemento\n");
    }*/

    //lista = retirarElemento(lista, 10);

    //imprimir(lista);     

    return 0;
}
