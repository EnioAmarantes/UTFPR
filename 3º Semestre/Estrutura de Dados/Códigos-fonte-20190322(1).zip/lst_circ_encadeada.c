#include <stdio.h>
#include <stdlib.h>

typedef struct Lista {
    int valor;
    struct Lista *prox;
} LISTA_CIRCULAR;

LISTA_CIRCULAR* criarListaVazia() {
    printf("\nLista criada\n");
    return NULL;
}

LISTA_CIRCULAR* buscaUltimoElemento(LISTA_CIRCULAR* pLista) {
    
    LISTA_CIRCULAR* p = pLista;
    LISTA_CIRCULAR* ant;

    if(p!=NULL) {
        do {
            ant=p;
            p=p->prox;
        }while(p!=pLista);
        return ant;
    }
    
    return pLista;
}

void imprimir(LISTA_CIRCULAR* pLista) {
    LISTA_CIRCULAR* p = pLista;

    printf("\n");
    if(p!=NULL) {
        do {
            printf("%d ", p->valor);
            p=p->prox;
        } while(p!=pLista);
    }   
}


LISTA_CIRCULAR* inserir(LISTA_CIRCULAR* pLista, int valor) {

    LISTA_CIRCULAR* novo = (LISTA_CIRCULAR*) malloc(sizeof(LISTA_CIRCULAR));
    LISTA_CIRCULAR* ultimo = buscaUltimoElemento(pLista);
    novo->valor = valor;  

    if(pLista==NULL) {
        novo->prox = novo;
    } else {
        novo->prox = pLista;
        ultimo->prox = novo;
    }
  
    return novo;
}

LISTA_CIRCULAR* remover(LISTA_CIRCULAR* pLista, int valor) {
    
    LISTA_CIRCULAR* p = pLista;
    LISTA_CIRCULAR* ant=NULL;
    LISTA_CIRCULAR* ultimoElemento;

    if(pLista!=NULL) {
        do{
            ant=p;
            p=p->prox;
        }while(p!=pLista && p->valor!=valor);

        if(ant==NULL) { //indica que o elemento está no início
            pLista = p->prox;
            ultimoElemento = buscaUltimoElemento(pLista);
            ultimoElemento->prox = pLista;
        } else {
            ant->prox = p->prox;
        }
    }
    return pLista;
}


void imprimirManual(LISTA_CIRCULAR* pLista) {
    LISTA_CIRCULAR* p;

    char c;

    printf("\n[N] - Próximo elemento\n[S] - Sair\n");
    
    do {
        scanf(" %c", &c);

        if(c == 'n' || c == 'N') {
            printf("%d \n", p->valor);
            p=p->prox;
        }
    } while(c!='S' && c!='s');
}


int main() {
    
    LISTA_CIRCULAR *lista = criarListaVazia();

    lista = inserir(lista, 5);
    lista = inserir(lista, 10);
    lista = inserir(lista, 15);
    lista = inserir(lista, 20);    

    imprimir(lista);

    //lista = remover(lista, 15);

    //imprimir(lista);
    
    imprimirManual(lista);
    
    return 0;
}
