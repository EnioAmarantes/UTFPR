#include <stdio.h>
#include <stdlib.h>

typedef struct Lista {
    int info;
    struct Lista* prox;
} LISTA;

LISTA* criar_lista() {

    return NULL;
}

int listaVazia(LISTA* pLista) {
    return (pLista==NULL);    
}

LISTA* inserir_elemento(LISTA* pLista, int valor) {

    LISTA *novo = (LISTA*) malloc(sizeof(LISTA));

    novo->info = valor;
    novo->prox = pLista;

    return novo;
}

void liberar(LISTA* pLista) {

    LISTA *p = pLista;

    while(p!=NULL) {
        LISTA *t = p->prox;
        printf("\nLiberando %d da memoria.\n", p->info);
        free(p);
        printf("\nLiberado.\n");
        p = t;
    }
}

void imprimir(LISTA* pLista) {
    LISTA* p;

    printf("\n");
    if(listaVazia(pLista)) {
        printf("\nLista vazia!\n");
    } else { 
        for(p=pLista; p!=NULL; p=p->prox) {
            printf("%d ", p->info);
        }
    }
    printf("\n\n");
}

LISTA* buscar_elemento(LISTA* pLista, int valor) {
    LISTA *p;
    
    for(p=pLista; p!=NULL; p=p->prox) {
        if(p->info == valor) {
            return p;
        }
    }

    return NULL;
}

LISTA* retirar_elemento(LISTA* pLista, int valor) {

    LISTA* p = pLista;
    LISTA* ant = NULL;
    
    while(p!=NULL && p->info!=valor) {
        ant=p;
        p=p->prox;
    }

    if(p == NULL) {
        return pLista;
    }

    if(ant == NULL) {
        pLista = p->prox;
    } else {
        ant->prox=p->prox;
    }

    free(p);

    return pLista;
}

LISTA* inserir_ordenado(LISTA *pLista, int valor) {

    LISTA *ant = NULL;
    LISTA *p = pLista;
    LISTA *novo = (LISTA*) malloc(sizeof(LISTA));
    novo->info = valor;

    while(p!=NULL && p->info < valor) {
        ant = p;
        p = p->prox;
    }

    if(ant==NULL) {
        novo->prox = pLista;
        pLista = novo;    
    } else {
        novo->prox = ant->prox;
        ant->prox = novo;        
    }

    return pLista;
}

int main() {

    LISTA *L;

    L = criar_lista();
    //L = inserir_elemento(L, 10);
    //L = inserir_elemento(L, 20);
    //L = inserir_elemento(L, 30);
    //L = inserir_elemento(L, 40);
    imprimir(L);
    //L = retirar_elemento(L, 20);
    imprimir(L);
    L = inserir_ordenado(L, 25);
    L = inserir_ordenado(L, 30);
    L = inserir_ordenado(L, 10);
    L = inserir_ordenado(L, 15);

    imprimir(L);

    return 0;
}
