#include <stdio.h>
#include <stdlib.h>

typedef struct Item {
    int valor;
} ITEM;

int main() {

    ITEM *v_itens;
    
    v_itens = (ITEM*) malloc(sizeof(ITEM)*5);
    v_itens[0].valor = 10;
    v_itens[1].valor = 20;
    v_itens[2].valor = 15;
    v_itens[3].valor = 10;
    v_itens[4].valor = 25;

    v_itens = realloc(v_itens, sizeof(ITEM)*6);
    
    v_itens[5].valor = 0;

    for(int i=0; i<5; i++) {
        v_itens[5].valor += v_itens[i].valor;
    }

    v_itens[5].valor = v_itens[5].valor / 5;

    printf("\nA média dos valores é: %d\n", v_itens[5].valor);
   
    free(v_itens);
    
    return 0;
}
