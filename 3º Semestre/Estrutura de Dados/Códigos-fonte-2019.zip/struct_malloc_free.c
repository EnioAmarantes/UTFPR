#include <stdio.h>
#include <stdlib.h>

typedef struct Estudante {
	char *nome;
	int matricula;
	int idade;
} ESTUDANTE;

int main() {

	ESTUDANTE *est;
	
	est=(ESTUDANTE*) malloc(sizeof(ESTUDANTE));

	est->nome = "Henrique";
	est->matricula = 11111;
	est->idade = 35;

	printf("\nNome: %s\nIdade: %d\nMatricula: %d\n", est->nome, est->matricula, est->idade);

	free(est);

	return 0;
}
