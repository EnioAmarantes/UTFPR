#include <stdio.h>
#include <stdlib.h>

typedef struct Nota {
	float P1;
	float P2;
	float T;
	float media;
} NOTA;

typedef struct Aluno {
	char *nome;
	int matricula;
	NOTA *nota;
} ALUNO;

int main() {

	ALUNO *alunos;

	alunos = (ALUNO*) malloc(sizeof(ALUNO) * 2);
	
	for(int i=0; i<2; i++) {
		alunos[i].nota = (NOTA*) malloc(sizeof(NOTA));
	}

	alunos[0].nome = "Henrique";
	alunos[0].matricula = 12345;
	alunos[0].nota->P1 = 10;
	alunos[0].nota->P2 = 6;
	alunos[0].nota->T  = 4;
	alunos[0].nota->media = (alunos[0].nota->P1 + alunos[0].nota->P2 + alunos[0].nota->T) /3;

	alunos[1].nome = "Pedro";
	alunos[1].matricula = 11111;
	alunos[1].nota->P1 = 6;
	alunos[1].nota->P2 = 9;
	alunos[1].nota->T  = 10;
	alunos[1].nota->media = (alunos[1].nota->P1 + alunos[1].nota->P2 + alunos[1].nota->T) /3;

	for(int i=0; i<2; i++) {
		printf("\nNome: %s\nMatricula: %d\nNota 1: %.2f\nNota 2: %.2f\nTrabalho: %.2f\nMedia: %.2f\n",
			alunos[i].nome, alunos[i].matricula, alunos[i].nota->P1, alunos[i].nota->P2, alunos[i].nota->T, alunos[i].nota->media);
	}

	for(int i=0; i<2; i++) {
		free(alunos[i].nota);
	}

	free(alunos);

	return 0;
}
