#include <stdio.h>
#include <stdlib.h>

typedef struct Aluno {
    char nome[40];
    int matricula;
    float P1;
    float P2;
    float T;
    float media;
} ALUNO;

void imprimeDados(ALUNO *a, int qtde) {
   
    for(int i=0; i<qtde; i++) { 
        printf("\nNome: %s\n", a[i].nome);
        printf("Matricula: %d\n", a[i].matricula);
        printf("P1: %.2f\n", a[i].P1);
        printf("P2: %.2f\n", a[i].P2);
        printf("T: %.2f\n", a[i].T);
        printf("Media: %.2f\n", a[i].media); 
    }

}

void calcMedia(ALUNO *a, int qtde) {
    for(int i=0; i<qtde; i++) {
        a[i].media = (a[i].P1 + a[i].P2 + a[i].T) / 3;
    }
}

int main() {

    ALUNO *aluno;
    aluno = (ALUNO*) malloc(sizeof(ALUNO) * 5);
    
    for(int i=0; i<5; i++) {
        printf("\nDigite o nome do aluno: ");
        scanf("%s", aluno[i].nome);

        printf("\nDigite a matricula: ");
        scanf("%d", &aluno[i].matricula);
    
        printf("\nDigite a nota P1: ");
        scanf("%f", &aluno[i].P1);

        printf("\nDigite a nota P2: ");
        scanf("%f", &aluno[i].P2);

        printf("\nDigite a nota T: ");
        scanf("%f", &aluno[i].T);
    }

    calcMedia(aluno, 5);
    imprimeDados(aluno, 5);

    free(aluno);

    return 0;
}


