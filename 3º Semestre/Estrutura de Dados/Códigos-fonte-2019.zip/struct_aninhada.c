#include <stdio.h>
#include <stdlib.h>

typedef struct Nota {
	float P1;
	float P2;
	float T;
	float media;
} NOTA;

typedef struct Aluno {
	char *nome;
	int matricula;
	NOTA *nota;
} ALUNO;

int main() {

	ALUNO *aluno1;

	aluno1 = (ALUNO*) malloc(sizeof(ALUNO));
	aluno1->nota = (NOTA*) malloc(sizeof(NOTA));

	aluno1->nome = "Henrique";
	aluno1->matricula = 12345;
	aluno1->nota->P1 = 7;
	aluno1->nota->P2 = 5;
	aluno1->nota->T  = 8;
	aluno1->nota->media = (aluno1->nota->P1 + 
			       aluno1->nota->P2 + 
			       aluno1->nota->T) / 3;
	
	printf("\nA media do aluno %s é: %.2f\n", 
		aluno1->nome, aluno1->nota->media); 

	free(aluno1->nota);
	free(aluno1);
	return 0;
}
