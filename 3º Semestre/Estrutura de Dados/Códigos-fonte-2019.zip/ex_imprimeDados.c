#include <stdio.h>
#include <stdlib.h>

typedef struct Aluno {
    char *nome;
    int matricula;
    float P1;
    float P2;
    float T;
    float media;
} ALUNO;

void imprimeDados(ALUNO *a) {
    
    printf("\nNome: %s\n", a->nome);
    printf("Matricula: %d\n", a->matricula);
    printf("P1: %.2f\n", a->P1);
    printf("P2: %.2f\n", a->P2);
    printf("T: %.2f\n", a->T);
    printf("Media: %.2f\n", a->media); 

}

int main() {

    ALUNO *aluno;
    aluno = (ALUNO*) malloc(sizeof(ALUNO));
    
    aluno->nome = "Henrique";
    aluno->matricula = 12345;
    aluno->P1 = 10;
    aluno->P2 = 5.5;
    aluno->T = 4.5;
    aluno->media = (aluno->P1 + aluno->P2 + aluno->T) / 3;

    imprimeDados(aluno);

    free(aluno);

    return 0;
}


