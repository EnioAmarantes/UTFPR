#include <stdio.h>
#include <stdlib.h>

typedef struct Aluno {
    char *nome;
    int matricula;
    float P1;
    float P2;
    float T;
    float media;
} ALUNO;

int main() {

    ALUNO *aluno;
    aluno = (ALUNO*) malloc(sizeof(ALUNO));

    aluno->nome = "Henrique";
    aluno->matricula = 12345;
    aluno->P1 = 7.5;
    aluno->P2 = 6.0;
    aluno->T  = 8.1;
    aluno->media = (aluno->P1 + aluno->P2 + aluno->T) / 3;
    
    printf("\nO aluno %s (matrícula %d) teve a média %.2f\n", aluno->nome, aluno->matricula, aluno->media);

    free(aluno);

    return 0;
}
