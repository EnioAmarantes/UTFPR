#include <stdio.h>
#include <stdlib.h>

typedef struct Estudante {
	char *nome;
	int matricula;
	int idade;
} ESTUDANTE;

int main() {

	ESTUDANTE est;
	ESTUDANTE *p_est;
	
	p_est=&est;

	est.nome = "Henrique";
	est.matricula = 12345;
	est.idade = 35;

	printf("\nNome: %s\nMatricula: %d\nIdade: %d\n", 
		  est.nome, est.matricula, est.idade);
	printf("\nNome: %s\nMatricula: %d\nIdade: %d\n\n", 
		  p_est->nome, p_est->matricula, p_est->idade);
	
	return 0;
}
